import React, { useState } from 'react';
import { Booking, CustomerAddress } from '../types';
import { DataStore } from '../services/store';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  FileText, 
  RefreshCw, 
  XCircle, 
  User as UserIcon, 
  Home, 
  ChevronRight, 
  CheckCircle2, 
  AlertCircle,
  Plus,
  ArrowRight
} from 'lucide-react';

interface CustomerDashboardProps {
  onBookAgain: (serviceId: string) => void;
  onOpenInvoice: (booking: Booking) => void;
  onClose: () => void;
}

export function CustomerDashboard({ onBookAgain, onOpenInvoice, onClose }: CustomerDashboardProps) {
  const [activeTab, setActiveTab] = useState<'bookings' | 'addresses' | 'profile'>('bookings');
  const [bookings, setBookings] = useState<Booking[]>(DataStore.getBookings());
  const [reschedulingBooking, setReschedulingBooking] = useState<Booking | null>(null);
  const [cancellingBooking, setCancellingBooking] = useState<Booking | null>(null);
  const [selectedBookingDetails, setSelectedBookingDetails] = useState<Booking | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [newRescheduleDate, setNewRescheduleDate] = useState('');
  const [newRescheduleTime, setNewRescheduleTime] = useState('09:00 – 12:00');

  // Customer profile info (mocked/stored for demo user)
  const [customerName, setCustomerName] = useState('Oliver Smith');
  const [customerEmail, setCustomerEmail] = useState('customer@cleaning.co.uk');
  const [customerPhone, setCustomerPhone] = useState('07700 900881');
  const [savedAddresses, setSavedAddresses] = useState<CustomerAddress[]>([
    { id: 'addr-1', label: 'Home (Kensington)', addressLine1: '14 Kensington Park Gardens', city: 'London', postcode: 'W11 3HB', isDefault: true }
  ]);
  const [newAddressLine, setNewAddressLine] = useState('');
  const [newPostcode, setNewPostcode] = useState('');
  const [newLabel, setNewLabel] = useState('');
  const [showAddAddress, setShowAddAddress] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  const upcomingBookings = bookings.filter(b => b.status !== 'Cancelled' && b.status !== 'Completed');
  const pastBookings = bookings.filter(b => b.status === 'Completed' || b.status === 'Cancelled');

  const handleConfirmCancel = () => {
    if (!cancellingBooking) return;
    DataStore.cancelBooking(cancellingBooking.id, cancelReason);
    setBookings(DataStore.getBookings());
    setCancellingBooking(null);
    setCancelReason('');
  };

  const handleConfirmReschedule = () => {
    if (!reschedulingBooking || !newRescheduleDate) return;
    DataStore.updateBooking(reschedulingBooking.id, {
      bookingDate: newRescheduleDate,
      timeSlot: newRescheduleTime,
      internalNotes: `Rescheduled by customer to ${newRescheduleDate} (${newRescheduleTime})`
    });
    setBookings(DataStore.getBookings());
    setReschedulingBooking(null);
    setNewRescheduleDate('');
  };

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddressLine || !newPostcode) return;
    const newAddr: CustomerAddress = {
      id: `addr-${Date.now()}`,
      label: newLabel || 'Saved Property',
      addressLine1: newAddressLine,
      city: 'London',
      postcode: newPostcode.toUpperCase(),
      isDefault: false
    };
    setSavedAddresses([...savedAddresses, newAddr]);
    setNewAddressLine('');
    setNewPostcode('');
    setNewLabel('');
    setShowAddAddress(false);
  };

  const getStatusBadge = (status: Booking['status']) => {
    switch (status) {
      case 'Confirmed':
        return <span className="px-2.5 py-1 bg-sky-100 text-sky-800 text-xs font-bold rounded-full">Confirmed</span>;
      case 'Cleaner Assigned':
        return <span className="px-2.5 py-1 bg-indigo-100 text-indigo-800 text-xs font-bold rounded-full">Cleaner Assigned</span>;
      case 'In Progress':
        return <span className="px-2.5 py-1 bg-amber-100 text-amber-800 text-xs font-bold rounded-full animate-pulse">In Progress</span>;
      case 'Completed':
        return <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">Completed</span>;
      case 'Cancelled':
        return <span className="px-2.5 py-1 bg-rose-100 text-rose-800 text-xs font-bold rounded-full">Cancelled</span>;
      default:
        return <span className="px-2.5 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded-full">Pending</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-sky-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              OS
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-sky-800">Customer Portal</span>
              <h3 className="font-extrabold text-xl text-slate-900">Welcome, {customerName}</h3>
              <p className="text-xs text-slate-500">{customerEmail} • {customerPhone}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="self-start sm:self-center px-4 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition"
          >
            Exit Portal
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 px-6 gap-6 text-sm bg-white">
          <button
            type="button"
            onClick={() => setActiveTab('bookings')}
            className={`py-3.5 font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'bookings' ? 'border-sky-600 text-sky-700' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            My Bookings ({bookings.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('addresses')}
            className={`py-3.5 font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'addresses' ? 'border-sky-600 text-sky-700' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Saved Addresses ({savedAddresses.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`py-3.5 font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'profile' ? 'border-sky-600 text-sky-700' : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Account Profile
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'bookings' && (
            <>
              {/* Upcoming Bookings */}
              <div>
                <h4 className="font-extrabold text-base text-slate-900 mb-3 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-sky-600" />
                  Upcoming Scheduled Cleanings ({upcomingBookings.length})
                </h4>

                {upcomingBookings.length === 0 ? (
                  <div className="p-8 border border-dashed border-slate-200 rounded-2xl text-center bg-slate-50">
                    <p className="text-sm text-slate-500">You have no upcoming cleaning appointments.</p>
                    <button
                      type="button"
                      onClick={() => onBookAgain('srv-regular')}
                      className="mt-3 px-4 py-2 bg-sky-700 text-white rounded-xl text-xs font-bold hover:bg-sky-800 transition cursor-pointer"
                    >
                      Book a Cleaning Now
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {upcomingBookings.map((b) => (
                      <div key={b.id} className="p-4 border border-slate-200 rounded-2xl bg-white hover:border-slate-300 transition shadow-2xs">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-bold text-sky-800">{b.reference}</span>
                              {getStatusBadge(b.status)}
                            </div>
                            <h5 className="font-bold text-slate-900 text-base mt-1">{b.serviceName}</h5>
                          </div>
                          <div className="text-right">
                            <span className="text-lg font-black text-slate-900 font-mono">£{b.pricing.total.toFixed(2)}</span>
                            <span className="block text-[11px] text-slate-500">{b.paymentStatus}</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 py-3 text-xs text-slate-600">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                            <span>{b.bookingDate}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            <span>{b.timeSlot}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-slate-400" />
                            <span className="truncate">{b.houseNumber} {b.address}, {b.postcode}</span>
                          </div>
                        </div>

                        {b.assignedCleanerName && (
                          <div className="p-2.5 bg-sky-50 rounded-xl text-xs text-sky-900 flex items-center justify-between mb-3">
                            <span>Assigned Cleaner: <strong>{b.assignedCleanerName}</strong></span>
                            <span className="text-[11px] text-sky-700">Fully Vetted</span>
                          </div>
                        )}

                        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => setSelectedBookingDetails(b)}
                              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold transition"
                            >
                              View Details
                            </button>
                            <button
                              type="button"
                              onClick={() => onOpenInvoice(b)}
                              className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg font-semibold transition flex items-center gap-1"
                            >
                              <FileText className="w-3.5 h-3.5" /> Receipt
                            </button>
                          </div>

                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setReschedulingBooking(b);
                                setNewRescheduleDate(b.bookingDate);
                                setNewRescheduleTime(b.timeSlot);
                              }}
                              className="px-3 py-1.5 bg-sky-50 text-sky-700 hover:bg-sky-100 rounded-lg font-semibold transition flex items-center gap-1"
                            >
                              <RefreshCw className="w-3.5 h-3.5" /> Reschedule
                            </button>
                            <button
                              type="button"
                              onClick={() => setCancellingBooking(b)}
                              className="px-3 py-1.5 text-rose-600 hover:bg-rose-50 rounded-lg font-semibold transition"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Past / Completed Bookings */}
              {pastBookings.length > 0 && (
                <div className="pt-4 border-t border-slate-100">
                  <h4 className="font-extrabold text-base text-slate-900 mb-3">
                    Past Bookings & Receipts ({pastBookings.length})
                  </h4>
                  <div className="space-y-3">
                    {pastBookings.map((b) => (
                      <div key={b.id} className="p-4 border border-slate-200 rounded-2xl bg-slate-50/50">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-bold text-slate-600">{b.reference}</span>
                              {getStatusBadge(b.status)}
                            </div>
                            <h5 className="font-bold text-slate-800 text-sm mt-1">{b.serviceName}</h5>
                            <p className="text-xs text-slate-500 mt-0.5">{b.bookingDate} • £{b.pricing.total.toFixed(2)}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => onOpenInvoice(b)}
                              className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 transition flex items-center gap-1"
                            >
                              <FileText className="w-3.5 h-3.5" /> Receipt
                            </button>
                            <button
                              type="button"
                              onClick={() => onBookAgain(b.serviceId)}
                              className="px-3 py-1.5 bg-sky-700 text-white rounded-lg text-xs font-bold hover:bg-sky-800 transition"
                            >
                              Book Again
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {activeTab === 'addresses' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-base">Saved Property Addresses</h4>
                  <p className="text-xs text-slate-500">Quickly select recurring locations during booking.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddAddress(!showAddAddress)}
                  className="px-3 py-1.5 bg-sky-700 text-white rounded-xl text-xs font-bold hover:bg-sky-800 transition flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Add New
                </button>
              </div>

              {showAddAddress && (
                <form onSubmit={handleAddAddress} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 text-xs">
                  <h5 className="font-bold text-slate-900">Add Property Address</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <input
                      type="text"
                      placeholder="Label (e.g. Home, Office, Rental Flat)"
                      value={newLabel}
                      onChange={(e) => setNewLabel(e.target.value)}
                      className="p-2 bg-white border border-slate-300 rounded-xl"
                    />
                    <input
                      type="text"
                      required
                      placeholder="Street Address"
                      value={newAddressLine}
                      onChange={(e) => setNewAddressLine(e.target.value)}
                      className="p-2 bg-white border border-slate-300 rounded-xl sm:col-span-2"
                    />
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      required
                      placeholder="UK Postcode (e.g. W11 3HB)"
                      value={newPostcode}
                      onChange={(e) => setNewPostcode(e.target.value.toUpperCase())}
                      className="p-2 bg-white border border-slate-300 rounded-xl uppercase font-semibold"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-sky-700 text-white rounded-xl font-bold hover:bg-sky-800 transition"
                    >
                      Save Address
                    </button>
                  </div>
                </form>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {savedAddresses.map((addr) => (
                  <div key={addr.id} className="p-4 border border-slate-200 rounded-2xl bg-white relative">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-900 text-sm">{addr.label}</span>
                      {addr.isDefault && (
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-sky-100 text-sky-800 rounded-full">
                          Default
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600">{addr.addressLine1}</p>
                    <p className="text-xs font-bold text-slate-800 mt-1 uppercase">{addr.postcode}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="max-w-md space-y-4 text-xs">
              <h4 className="font-bold text-slate-900 text-base">Your Personal Details</h4>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Name</label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl"
                />
              </div>
              <button
                type="button"
                onClick={() => alert('Profile details updated successfully.')}
                className="px-4 py-2 bg-sky-700 text-white rounded-xl font-bold hover:bg-sky-800 transition"
              >
                Save Changes
              </button>
            </div>
          )}
        </div>

        {/* Modal: Reschedule */}
        {reschedulingBooking && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl border border-slate-200">
              <h4 className="font-bold text-slate-900 text-base">Reschedule Cleaning</h4>
              <p className="text-xs text-slate-600">
                You can choose a new date and arrival window for booking <strong className="font-mono">{reschedulingBooking.reference}</strong> at no fee.
              </p>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">New Date</label>
                <input
                  type="date"
                  min={todayStr}
                  value={newRescheduleDate}
                  onChange={(e) => setNewRescheduleDate(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl text-sm font-semibold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">New Time Slot</label>
                <select
                  value={newRescheduleTime}
                  onChange={(e) => setNewRescheduleTime(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl text-xs font-medium"
                >
                  <option value="08:30 – 11:30">Morning: 08:30 – 11:30</option>
                  <option value="12:00 – 15:00">Midday: 12:00 – 15:00</option>
                  <option value="15:30 – 18:30">Afternoon: 15:30 – 18:30</option>
                  <option value="18:30 – 21:00">Evening: 18:30 – 21:00</option>
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReschedulingBooking(null)}
                  className="px-4 py-2 bg-slate-100 rounded-xl text-xs font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmReschedule}
                  className="px-5 py-2 bg-sky-700 text-white rounded-xl text-xs font-bold hover:bg-sky-800"
                >
                  Confirm Reschedule
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Cancel Booking */}
        {cancellingBooking && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl border border-slate-200">
              <div className="flex items-center gap-2 text-rose-600">
                <AlertCircle className="w-5 h-5" />
                <h4 className="font-bold text-slate-900 text-base">Cancel Appointment</h4>
              </div>
              <p className="text-xs text-slate-600">
                Are you sure you want to cancel booking <strong className="font-mono">{cancellingBooking.reference}</strong> on {cancellingBooking.bookingDate}?
              </p>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Reason for cancellation (optional)</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Plans changed, rebooking for next month..."
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl text-xs"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCancellingBooking(null)}
                  className="px-4 py-2 bg-slate-100 rounded-xl text-xs font-semibold text-slate-700"
                >
                  Keep Booking
                </button>
                <button
                  type="button"
                  onClick={handleConfirmCancel}
                  className="px-5 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700"
                >
                  Yes, Cancel Booking
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Selected Booking Details */}
        {selectedBookingDetails && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-xl border border-slate-200">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <span className="font-mono text-xs font-bold text-sky-800">{selectedBookingDetails.reference}</span>
                  <h4 className="font-bold text-base text-slate-900">{selectedBookingDetails.serviceName}</h4>
                </div>
                {getStatusBadge(selectedBookingDetails.status)}
              </div>
              <div className="space-y-2 text-xs text-slate-700">
                <p><strong>Property:</strong> {selectedBookingDetails.propertyType} • {selectedBookingDetails.propertySize} • {selectedBookingDetails.bathrooms} Bathrooms</p>
                <p><strong>Frequency:</strong> {selectedBookingDetails.frequency}</p>
                <p><strong>Date & Time:</strong> {selectedBookingDetails.bookingDate} ({selectedBookingDetails.timeSlot})</p>
                <p><strong>Address:</strong> {selectedBookingDetails.houseNumber} {selectedBookingDetails.address}, {selectedBookingDetails.postcode}</p>
                {selectedBookingDetails.accessInstructions && (
                  <p><strong>Access:</strong> {selectedBookingDetails.accessInstructions}</p>
                )}
                {selectedBookingDetails.specialInstructions && (
                  <p><strong>Special Notes:</strong> {selectedBookingDetails.specialInstructions}</p>
                )}
                {selectedBookingDetails.selectedExtras.length > 0 && (
                  <div>
                    <strong>Extras Included:</strong>
                    <ul className="list-disc pl-4 mt-1 text-slate-600">
                      {selectedBookingDetails.selectedExtras.map(ext => (
                        <li key={ext.extraId}>{ext.title} (£{ext.price})</li>
                      ))}
                    </ul>
                  </div>
                )}
                <div className="p-3 bg-slate-50 rounded-xl font-bold flex justify-between text-slate-900 pt-2">
                  <span>Total Cost:</span>
                  <span className="font-mono text-sky-800 text-sm">£{selectedBookingDetails.pricing.total.toFixed(2)}</span>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedBookingDetails(null)}
                  className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
