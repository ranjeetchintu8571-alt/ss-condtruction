import React, { useState } from 'react';
import { Booking, Cleaner } from '../types';
import { DataStore } from '../services/store';
import { 
  CheckCircle, 
  Clock, 
  MapPin, 
  Phone, 
  User, 
  Camera, 
  Play, 
  AlertCircle, 
  MessageSquare, 
  ShieldCheck,
  Calendar,
  X
} from 'lucide-react';

export function CleanerDashboard({ onClose }: { onClose: () => void }) {
  const cleaners = DataStore.getCleaners();
  const [selectedCleanerId, setSelectedCleanerId] = useState<string>(cleaners[0]?.id || 'cln-1');
  const [bookings, setBookings] = useState<Booking[]>(DataStore.getBookings());
  const [photoUploadModal, setPhotoUploadModal] = useState<string | null>(null);
  const [completionNotes, setCompletionNotes] = useState('');
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);

  const activeCleaner = cleaners.find(c => c.id === selectedCleanerId) || cleaners[0];

  // Filter jobs for this cleaner or unassigned jobs
  const myBookings = bookings.filter(b => 
    b.assignedCleanerId === activeCleaner?.id || (!b.assignedCleanerId && b.status === 'Confirmed')
  );

  const todayStr = new Date().toISOString().split('T')[0];
  const todayJobs = myBookings.filter(b => b.status !== 'Completed' && b.status !== 'Cancelled');
  const completedJobs = myBookings.filter(b => b.status === 'Completed');

  const handleStartJob = (bookingId: string) => {
    DataStore.updateBooking(bookingId, {
      status: 'In Progress',
      assignedCleanerId: activeCleaner?.id,
      assignedCleanerName: activeCleaner?.name,
      cleanerNotes: 'Cleaner arrived on site and started work.'
    });
    setBookings(DataStore.getBookings());
  };

  const handleOpenCompleteModal = (bookingId: string) => {
    setPhotoUploadModal(bookingId);
    setCompletionNotes('');
    setUploadedPhotos([]);
  };

  const handleFinishCompletion = () => {
    if (!photoUploadModal) return;
    DataStore.updateBooking(photoUploadModal, {
      status: 'Completed',
      cleanerNotes: completionNotes || 'Job completed to high quality standard.',
      completionPhotos: uploadedPhotos.length > 0 ? uploadedPhotos : [
        'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=400&q=80'
      ]
    });
    // Increment cleaner jobs count
    if (activeCleaner) {
      DataStore.updateCleaner(activeCleaner.id, {
        completedJobsCount: activeCleaner.completedJobsCount + 1,
        status: 'Available'
      });
    }
    setBookings(DataStore.getBookings());
    setPhotoUploadModal(null);
  };

  const simulatePhotoAdd = () => {
    setUploadedPhotos(prev => [
      ...prev, 
      'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=400&q=80'
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-700 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">Operative Workspace</span>
              <h3 className="font-extrabold text-xl text-slate-900">Cleaner Portal: {activeCleaner?.name}</h3>
              <p className="text-xs text-slate-500">
                Status: <span className="font-bold text-emerald-700">{activeCleaner?.status}</span> • Rating: {activeCleaner?.rating} ★ • {activeCleaner?.completedJobsCount} Jobs Completed
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Cleaner Account Switcher */}
            <select
              value={selectedCleanerId}
              onChange={(e) => setSelectedCleanerId(e.target.value)}
              className="p-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 outline-none"
            >
              {cleaners.map(c => (
                <option key={c.id} value={c.id}>Log in as: {c.name}</option>
              ))}
            </select>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition"
            >
              Exit
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-slate-800">
          {/* Today & Upcoming Active Jobs */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-600" />
                Active & Upcoming Jobs ({todayJobs.length})
              </h4>
              <span className="text-xs text-slate-500 font-medium">Service Areas: {activeCleaner?.serviceAreas.join(', ')}</span>
            </div>

            {todayJobs.length === 0 ? (
              <div className="p-8 border border-dashed border-slate-200 rounded-2xl text-center bg-slate-50">
                <p className="text-sm text-slate-500">No active jobs assigned right now. You are set to Available.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {todayJobs.map((job) => (
                  <div key={job.id} className="p-5 border-2 border-slate-200 rounded-2xl bg-white shadow-xs">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-sky-800 bg-sky-50 px-2 py-0.5 rounded-md">
                            {job.reference}
                          </span>
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                            job.status === 'In Progress' ? 'bg-amber-100 text-amber-900 animate-pulse' : 'bg-sky-100 text-sky-800'
                          }`}>
                            {job.status}
                          </span>
                        </div>
                        <h5 className="font-bold text-slate-900 text-base mt-1">{job.serviceName}</h5>
                        <p className="text-xs text-slate-500">{job.propertyType} • {job.propertySize} • {job.bathrooms} Bathrooms</p>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-bold text-slate-700 block">Scheduled Time</span>
                        <span className="text-sm font-black text-slate-900">{job.bookingDate}</span>
                        <span className="text-xs text-sky-700 block font-semibold">{job.timeSlot}</span>
                      </div>
                    </div>

                    {/* Customer & Location Specs */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 py-3 text-xs bg-slate-50/70 p-3 rounded-xl mt-3">
                      <div>
                        <span className="text-slate-400 uppercase font-bold text-[10px] block">Customer</span>
                        <span className="font-bold text-slate-900 text-sm">{job.customerName}</span>
                        <a href={`tel:${job.customerPhone}`} className="text-sky-700 font-medium block mt-0.5 hover:underline">
                          📞 {job.customerPhone}
                        </a>
                      </div>
                      <div>
                        <span className="text-slate-400 uppercase font-bold text-[10px] block">Address</span>
                        <span className="font-semibold text-slate-800 text-sm">{job.houseNumber} {job.address}</span>
                        <span className="text-slate-900 font-black uppercase block">{job.postcode}</span>
                      </div>
                    </div>

                    {/* Access & Instructions */}
                    {(job.accessInstructions || job.specialInstructions) && (
                      <div className="mt-3 p-3 bg-amber-50/70 border border-amber-200/60 rounded-xl text-xs space-y-1">
                        {job.accessInstructions && (
                          <p className="text-amber-950">
                            <strong>🔑 Access:</strong> {job.accessInstructions}
                          </p>
                        )}
                        {job.specialInstructions && (
                          <p className="text-amber-950">
                            <strong>📝 Focus Notes:</strong> {job.specialInstructions}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-4 mt-3 border-t border-slate-100">
                      <a
                        href={`tel:${job.customerPhone}`}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Phone className="w-3.5 h-3.5" /> Contact Customer
                      </a>

                      <div className="flex gap-2">
                        {job.status !== 'In Progress' ? (
                          <button
                            type="button"
                            onClick={() => handleStartJob(job.id)}
                            className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
                          >
                            <Play className="w-3.5 h-3.5 fill-current" /> Start Job
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOpenCompleteModal(job.id)}
                            className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
                          >
                            <CheckCircle className="w-4 h-4" /> Complete Job & Submit
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Completed Jobs History */}
          {completedJobs.length > 0 && (
            <div className="pt-4 border-t border-slate-100">
              <h4 className="font-extrabold text-base text-slate-900 mb-3 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                Completed Jobs History ({completedJobs.length})
              </h4>
              <div className="space-y-2">
                {completedJobs.map(job => (
                  <div key={job.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-slate-700 mr-2">{job.reference}</span>
                      <strong className="text-slate-900">{job.serviceName}</strong>
                      <span className="text-slate-500 ml-2">• {job.customerName} ({job.postcode})</span>
                    </div>
                    <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
                      ✓ Completed
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal: Complete Job & Upload Photos */}
        {photoUploadModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-200">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <h4 className="font-bold text-slate-900 text-base">Complete Job Checklist</h4>
                <button 
                  type="button" 
                  onClick={() => setPhotoUploadModal(null)} 
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Completion Notes / Client Handover</label>
                <textarea
                  rows={3}
                  value={completionNotes}
                  onChange={(e) => setCompletionNotes(e.target.value)}
                  placeholder="e.g. All rooms vacuumed and sanitised. Oven glass buffed. Key returned to security box."
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Upload Completion Proof Photos (Optional)</label>
                <div 
                  onClick={simulatePhotoAdd}
                  className="p-3 border-2 border-dashed border-slate-300 hover:border-emerald-600 rounded-xl text-center cursor-pointer bg-slate-50 transition"
                >
                  <Camera className="w-5 h-5 text-slate-400 mx-auto mb-1" />
                  <span className="text-xs text-slate-600 font-semibold">+ Add Room Photo Proof</span>
                </div>
                {uploadedPhotos.length > 0 && (
                  <div className="mt-2 flex gap-2">
                    {uploadedPhotos.map((url, i) => (
                      <img key={i} src={url} alt="Proof" className="w-14 h-14 object-cover rounded-lg border border-slate-200" />
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPhotoUploadModal(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleFinishCompletion}
                  className="px-5 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800"
                >
                  Confirm Completion
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
