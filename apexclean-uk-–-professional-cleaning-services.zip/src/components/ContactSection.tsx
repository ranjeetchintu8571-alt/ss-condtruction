import React, { useState } from 'react';
import { DataStore } from '../services/store';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2, ShieldCheck } from 'lucide-react';

export function ContactSection() {
  const content = DataStore.getWebsiteContent();
  const services = DataStore.getServices();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [postcode, setPostcode] = useState('');
  const [serviceInterest, setServiceInterest] = useState('General Enquiry');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    DataStore.createContactMessage({
      name,
      email,
      phone,
      postcode: postcode.toUpperCase(),
      message: `[Interest: ${serviceInterest}] ${message}`
    });
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200">
      <div className="max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="px-3 py-1 bg-sky-100 text-sky-800 rounded-full text-xs font-bold uppercase tracking-wider">
            Get In Touch
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mt-2">
            We're Here To Help
          </h2>
          <p className="text-slate-600 text-sm mt-2">
            Have a question about domestic cleaning, commercial contracts, or bespoke end-of-tenancy quotes? Contact our UK team.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Company Contact Information (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900 text-white rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div>
              <span className="text-xs font-black uppercase tracking-widest text-sky-400">Direct Contacts</span>
              <h3 className="text-2xl font-black mt-1">{content.companyName}</h3>
              <p className="text-slate-400 text-xs mt-1">{content.tagline}</p>
            </div>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-3 p-3 bg-slate-800/80 rounded-2xl border border-slate-700">
                <Phone className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 block">Telephone Support</span>
                  <a href={`tel:${content.phone}`} className="font-bold text-sm text-white hover:text-sky-300 transition">
                    {content.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-800/80 rounded-2xl border border-slate-700">
                <Mail className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 block">Email Enquiries</span>
                  <a href={`mailto:${content.email}`} className="font-bold text-sm text-white hover:text-sky-300 transition">
                    {content.email}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-800/80 rounded-2xl border border-slate-700">
                <MapPin className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 block">Head Office & Dispatch Hub</span>
                  <p className="font-medium text-white">{content.address}</p>
                  <p className="text-[11px] text-sky-400 mt-0.5">{content.serviceArea}</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-800/80 rounded-2xl border border-slate-700">
                <Clock className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 block">Operating Hours</span>
                  <p className="font-medium text-white">{content.openingHours}</p>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="pt-2">
              <div className="h-40 rounded-2xl bg-slate-800 border border-slate-700 flex flex-col items-center justify-center text-center p-4">
                <MapPin className="w-8 h-8 text-sky-500 mb-1 animate-bounce" />
                <span className="text-xs font-bold text-white">Central Operations Hub</span>
                <span className="text-[10px] text-slate-400">{content.address}</span>
              </div>
            </div>
          </div>

          {/* Interactive Enquiry Form (7 cols) */}
          <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm">
            {submitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
                <h3 className="text-2xl font-black text-slate-900">Message Received!</h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  Thank you for contacting {content.companyName}. A dedicated cleaning coordinator will review your query and reply within 2 business hours.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSubmitted(false);
                    setMessage('');
                  }}
                  className="px-6 py-2.5 bg-sky-700 text-white rounded-xl text-xs font-bold hover:bg-sky-800 transition"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <h3 className="text-xl font-bold text-slate-900 mb-1">Send Us a Direct Message</h3>
                <p className="text-slate-500 text-xs mb-4">Fill out the quick form below and our customer care team will assist you.</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sarah Jenkins"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="sarah@example.co.uk"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Telephone *</label>
                    <input
                      type="tel"
                      required
                      placeholder="07700 900000"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">UK Postcode *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. SW1A 1AA"
                      value={postcode}
                      onChange={(e) => setPostcode(e.target.value.toUpperCase())}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500 uppercase font-semibold"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Service of Interest</label>
                  <select
                    value={serviceInterest}
                    onChange={(e) => setServiceInterest(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500 font-medium"
                  >
                    <option value="General Enquiry">General Enquiry</option>
                    {services.map(s => (
                      <option key={s.id} value={s.title}>{s.title}</option>
                    ))}
                    <option value="Commercial Contract">Commercial / Office Contract</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">How can we help? *</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Tell us about your property, frequency, access requirements, or questions..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-8 py-3 bg-sky-700 hover:bg-sky-800 text-white rounded-xl font-bold shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" /> Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
