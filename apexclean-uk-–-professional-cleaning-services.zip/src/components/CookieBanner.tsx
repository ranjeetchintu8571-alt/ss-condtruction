import React, { useState, useEffect } from 'react';
import { ShieldCheck, Cookie, X } from 'lucide-react';

interface CookiePreferences {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
}

export function CookieBanner({ onOpenLegal }: { onOpenLegal: (type: 'privacy' | 'cookies' | 'terms') => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [prefs, setPrefs] = useState<CookiePreferences>({
    essential: true,
    analytics: false,
    marketing: false
  });

  useEffect(() => {
    const saved = localStorage.getItem('apexclean_cookie_consent');
    if (!saved) {
      setIsOpen(true);
    }
  }, []);

  const handleAcceptAll = () => {
    const consent = { essential: true, analytics: true, marketing: true, timestamp: new Date().toISOString() };
    localStorage.setItem('apexclean_cookie_consent', JSON.stringify(consent));
    setIsOpen(false);
  };

  const handleRejectNonEssential = () => {
    const consent = { essential: true, analytics: false, marketing: false, timestamp: new Date().toISOString() };
    localStorage.setItem('apexclean_cookie_consent', JSON.stringify(consent));
    setIsOpen(false);
  };

  const handleSavePreferences = () => {
    const consent = { ...prefs, essential: true, timestamp: new Date().toISOString() };
    localStorage.setItem('apexclean_cookie_consent', JSON.stringify(consent));
    setIsOpen(false);
    setShowPreferences(false);
  };

  if (!isOpen) return null;

  return (
    <div id="cookie-consent-banner" className="fixed bottom-4 left-4 right-4 md:left-8 md:right-auto md:max-w-xl bg-white border border-slate-200 rounded-2xl shadow-xl p-5 z-50 text-slate-800">
      <div className="flex items-start gap-3">
        <div className="p-2.5 bg-sky-50 text-sky-700 rounded-xl shrink-0">
          <Cookie className="w-6 h-6" />
        </div>
        <div className="flex-1 text-sm">
          <h4 className="font-bold text-base text-slate-900 mb-1">UK & EU Privacy & Cookies</h4>
          <p className="text-slate-600 leading-relaxed">
            We use essential cookies to ensure our online booking system operates securely. With your permission, we also use non-essential cookies to analyze website performance.
          </p>
          <div className="mt-2 flex gap-3 text-xs text-sky-700 font-medium">
            <button 
              type="button" 
              onClick={() => onOpenLegal('cookies')} 
              className="hover:underline cursor-pointer"
            >
              Cookie Policy
            </button>
            <span>•</span>
            <button 
              type="button" 
              onClick={() => onOpenLegal('privacy')} 
              className="hover:underline cursor-pointer"
            >
              Privacy Policy
            </button>
          </div>

          {showPreferences && (
            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
              <label className="flex items-center justify-between">
                <span className="font-semibold text-slate-900">Essential Cookies (Required for booking)</span>
                <input type="checkbox" checked disabled className="rounded text-sky-600 focus:ring-sky-500" />
              </label>
              <label className="flex items-center justify-between cursor-pointer">
                <span className="text-slate-700">Analytics & Performance</span>
                <input 
                  type="checkbox" 
                  checked={prefs.analytics} 
                  onChange={(e) => setPrefs({ ...prefs, analytics: e.target.checked })} 
                  className="rounded text-sky-600 focus:ring-sky-500"
                />
              </label>
              <label className="flex items-center justify-between cursor-pointer">
                <span className="text-slate-700">Marketing & Personalization</span>
                <input 
                  type="checkbox" 
                  checked={prefs.marketing} 
                  onChange={(e) => setPrefs({ ...prefs, marketing: e.target.checked })} 
                  className="rounded text-sky-600 focus:ring-sky-500"
                />
              </label>
            </div>
          )}

          <div className="mt-4 flex flex-wrap items-center gap-2">
            {!showPreferences ? (
              <>
                <button
                  id="accept-all-cookies-btn"
                  type="button"
                  onClick={handleAcceptAll}
                  className="px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white rounded-lg text-xs font-semibold shadow-sm transition"
                >
                  Accept All
                </button>
                <button
                  id="reject-cookies-btn"
                  type="button"
                  onClick={handleRejectNonEssential}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition"
                >
                  Reject Non-Essential
                </button>
                <button
                  id="manage-cookies-btn"
                  type="button"
                  onClick={() => setShowPreferences(true)}
                  className="px-3.5 py-2 text-slate-600 hover:text-slate-900 text-xs font-medium underline transition"
                >
                  Manage Preferences
                </button>
              </>
            ) : (
              <>
                <button
                  id="save-cookie-prefs-btn"
                  type="button"
                  onClick={handleSavePreferences}
                  className="px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white rounded-lg text-xs font-semibold transition"
                >
                  Save Preferences
                </button>
                <button
                  type="button"
                  onClick={() => setShowPreferences(false)}
                  className="px-3 py-2 text-slate-600 text-xs font-medium transition"
                >
                  Back
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function LegalModal({
  type,
  isOpen,
  onClose,
  companyName
}: {
  type: 'privacy' | 'cookies' | 'terms' | null;
  isOpen: boolean;
  onClose: () => void;
  companyName: string;
}) {
  if (!isOpen || !type) return null;

  const titles = {
    privacy: 'Privacy Policy (UK GDPR Compliant)',
    cookies: 'Cookie Policy',
    terms: 'Terms and Conditions of Service'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden border border-slate-200">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-sky-100 text-sky-800 rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-lg text-slate-900">{titles[type]}</h3>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4 text-sm text-slate-600 leading-relaxed">
          {type === 'privacy' && (
            <>
              <p className="text-xs text-slate-400">Last updated: September 2026 • Compliant with the UK Data Protection Act 2018 and UK GDPR.</p>
              <h4 className="font-bold text-slate-900 text-base">1. Information We Collect</h4>
              <p>When you use the {companyName} booking portal or request a quote, we collect contact information (name, phone number, email address), property address, access instructions, and preferred cleaning specifications.</p>
              <h4 className="font-bold text-slate-900 text-base">2. Purpose of Processing</h4>
              <p>We process your personal data strictly to deliver cleaning services, assign vetted cleaners to your location, calculate dynamic pricing, send booking confirmations, invoices, and relevant service reminders.</p>
              <h4 className="font-bold text-slate-900 text-base">3. Payment Information Security</h4>
              <p>We never store raw credit or debit card numbers on our servers. All digital transactions are handled via compliant encrypted payment gateways.</p>
              <h4 className="font-bold text-slate-900 text-base">4. Your Statutory UK Rights</h4>
              <p>Under UK GDPR, you have the right to access, rectify, or request deletion of your personal data at any time by contacting our support team.</p>
            </>
          )}

          {type === 'cookies' && (
            <>
              <p className="text-xs text-slate-400">Last updated: September 2026</p>
              <h4 className="font-bold text-slate-900 text-base">1. What Are Cookies?</h4>
              <p>Cookies are small text files placed on your device to make the booking workflow functional, remember your property selection during booking, and ensure secure authentication.</p>
              <h4 className="font-bold text-slate-900 text-base">2. Strictly Essential Cookies</h4>
              <p>These cookies are required for core site functionality, including remembering items in your booking wizard, postcode validation, and customer login credentials. They cannot be turned off.</p>
              <h4 className="font-bold text-slate-900 text-base">3. Analytical & Preference Cookies</h4>
              <p>With your explicit consent, we may gather anonymous metrics regarding page visits to optimize page speed and booking efficiency.</p>
            </>
          )}

          {type === 'terms' && (
            <>
              <p className="text-xs text-slate-400">Last updated: September 2026</p>
              <h4 className="font-bold text-slate-900 text-base">1. Service Provision</h4>
              <p>{companyName} connects customers with professional, vetted cleaning operatives. All cleaning services are carried out in accordance with standard UK industry guidelines and safety protocols.</p>
              <h4 className="font-bold text-slate-900 text-base">2. Access, Water & Electricity</h4>
              <p>The client agrees to provide safe access to the property at the agreed scheduled time, as well as working hot water and electricity necessary to operate cleaning appliances.</p>
              <h4 className="font-bold text-slate-900 text-base">3. Rescheduling and Cancellations</h4>
              <p>Clients may reschedule or cancel any appointment free of charge up to 24 hours prior to the scheduled start time. Cancellations with less than 24 hours notice may be subject to a standard callout charge.</p>
              <h4 className="font-bold text-slate-900 text-base">4. End of Tenancy Guarantee</h4>
              <p>Our End of Tenancy cleaning adheres strictly to estate agent checkout checklists. If any item is flagged during the official inventory checkout within 48 hours, our operatives will re-attend free of charge.</p>
            </>
          )}
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-sm font-semibold hover:bg-slate-800 transition"
          >
            I Understand & Close
          </button>
        </div>
      </div>
    </div>
  );
}
