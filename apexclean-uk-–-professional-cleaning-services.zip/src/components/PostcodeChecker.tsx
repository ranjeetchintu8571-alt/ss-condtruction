import React, { useState } from 'react';
import { DataStore } from '../services/store';
import { MapPin, CheckCircle2, AlertCircle, ArrowRight, BellRing } from 'lucide-react';

export function PostcodeChecker({ onBookNow }: { onBookNow: (postcode: string) => void }) {
  const [inputPostcode, setInputPostcode] = useState('');
  const [checkResult, setCheckResult] = useState<{ checked: boolean; covered: boolean; message?: string } | null>(null);
  const [notifyEmail, setNotifyEmail] = useState('');
  const [notified, setNotified] = useState(false);

  const serviceArea = DataStore.getServiceArea();

  const handleCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputPostcode.trim()) return;

    const res = DataStore.validatePostcode(inputPostcode);
    if (res.isValid) {
      setCheckResult({ checked: true, covered: true });
    } else {
      setCheckResult({ checked: true, covered: false, message: res.message });
    }
  };

  const handleNotifySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifyEmail) return;
    setNotified(true);
  };

  return (
    <section id="service-areas" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900 text-white relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-sky-600/15 blur-3xl rounded-full pointer-events-none"></div>

      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-900/60 text-sky-400 border border-sky-800 text-xs font-bold uppercase tracking-wider mb-2">
            <MapPin className="w-3.5 h-3.5" /> Fast Coverage Check
          </div>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
            Do We Clean In Your Postcode?
          </h2>
          <p className="text-slate-300 text-sm mt-2">
            Enter your UK postcode below to verify immediate cleaner dispatch availability.
          </p>
        </div>

        {/* Search Box */}
        <div className="max-w-xl mx-auto">
          <form onSubmit={handleCheck} className="flex flex-col sm:flex-row gap-2 bg-slate-800/90 p-2.5 rounded-2xl border border-slate-700 shadow-2xl backdrop-blur-md">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Enter UK Postcode (e.g. SW1A 1AA, EC2M, W1)"
                value={inputPostcode}
                onChange={(e) => {
                  setInputPostcode(e.target.value);
                  setCheckResult(null);
                  setNotified(false);
                }}
                className="w-full px-4 py-3.5 bg-slate-900/80 border border-slate-700 rounded-xl text-white placeholder-slate-400 text-sm uppercase font-bold tracking-wider outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-lg transition flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              Check Postcode
            </button>
          </form>

          {/* Result Banner */}
          {checkResult && (
            <div className="mt-4 animate-fade-in">
              {checkResult.covered ? (
                <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-emerald-200 text-xs shadow-lg">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div>
                      <strong className="text-sm font-black text-white block">
                        Great news! We operate in your area.
                      </strong>
                      <span>Professional vetted cleaners are ready for dispatch to your address.</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onBookNow(inputPostcode)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                  >
                    Book Now For This Postcode <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="p-4 bg-slate-800 border border-slate-700 rounded-2xl text-slate-300 text-xs shadow-lg space-y-3">
                  <div className="flex items-start gap-2.5">
                    <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-sm font-bold text-white block">
                        We don't regularly service {inputPostcode.toUpperCase()} yet
                      </strong>
                      <p className="text-slate-400 mt-0.5">{checkResult.message || serviceArea.customNotice}</p>
                    </div>
                  </div>

                  {!notified ? (
                    <form onSubmit={handleNotifySubmit} className="flex gap-2 pt-2 border-t border-slate-700/60">
                      <input
                        type="email"
                        required
                        placeholder="Enter email to be notified when we launch here"
                        value={notifyEmail}
                        onChange={(e) => setNotifyEmail(e.target.value)}
                        className="flex-1 p-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500"
                      />
                      <button
                        type="submit"
                        className="px-3 py-2 bg-sky-700 hover:bg-sky-600 text-white rounded-xl text-xs font-bold flex items-center gap-1"
                      >
                        <BellRing className="w-3 h-3" /> Notify Me
                      </button>
                    </form>
                  ) : (
                    <p className="text-emerald-400 font-semibold pt-1">
                      ✓ Thank you! We will email {notifyEmail} the moment our team expands to your street.
                    </p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Common Serviced Areas Chips */}
          <div className="mt-8 pt-6 border-t border-slate-800 text-center">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Major UK Regions Covered Daily:
            </span>
            <div className="flex flex-wrap justify-center gap-1.5 text-xs text-slate-400">
              {serviceArea.cities.map((city, idx) => (
                <span key={idx} className="px-2.5 py-1 bg-slate-800/80 border border-slate-700/60 rounded-lg text-slate-300">
                  {city}
                </span>
              ))}
              <span className="px-2.5 py-1 bg-sky-950/60 text-sky-400 border border-sky-800/50 rounded-lg font-semibold">
                + Surrounding Counties
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
