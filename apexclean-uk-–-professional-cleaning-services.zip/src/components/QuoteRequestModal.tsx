import React, { useState } from 'react';
import { DataStore } from '../services/store';
import { PropertyType } from '../types';
import { X, UploadCloud, CheckCircle2, FileText, AlertCircle } from 'lucide-react';

export function QuoteRequestModal({
  isOpen,
  onClose,
  initialServiceId
}: {
  isOpen: boolean;
  onClose: () => void;
  initialServiceId?: string;
}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [postcode, setPostcode] = useState('');
  const [propertyType, setPropertyType] = useState<PropertyType>('House');
  const [serviceId, setServiceId] = useState(initialServiceId || 'srv-regular');
  const [propertySize, setPropertySize] = useState('3 Bedrooms');
  const [preferredDate, setPreferredDate] = useState('');
  const [message, setMessage] = useState('');
  const [files, setFiles] = useState<{ name: string; size: string; progress: number }[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const services = DataStore.getServices();
  const selectedService = services.find(s => s.id === serviceId);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files;
    if (!uploaded || uploaded.length === 0) return;

    setIsUploading(true);
    const newFiles: { name: string; size: string; progress: number }[] = [];

    Array.from(uploaded).forEach(file => {
      // Validate types: JPG, PNG, PDF
      const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
      if (validTypes.includes(file.type) || file.name.match(/\.(jpg|jpeg|png|pdf)$/i)) {
        const sizeMb = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
        newFiles.push({ name: file.name, size: sizeMb, progress: 0 });
      }
    });

    setFiles(prev => [...prev, ...newFiles]);

    // Simulate progress bar
    let progress = 0;
    const interval = setInterval(() => {
      progress += 25;
      setFiles(prev => prev.map(f => ({ ...f, progress: Math.min(100, progress) })));
      if (progress >= 100) {
        clearInterval(interval);
        setIsUploading(false);
      }
    }, 150);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    DataStore.createQuoteRequest({
      name,
      email,
      phone,
      postcode,
      propertyType,
      serviceId,
      serviceName: selectedService?.title || 'General Cleaning',
      propertySize,
      preferredDate,
      message,
      uploadedFiles: files.map(f => ({ name: f.name, size: f.size }))
    });

    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-sky-800">Bespoke Estimate</span>
            <h3 className="font-extrabold text-lg text-slate-900">Request a Free Quote</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-xl font-bold text-slate-900">Quote Request Received</h4>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              Thank you, {name}. Our specialist team will review your specifications and photos, and email you a tailored quotation within 2 business hours.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. James Wilson"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="james@example.co.uk"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="07700 900000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">UK Postcode *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. SW1A 1AA"
                  value={postcode}
                  onChange={(e) => setPostcode(e.target.value.toUpperCase())}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500 uppercase font-semibold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Cleaning Service *</label>
                <select
                  value={serviceId}
                  onChange={(e) => setServiceId(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                >
                  {services.map(s => (
                    <option key={s.id} value={s.id}>{s.title}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Property Type</label>
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value as PropertyType)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="House">House</option>
                  <option value="Flat/Apartment">Flat/Apartment</option>
                  <option value="Studio">Studio</option>
                  <option value="Office">Office</option>
                  <option value="Shop">Shop</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Property Size / Specs</label>
                <input
                  type="text"
                  placeholder="e.g. 4 Beds, 2.500 sq ft"
                  value={propertySize}
                  onChange={(e) => setPropertySize(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Preferred Date (Optional)</label>
                <input
                  type="date"
                  value={preferredDate}
                  onChange={(e) => setPreferredDate(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Message & Requirements *</label>
              <textarea
                required
                rows={3}
                placeholder="Describe condition, special requests, access details or commercial specs..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-sky-500 resize-none"
              />
            </div>

            {/* File Upload Section (JPG, PNG, PDF with upload progress) */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">Upload Photos / Plans (JPG, PNG, PDF)</label>
              <div className="border-2 border-dashed border-slate-300 hover:border-sky-500 rounded-2xl p-4 text-center cursor-pointer bg-slate-50 transition relative">
                <input
                  type="file"
                  multiple
                  accept=".jpg,.jpeg,.png,.pdf"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />
                <UploadCloud className="w-7 h-7 text-sky-700 mx-auto mb-1" />
                <p className="font-semibold text-slate-800">Click or drag photos here</p>
                <p className="text-[10px] text-slate-500">Supports JPG, PNG, PDF up to 15MB</p>
              </div>

              {/* Uploaded items list with progress */}
              {files.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  {files.map((f, i) => (
                    <div key={i} className="p-2 bg-slate-100 rounded-xl flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-2 overflow-hidden flex-1 mr-2">
                        <FileText className="w-3.5 h-3.5 text-sky-700 shrink-0" />
                        <span className="truncate font-medium text-slate-800">{f.name}</span>
                        <span className="text-slate-400">({f.size})</span>
                      </div>
                      <div className="w-20 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                        <div className="bg-sky-600 h-1.5" style={{ width: `${f.progress}%` }}></div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isUploading}
                className="px-6 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl font-bold shadow-md transition cursor-pointer"
              >
                Send Quote Request
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
