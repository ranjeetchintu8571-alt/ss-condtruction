import React, { useState } from 'react';
import { PropertyType, PropertySize, CleaningFrequency } from '../types';
import { DataStore } from '../services/store';
import { Sparkles, ArrowRight, Check, Plus, Tag } from 'lucide-react';

export function PricingCalculatorSection({ 
  onBookWithParams 
}: { 
  onBookWithParams: (params: {
    serviceId: string;
    propertyType: PropertyType;
    propertySize: PropertySize;
    bathrooms: number;
    frequency: CleaningFrequency;
    selectedExtras: string[];
  }) => void;
}) {
  const services = DataStore.getServices().filter(s => s.active);
  const extras = DataStore.getExtras().filter(e => e.active);

  const [serviceId, setServiceId] = useState('srv-regular');
  const [propertyType, setPropertyType] = useState<PropertyType>('House');
  const [propertySize, setPropertySize] = useState<PropertySize>('2 Bedrooms');
  const [bathrooms, setBathrooms] = useState(1);
  const [frequency, setFrequency] = useState<CleaningFrequency>('weekly');
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);

  const currentService = services.find(s => s.id === serviceId) || services[0];

  const pricing = DataStore.calculatePricing({
    serviceId,
    propertyType,
    propertySize,
    bathrooms,
    frequency,
    selectedExtraIds: selectedExtras
  });

  const toggleExtra = (id: string) => {
    setSelectedExtras(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleBook = () => {
    onBookWithParams({
      serviceId,
      propertyType,
      propertySize,
      bathrooms,
      frequency,
      selectedExtras
    });
  };

  return (
    <section id="pricing" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50/60 border-b border-slate-200">
      <div className="max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" /> Instant Estimate Tool
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Transparent Pricing Calculator
          </h2>
          <p className="text-slate-600 text-sm mt-2">
            Calculate your cleaning cost with zero guesswork. What you see is exactly what you pay.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Controls Form (8 cols) */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            
            {/* 1. Service Selection */}
            <div>
              <label className="block text-xs font-black uppercase tracking-wider text-slate-500 mb-2">
                1. Select Service Type
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {services.map(s => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setServiceId(s.id)}
                    className={`p-3 rounded-2xl border text-left transition cursor-pointer ${
                      serviceId === s.id
                        ? 'border-sky-600 bg-sky-50 font-bold text-sky-900 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="text-xs block font-bold truncate">{s.title}</span>
                    <span className="text-[11px] text-slate-500 block">From £{s.startingPrice}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Bedrooms & Bathrooms */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-500 mb-2">
                  2. Property Bedrooms
                </label>
                <select
                  value={propertySize}
                  onChange={(e) => setPropertySize(e.target.value as PropertySize)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="Studio">Studio Apartment</option>
                  <option value="1 Bedroom">1 Bedroom</option>
                  <option value="2 Bedrooms">2 Bedrooms</option>
                  <option value="3 Bedrooms">3 Bedrooms</option>
                  <option value="4 Bedrooms">4 Bedrooms</option>
                  <option value="5+ Bedrooms">5+ Bedrooms</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-500 mb-2">
                  3. Bathrooms
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4].map(num => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setBathrooms(num)}
                      className={`flex-1 py-3 rounded-2xl border text-xs font-bold transition cursor-pointer ${
                        bathrooms === num
                          ? 'border-sky-600 bg-sky-700 text-white shadow-2xs'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      {num === 4 ? '4+' : num}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* 4. Frequency Selection */}
            <div>
              <label className="block text-xs font-black uppercase tracking-wider text-slate-500 mb-2">
                4. Cleaning Frequency
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'weekly', title: 'Weekly', badge: '15% Off' },
                  { id: 'fortnightly', title: 'Fortnightly', badge: '10% Off' },
                  { id: 'monthly', title: 'Monthly', badge: '5% Off' },
                  { id: 'one-off', title: 'One-Off', badge: 'Standard' }
                ].map(freq => (
                  <button
                    key={freq.id}
                    type="button"
                    onClick={() => setFrequency(freq.id as CleaningFrequency)}
                    className={`p-3 rounded-2xl border text-center transition cursor-pointer ${
                      frequency === freq.id
                        ? 'border-sky-600 bg-sky-50 text-sky-900 font-black shadow-2xs'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="text-xs block font-bold">{freq.title}</span>
                    <span className="text-[10px] text-emerald-700 font-bold block">{freq.badge}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 5. Quick Add Extras */}
            <div>
              <label className="block text-xs font-black uppercase tracking-wider text-slate-500 mb-2">
                5. Add Extras & Specialist Additions
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {extras.slice(0, 6).map(ext => {
                  const isSelected = selectedExtras.includes(ext.id);
                  return (
                    <button
                      key={ext.id}
                      type="button"
                      onClick={() => toggleExtra(ext.id)}
                      className={`p-2.5 rounded-xl border text-left transition flex items-center justify-between text-xs cursor-pointer ${
                        isSelected
                          ? 'border-sky-600 bg-sky-50/80 font-bold text-sky-950'
                          : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <span className="truncate pr-1 text-[11px]">{ext.title}</span>
                      <span className="font-mono text-sky-800 shrink-0">+£{ext.price}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Pricing Receipt Summary Card (4 cols) */}
          <div className="lg:col-span-4 bg-white border-2 border-slate-200 rounded-3xl p-6 shadow-xl sticky top-24 space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <span className="text-[10px] font-black uppercase tracking-widest text-sky-800 block">
                Estimated Quotation
              </span>
              <h3 className="font-extrabold text-lg text-slate-900">{currentService.title}</h3>
              <span className="text-xs text-slate-500">{propertySize}, {bathrooms} {bathrooms === 1 ? 'Bath' : 'Baths'}</span>
            </div>

            {/* Itemized Calculation */}
            <div className="space-y-2 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Base Service Rate:</span>
                <span className="font-semibold text-slate-900">£{pricing.basePrice.toFixed(2)}</span>
              </div>

              {(pricing.bedroomSurcharge > 0 || pricing.bathroomSurcharge > 0) && (
                <div className="flex justify-between">
                  <span>Room Size Factor:</span>
                  <span className="font-semibold text-slate-900">+£{(pricing.bedroomSurcharge + pricing.bathroomSurcharge).toFixed(2)}</span>
                </div>
              )}

              {pricing.extrasTotal > 0 && (
                <div className="flex justify-between">
                  <span>Selected Extras ({selectedExtras.length}):</span>
                  <span className="font-semibold text-slate-900">+£{pricing.extrasTotal.toFixed(2)}</span>
                </div>
              )}

              {pricing.frequencyDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-bold">
                  <span>{frequency.toUpperCase()} Discount:</span>
                  <span>-£{pricing.frequencyDiscount.toFixed(2)}</span>
                </div>
              )}

              <div className="border-t border-slate-200 pt-3 flex justify-between items-baseline">
                <div>
                  <span className="text-xs text-slate-500 block">Total Est. Price</span>
                  <span className="text-3xl font-black text-slate-900 font-mono tracking-tight">
                    £{pricing.total.toFixed(2)}
                  </span>
                </div>
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                  Guaranteed Rate
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleBook}
              className="w-full py-4 bg-sky-700 hover:bg-sky-800 text-white rounded-2xl font-black text-sm uppercase tracking-wider shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
            >
              Book At This Price <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-[11px] text-slate-400 text-center space-y-1">
              <p>✓ All equipment & detergents included</p>
              <p>✓ Free cancellation up to 24h prior</p>
              <p>✓ Strictly vetted, background-checked cleaners</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
