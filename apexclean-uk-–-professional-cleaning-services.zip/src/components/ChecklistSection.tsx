import React, { useState } from 'react';
import { CheckCircle2, Sparkles, ShieldCheck } from 'lucide-react';

interface RoomChecklist {
  room: string;
  badge: string;
  tasks: string[];
}

const roomSpecs: RoomChecklist[] = [
  {
    room: 'Kitchen',
    badge: 'Hygiene Focus',
    tasks: [
      'Wipe and sanitise all kitchen worktops and splashbacks',
      'Clean hob, extractor fan filters, and exterior cooker knobs',
      'Deep clean sink, descaling taps and polishing chrome',
      'Clean outside of oven, fridge, microwave, and dishwasher',
      'Wipe down all cupboard door fronts and drawer handles',
      'Empty bins, replace liners, and disinfect bin exterior',
      'Vacuum, wash and mop hard floors'
    ]
  },
  {
    room: 'Bathrooms & Toilets',
    badge: 'Anti-Limescale & Sanitisation',
    tasks: [
      'Disinfect, descale, and scrub toilet bowl inside and out',
      'Scrub bath tub, shower enclosure, and clean drain trap',
      'Remove soap scum and hard water stains from glass screens',
      'Clean and polish wash basins and shiny chrome taps',
      'Wipe down tile grout surfaces and medicine cabinets',
      'Polish all vanity mirrors until crystal clear streak-free',
      'Disinfect tiled floors and wipe skirting boards'
    ]
  },
  {
    room: 'Bedrooms',
    badge: 'Dust & Freshness',
    tasks: [
      'Dust all flat surfaces, bedside tables, wardrobes, and lamps',
      'Change bed linen and make beds (fresh linen laid out)',
      'Vacuum mattresses and under accessible bed frames',
      'Dust picture frames, window sills, and curtain poles',
      'Clean internal mirror wardrobes and dressing tables',
      'Empty waste baskets and tidy light clutter',
      'Thoroughly vacuum carpets or damp-mop hard flooring'
    ]
  },
  {
    room: 'Living & Dining Rooms',
    badge: 'Detail & Comfort',
    tasks: [
      'Dust TV screens, electronics, tables, and bookshelves',
      'Vacuum sofas, under removable cushions, and fabric chairs',
      'Dust blinds, window sills, and polish glass coffee tables',
      'Wipe down dining table, chairs, and light switch plates',
      'Wipe skirting boards and clean door touch-points',
      'Vacuum carpets edge-to-edge or damp mop wood floors'
    ]
  },
  {
    room: 'Hallways & Staircases',
    badge: 'First Impressions',
    tasks: [
      'Vacuum staircase runner, steps, and risers thoroughly',
      'Dust banisters, spindles, handrails, and radiator covers',
      'Wipe front door interior and porch entry mats',
      'Polish hallway mirrors and entryway console tables',
      'Sanitise high-traffic door handles and light switches'
    ]
  },
  {
    room: 'General Across All Rooms',
    badge: 'Standard Included',
    tasks: [
      'Cobweb removal from ceilings and high corners',
      'Dusting of doors, doorframes, and skirting boards',
      'Emptying of all household waste receptacles',
      'Eco-friendly and pet-safe detergents used as standard',
      'Final visual checklist inspection before sign-off'
    ]
  }
];

export function ChecklistSection() {
  const [activeTab, setActiveTab] = useState(0);
  const currentRoom = roomSpecs[activeTab];

  return (
    <section id="checklist" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200">
      <div className="max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-2">
            <ShieldCheck className="w-3.5 h-3.5" /> 50-Point Standard
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Our Room-By-Room Cleaning Specification
          </h2>
          <p className="text-slate-600 text-sm mt-2">
            Nothing is missed. Review our thorough inspection checklist designed to keep UK homes impeccably hygienic.
          </p>
        </div>

        {/* Room Navigation Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {roomSpecs.map((item, idx) => (
            <button
              key={item.room}
              type="button"
              onClick={() => setActiveTab(idx)}
              className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                activeTab === idx
                  ? 'bg-sky-700 text-white shadow-md'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              <span>{item.room}</span>
            </button>
          ))}
        </div>

        {/* Room Card Checklist */}
        <div className="bg-slate-50 border-2 border-slate-200 rounded-3xl p-6 sm:p-10 shadow-sm max-w-4xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-4 mb-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-sky-800">
                {currentRoom.badge}
              </span>
              <h3 className="text-2xl font-black text-slate-900 mt-0.5">
                {currentRoom.room} Cleaning Checklist
              </h3>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold bg-white px-3 py-1.5 rounded-xl border border-slate-200">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>{currentRoom.tasks.length} Comprehensive Steps</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {currentRoom.tasks.map((task, i) => (
              <div key={i} className="flex items-start gap-3 p-3 bg-white rounded-2xl border border-slate-200/80 shadow-2xs">
                <div className="p-1 bg-emerald-100 text-emerald-700 rounded-full shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <span className="text-xs font-medium text-slate-800 leading-snug">{task}</span>
              </div>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
            <p>
              Need additional specialist additions like oven lining, fridge de-frosting or carpet shampooing?
            </p>
            <span className="font-bold text-sky-800 whitespace-nowrap">
              Optional Extras can be added with 1-click at checkout
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
