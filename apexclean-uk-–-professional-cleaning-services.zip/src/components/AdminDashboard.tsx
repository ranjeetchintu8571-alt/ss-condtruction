import React, { useState } from 'react';
import { 
  Booking, 
  Cleaner, 
  PricingRules, 
  VatSettings, 
  ServiceAreaConfig, 
  BusinessHoursDay, 
  FAQ, 
  Review, 
  PromoCode, 
  WebsiteContent, 
  QuoteRequest, 
  ContactMessage,
  ServiceExtra,
  Service,
  SpecialOffer,
  AvailabilityBlock
} from '../types';
import { DataStore } from '../services/store';
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  Tag, 
  Settings, 
  FileText, 
  MapPin, 
  Clock, 
  Percent, 
  HelpCircle, 
  Star, 
  Edit, 
  Plus, 
  Trash2, 
  Check, 
  X, 
  Search, 
  ArrowUpRight, 
  ShieldCheck, 
  Eye, 
  DollarSign,
  Briefcase,
  Layers,
  MessageSquare
} from 'lucide-react';

export function AdminDashboard({ onClose, onOpenInvoice }: { onClose: () => void; onOpenInvoice: (b: Booking) => void }) {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'bookings' | 'cleaners' | 'pricing' | 'service-areas' | 'business-hours' | 'calendar' | 'cms' | 'faqs' | 'reviews' | 'promos' | 'enquiries'
  >('overview');

  // Reactive state
  const [bookings, setBookings] = useState<Booking[]>(DataStore.getBookings());
  const [cleaners, setCleaners] = useState<Cleaner[]>(DataStore.getCleaners());
  const [pricingRules, setPricingRules] = useState<PricingRules>(DataStore.getPricingRules());
  const [vatSettings, setVatSettings] = useState<VatSettings>(DataStore.getVatSettings());
  const [serviceArea, setServiceArea] = useState<ServiceAreaConfig>(DataStore.getServiceArea());
  const [businessHours, setBusinessHours] = useState<BusinessHoursDay[]>(DataStore.getBusinessHours());
  const [websiteContent, setWebsiteContent] = useState<WebsiteContent>(DataStore.getWebsiteContent());
  const [faqs, setFaqs] = useState<FAQ[]>(DataStore.getFaqs());
  const [reviews, setReviews] = useState<Review[]>(DataStore.getReviews());
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>(DataStore.getPromoCodes());
  const [quoteRequests, setQuoteRequests] = useState<QuoteRequest[]>(DataStore.getQuoteRequests());
  const [contactMessages, setContactMessages] = useState<ContactMessage[]>(DataStore.getContactMessages());
  const [extras, setExtras] = useState<ServiceExtra[]>(DataStore.getExtras());
  const [services, setServices] = useState<Service[]>(DataStore.getServices());
  const [specialOffer, setSpecialOffer] = useState<SpecialOffer>(DataStore.getSpecialOffer());
  const [availabilityBlocks, setAvailabilityBlocks] = useState<AvailabilityBlock[]>(DataStore.getAvailabilityBlocks());

  // Modal / Filter state
  const [bookingFilter, setBookingFilter] = useState<string>('all');
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [editingCleaner, setEditingCleaner] = useState<Cleaner | null>(null);
  const [showAddCleaner, setShowAddCleaner] = useState(false);
  const [showAddFaq, setShowAddFaq] = useState(false);
  const [showAddReview, setShowAddReview] = useState(false);
  const [showAddPromo, setShowAddPromo] = useState(false);
  const [showBlockDateModal, setShowBlockDateModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New item draft states
  const [newBlockDate, setNewBlockDate] = useState('');
  const [newBlockReason, setNewBlockReason] = useState('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Calculations for overview KPIs
  const totalRevenue = bookings.reduce((sum, b) => b.status !== 'Cancelled' ? sum + b.pricing.total : sum, 0);
  const pendingBookingsCount = bookings.filter(b => b.status === 'Pending').length;
  const completedBookingsCount = bookings.filter(b => b.status === 'Completed').length;
  const cancelledBookingsCount = bookings.filter(b => b.status === 'Cancelled').length;
  const upcomingBookingsCount = bookings.filter(b => b.status === 'Confirmed' || b.status === 'Cleaner Assigned').length;

  // Booking management handlers
  const handleUpdateBookingStatus = (bookingId: string, status: Booking['status'], cleanerId?: string) => {
    const cleaner = cleanerId ? cleaners.find(c => c.id === cleanerId) : undefined;
    DataStore.updateBooking(bookingId, {
      status,
      assignedCleanerId: cleanerId ?? undefined,
      assignedCleanerName: cleaner?.name ?? undefined
    });
    setBookings(DataStore.getBookings());
    showToast(`Booking ${status.toLowerCase()} successfully`);
  };

  const handleSavePricing = () => {
    DataStore.updatePricingRules(pricingRules);
    DataStore.updateVatSettings(vatSettings);
    showToast('Pricing and VAT settings saved');
  };

  const handleSaveCMS = () => {
    DataStore.updateWebsiteContent(websiteContent);
    DataStore.updateSpecialOffer(specialOffer);
    showToast('Website content updated successfully');
  };

  const handleSaveServiceArea = () => {
    DataStore.updateServiceArea(serviceArea);
    showToast('Service area configuration updated');
  };

  const handleSaveBusinessHours = () => {
    DataStore.updateBusinessHours(businessHours);
    showToast('Business hours saved');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
      <div className="bg-white rounded-3xl max-w-6xl w-full shadow-2xl border border-slate-200 overflow-hidden h-[95vh] flex flex-col">
        
        {/* Admin Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-sky-600 rounded-xl">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-sky-400">Admin Control Panel</span>
              <h2 className="text-lg font-black tracking-tight">{websiteContent.companyName} Administration</h2>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {toastMessage && (
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold rounded-lg animate-fade-in">
                ✓ {toastMessage}
              </span>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Exit Admin
            </button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar Navigation */}
          <div className="w-56 bg-slate-50 border-r border-slate-200 p-3 space-y-1 overflow-y-auto shrink-0 text-xs font-semibold text-slate-600">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'overview' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" /> Overview & KPIs
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('bookings')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition ${
                activeTab === 'bookings' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Calendar className="w-4 h-4" /> Bookings
              </span>
              {pendingBookingsCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-amber-400 text-slate-900 font-extrabold">
                  {pendingBookingsCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('cleaners')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'cleaners' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <Users className="w-4 h-4" /> Cleaners ({cleaners.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('pricing')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'pricing' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <DollarSign className="w-4 h-4" /> Pricing & VAT
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('service-areas')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'service-areas' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <MapPin className="w-4 h-4" /> Service Areas
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('business-hours')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'business-hours' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <Clock className="w-4 h-4" /> Business Hours
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('calendar')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'calendar' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <Calendar className="w-4 h-4" /> Blocked Dates
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('enquiries')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition ${
                activeTab === 'enquiries' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <MessageSquare className="w-4 h-4" /> Quotes & Queries
              </span>
              {quoteRequests.filter(q => q.status === 'New').length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-sky-400 text-slate-900 font-extrabold">
                  {quoteRequests.filter(q => q.status === 'New').length}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('promos')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'promos' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <Tag className="w-4 h-4" /> Promo Codes ({promoCodes.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('cms')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'cms' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <Edit className="w-4 h-4" /> Website CMS
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('faqs')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'faqs' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <HelpCircle className="w-4 h-4" /> FAQs ({faqs.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('reviews')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition ${
                activeTab === 'reviews' ? 'bg-sky-700 text-white font-bold' : 'hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              <Star className="w-4 h-4" /> Genuine Reviews ({reviews.length})
            </button>
          </div>

          {/* Main Tab Body */}
          <div className="flex-1 p-6 overflow-y-auto bg-white text-slate-800">
            
            {/* OVERVIEW TAB */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-black text-slate-900">Business Dashboard</h3>
                  <p className="text-xs text-slate-500">Live operational snapshot of UK bookings, cleaners, and revenue.</p>
                </div>

                {/* KPI Cards Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                    <span className="text-xs font-bold text-slate-500 block">Total Revenue</span>
                    <span className="text-2xl font-black text-slate-900 font-mono mt-1 block">£{totalRevenue.toFixed(2)}</span>
                    <span className="text-[11px] text-emerald-600 font-semibold">Active & Confirmed</span>
                  </div>
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                    <span className="text-xs font-bold text-slate-500 block">Pending Bookings</span>
                    <span className="text-2xl font-black text-amber-600 font-mono mt-1 block">{pendingBookingsCount}</span>
                    <span className="text-[11px] text-slate-500">Requires review</span>
                  </div>
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                    <span className="text-xs font-bold text-slate-500 block">Upcoming Cleanings</span>
                    <span className="text-2xl font-black text-sky-700 font-mono mt-1 block">{upcomingBookingsCount}</span>
                    <span className="text-[11px] text-sky-700 font-medium">Scheduled</span>
                  </div>
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                    <span className="text-xs font-bold text-slate-500 block">Completed Jobs</span>
                    <span className="text-2xl font-black text-emerald-700 font-mono mt-1 block">{completedBookingsCount}</span>
                    <span className="text-[11px] text-emerald-700 font-semibold">100% Quality Rate</span>
                  </div>
                </div>

                {/* Analytics & Metrics Visualizer */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Bookings by Frequency */}
                  <div className="p-5 border border-slate-200 rounded-2xl bg-slate-50/50">
                    <h4 className="font-bold text-sm text-slate-900 mb-3">Bookings by Frequency</h4>
                    <div className="space-y-2 text-xs">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium text-slate-700">Weekly Recurring (High LTV)</span>
                          <span className="font-bold text-slate-900">45%</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="bg-sky-600 h-2 rounded-full" style={{ width: '45%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium text-slate-700">One-Off & Deep Cleans</span>
                          <span className="font-bold text-slate-900">30%</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="bg-indigo-600 h-2 rounded-full" style={{ width: '30%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium text-slate-700">Fortnightly</span>
                          <span className="font-bold text-slate-900">18%</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="bg-emerald-600 h-2 rounded-full" style={{ width: '18%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium text-slate-700">Monthly</span>
                          <span className="font-bold text-slate-900">7%</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="bg-amber-600 h-2 rounded-full" style={{ width: '7%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Popular Services Breakdown */}
                  <div className="p-5 border border-slate-200 rounded-2xl bg-slate-50/50">
                    <h4 className="font-bold text-sm text-slate-900 mb-3">Popular UK Services</h4>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-200">
                        <span className="font-semibold text-slate-800">Regular Domestic Cleaning</span>
                        <span className="font-mono font-bold text-sky-800">From £45 • 42 bookings</span>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-200">
                        <span className="font-semibold text-slate-800">End of Tenancy Cleaning</span>
                        <span className="font-mono font-bold text-sky-800">From £145 • 28 bookings</span>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-200">
                        <span className="font-semibold text-slate-800">Deep Cleaning</span>
                        <span className="font-mono font-bold text-sky-800">From £110 • 19 bookings</span>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-200">
                        <span className="font-semibold text-slate-800">Commercial Office Cleaning</span>
                        <span className="font-mono font-bold text-sky-800">From £85 • 14 accounts</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Bookings Quick Table */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-bold text-sm text-slate-900">Recent Customer Bookings</h4>
                    <button 
                      type="button" 
                      onClick={() => setActiveTab('bookings')} 
                      className="text-xs font-bold text-sky-700 hover:underline"
                    >
                      View All Bookings →
                    </button>
                  </div>
                  <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                        <tr>
                          <th className="p-3">Ref</th>
                          <th className="p-3">Customer</th>
                          <th className="p-3">Service</th>
                          <th className="p-3">Date</th>
                          <th className="p-3">Total</th>
                          <th className="p-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {bookings.slice(0, 4).map(b => (
                          <tr key={b.id} className="hover:bg-slate-50">
                            <td className="p-3 font-mono font-bold text-sky-800">{b.reference}</td>
                            <td className="p-3 font-semibold text-slate-900">{b.customerName}</td>
                            <td className="p-3 text-slate-600">{b.serviceName}</td>
                            <td className="p-3 text-slate-600">{b.bookingDate}</td>
                            <td className="p-3 font-mono font-bold">£{b.pricing.total.toFixed(2)}</td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800">
                                {b.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* BOOKINGS MANAGEMENT TAB */}
            {activeTab === 'bookings' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-xl font-black text-slate-900">Booking Management</h3>
                    <p className="text-xs text-slate-500">Filter, approve, assign vetted cleaners, and update job statuses.</p>
                  </div>

                  {/* Filter Pills */}
                  <div className="flex flex-wrap gap-1 bg-slate-100 p-1 rounded-xl text-xs">
                    {['all', 'Pending', 'Confirmed', 'Cleaner Assigned', 'In Progress', 'Completed', 'Cancelled'].map(f => (
                      <button
                        key={f}
                        type="button"
                        onClick={() => setBookingFilter(f)}
                        className={`px-3 py-1 rounded-lg font-semibold transition ${
                          bookingFilter === f ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {f === 'all' ? 'All' : f}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Bookings List */}
                <div className="space-y-3">
                  {bookings
                    .filter(b => bookingFilter === 'all' || b.status === bookingFilter)
                    .map(b => (
                      <div key={b.id} className="p-4 border border-slate-200 rounded-2xl bg-white shadow-2xs">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-bold text-sky-900 bg-sky-50 px-2 py-0.5 rounded-md">
                                {b.reference}
                              </span>
                              <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-slate-100 text-slate-800">
                                {b.status}
                              </span>
                              <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md">
                                {b.paymentStatus}
                              </span>
                            </div>
                            <h4 className="font-bold text-slate-900 text-base mt-1">{b.serviceName}</h4>
                            <p className="text-xs text-slate-500">
                              {b.customerName} ({b.customerPhone} • {b.customerEmail})
                            </p>
                          </div>

                          <div className="text-right">
                            <span className="text-xl font-black font-mono text-slate-900">£{b.pricing.total.toFixed(2)}</span>
                            <span className="block text-xs text-slate-500">{b.bookingDate} ({b.timeSlot})</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 py-2.5 text-xs text-slate-600">
                          <div>
                            <strong className="text-slate-800">Property:</strong> {b.propertyType}, {b.propertySize}, {b.bathrooms} Bath
                          </div>
                          <div>
                            <strong className="text-slate-800">Location:</strong> {b.houseNumber} {b.address}, {b.postcode}
                          </div>
                          <div>
                            <strong className="text-slate-800">Cleaner:</strong> {b.assignedCleanerName || <span className="text-amber-700 font-bold">Unassigned</span>}
                          </div>
                        </div>

                        {b.accessInstructions && (
                          <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded-lg">
                            <strong>Access:</strong> {b.accessInstructions}
                          </p>
                        )}

                        {/* Admin Action Controls */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 text-xs">
                          {/* Cleaner Assignment Dropdown */}
                          <div className="flex items-center gap-2">
                            <label className="font-semibold text-slate-700">Assign Cleaner:</label>
                            <select
                              value={b.assignedCleanerId || ''}
                              onChange={(e) => handleUpdateBookingStatus(b.id, 'Cleaner Assigned', e.target.value)}
                              className="p-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                            >
                              <option value="">-- Choose Cleaner --</option>
                              {cleaners.map(c => (
                                <option key={c.id} value={c.id}>{c.name} ({c.status})</option>
                              ))}
                            </select>
                          </div>

                          <div className="flex items-center gap-1.5">
                            {b.status === 'Pending' && (
                              <button
                                type="button"
                                onClick={() => handleUpdateBookingStatus(b.id, 'Confirmed')}
                                className="px-3 py-1.5 bg-sky-700 hover:bg-sky-800 text-white rounded-lg font-bold"
                              >
                                Accept Booking
                              </button>
                            )}

                            <select
                              value={b.status}
                              onChange={(e) => handleUpdateBookingStatus(b.id, e.target.value as Booking['status'])}
                              className="p-1.5 border border-slate-300 rounded-lg text-xs font-semibold"
                            >
                              <option value="Pending">Pending</option>
                              <option value="Confirmed">Confirmed</option>
                              <option value="Cleaner Assigned">Cleaner Assigned</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Completed">Completed</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>

                            <button
                              type="button"
                              onClick={() => onOpenInvoice(b)}
                              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold flex items-center gap-1"
                            >
                              <FileText className="w-3.5 h-3.5" /> Invoice
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* CLEANER MANAGEMENT TAB */}
            {activeTab === 'cleaners' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-black text-slate-900">Cleaner Management</h3>
                    <p className="text-xs text-slate-500">Manage vetted cleaners, skills, active duty status, and working hours.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddCleaner(!showAddCleaner)}
                    className="px-4 py-2 bg-sky-700 text-white rounded-xl text-xs font-bold hover:bg-sky-800 transition flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add New Cleaner
                  </button>
                </div>

                {showAddCleaner && (
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const formData = new FormData(form);
                      DataStore.addCleaner({
                        userId: `user-cln-${Date.now()}`,
                        name: formData.get('name') as string,
                        phone: formData.get('phone') as string,
                        email: formData.get('email') as string,
                        serviceAreas: (formData.get('areas') as string).split(',').map(s => s.trim()),
                        skills: ['Residential', 'Deep Cleaning'],
                        availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
                        workingHours: formData.get('hours') as string || '08:00 – 17:00',
                        status: 'Available'
                      });
                      setCleaners(DataStore.getCleaners());
                      setShowAddCleaner(false);
                      showToast('New cleaner operative added');
                    }}
                    className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 text-xs"
                  >
                    <h4 className="font-bold text-slate-900 text-sm">Add New Cleaning Operative</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input name="name" required placeholder="Cleaner Full Name" className="p-2 border rounded-xl bg-white" />
                      <input name="phone" required placeholder="UK Phone (07700...)" className="p-2 border rounded-xl bg-white" />
                      <input name="email" required type="email" placeholder="cleaner@example.co.uk" className="p-2 border rounded-xl bg-white" />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input name="areas" placeholder="Service Postcodes (e.g. SW, SE, W)" className="p-2 border rounded-xl bg-white" />
                      <input name="hours" placeholder="Working Hours (e.g. 08:30 – 17:00)" className="p-2 border rounded-xl bg-white" />
                    </div>
                    <button type="submit" className="px-4 py-2 bg-sky-700 text-white font-bold rounded-xl">Save Cleaner</button>
                  </form>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {cleaners.map(c => (
                    <div key={c.id} className="p-4 border border-slate-200 rounded-2xl bg-white space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-bold text-slate-900 text-base">{c.name}</h4>
                          <p className="text-xs text-slate-500">{c.email} • {c.phone}</p>
                        </div>
                        <select
                          value={c.status}
                          onChange={(e) => {
                            DataStore.updateCleaner(c.id, { status: e.target.value as Cleaner['status'] });
                            setCleaners(DataStore.getCleaners());
                          }}
                          className={`p-1 text-xs font-bold rounded-lg border ${
                            c.status === 'Available' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' :
                            c.status === 'Busy' ? 'bg-amber-50 text-amber-800 border-amber-300' : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          <option value="Available">Available</option>
                          <option value="Busy">Busy</option>
                          <option value="Off Duty">Off Duty</option>
                        </select>
                      </div>

                      <div className="text-xs text-slate-600">
                        <p><strong>Areas:</strong> {c.serviceAreas.join(', ')}</p>
                        <p><strong>Hours:</strong> {c.workingHours}</p>
                        <p><strong>Rating:</strong> {c.rating} ★ ({c.completedJobsCount} jobs completed)</p>
                      </div>

                      <div className="flex flex-wrap gap-1 pt-1">
                        {c.skills.map((skill, i) => (
                          <span key={i} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[10px] font-semibold">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* DYNAMIC PRICING & VAT TAB */}
            {activeTab === 'pricing' && (
              <div className="space-y-6 max-w-2xl">
                <div>
                  <h3 className="text-xl font-black text-slate-900">Dynamic Pricing Engine & VAT</h3>
                  <p className="text-xs text-slate-500">Configure base service prices, bedroom/bathroom costs, frequency discounts, and UK tax settings.</p>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 text-xs">
                  <h4 className="font-bold text-slate-900 text-sm">Room & Property Dimension Surcharges (£ GBP)</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Additional Bedroom Price (£)</label>
                      <input
                        type="number"
                        value={pricingRules.bedroomPrice}
                        onChange={(e) => setPricingRules({ ...pricingRules, bedroomPrice: Number(e.target.value) })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Additional Bathroom Price (£)</label>
                      <input
                        type="number"
                        value={pricingRules.bathroomPrice}
                        onChange={(e) => setPricingRules({ ...pricingRules, bathroomPrice: Number(e.target.value) })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Weekend Surcharge (£)</label>
                      <input
                        type="number"
                        value={pricingRules.weekendSurcharge}
                        onChange={(e) => setPricingRules({ ...pricingRules, weekendSurcharge: Number(e.target.value) })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Min. Booking Amount (£)</label>
                      <input
                        type="number"
                        value={pricingRules.minimumBookingAmount}
                        onChange={(e) => setPricingRules({ ...pricingRules, minimumBookingAmount: Number(e.target.value) })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Travel Fee (£)</label>
                      <input
                        type="number"
                        value={pricingRules.travelFee}
                        onChange={(e) => setPricingRules({ ...pricingRules, travelFee: Number(e.target.value) })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>
                </div>

                {/* Recurring Frequency Discounts */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 text-xs">
                  <h4 className="font-bold text-slate-900 text-sm">Recurring Frequency Discounts (%)</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Weekly Discount (%)</label>
                      <input
                        type="number"
                        value={pricingRules.frequencyDiscounts.weekly}
                        onChange={(e) => setPricingRules({
                          ...pricingRules,
                          frequencyDiscounts: { ...pricingRules.frequencyDiscounts, weekly: Number(e.target.value) }
                        })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Fortnightly Discount (%)</label>
                      <input
                        type="number"
                        value={pricingRules.frequencyDiscounts.fortnightly}
                        onChange={(e) => setPricingRules({
                          ...pricingRules,
                          frequencyDiscounts: { ...pricingRules.frequencyDiscounts, fortnightly: Number(e.target.value) }
                        })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Monthly Discount (%)</label>
                      <input
                        type="number"
                        value={pricingRules.frequencyDiscounts.monthly}
                        onChange={(e) => setPricingRules({
                          ...pricingRules,
                          frequencyDiscounts: { ...pricingRules.frequencyDiscounts, monthly: Number(e.target.value) }
                        })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>
                </div>

                {/* VAT / Tax Settings (Section 26) */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 text-sm">UK VAT / Tax Settings</h4>
                    <label className="flex items-center gap-2 font-semibold text-slate-800 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={vatSettings.enabled}
                        onChange={(e) => setVatSettings({ ...vatSettings, enabled: e.target.checked })}
                        className="rounded text-sky-600 w-4 h-4"
                      />
                      <span>VAT Registered Business</span>
                    </label>
                  </div>

                  {vatSettings.enabled && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">VAT Percentage (%)</label>
                        <input
                          type="number"
                          value={vatSettings.percentage}
                          onChange={(e) => setVatSettings({ ...vatSettings, percentage: Number(e.target.value) })}
                          className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">VAT Number</label>
                        <input
                          type="text"
                          value={vatSettings.vatNumber || ''}
                          onChange={(e) => setVatSettings({ ...vatSettings, vatNumber: e.target.value })}
                          className="w-full p-2 bg-white border border-slate-300 rounded-xl uppercase font-semibold"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Price Inclusivity</label>
                        <select
                          value={vatSettings.pricesIncludeVat ? 'include' : 'exclude'}
                          onChange={(e) => setVatSettings({ ...vatSettings, pricesIncludeVat: e.target.value === 'include' })}
                          className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                        >
                          <option value="include">Prices include VAT</option>
                          <option value="exclude">Prices exclude VAT (Add at checkout)</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleSavePricing}
                  className="px-6 py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-bold rounded-xl text-xs transition"
                >
                  Save Pricing & VAT Configuration
                </button>
              </div>
            )}

            {/* SERVICE AREAS TAB */}
            {activeTab === 'service-areas' && (
              <div className="space-y-4 max-w-2xl text-xs">
                <div>
                  <h3 className="text-xl font-black text-slate-900">UK Service Area Configuration</h3>
                  <p className="text-slate-500">Configure which UK postcodes and regions are permitted for automatic booking.</p>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                  <label className="flex items-center gap-2 font-bold text-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={serviceArea.allowNationwide}
                      onChange={(e) => setServiceArea({ ...serviceArea, allowNationwide: e.target.checked })}
                      className="rounded text-sky-600 w-4 h-4"
                    />
                    <span>Allow Any Valid UK Postcode (Nationwide Coverage)</span>
                  </label>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Allowed Postcode Outcode Prefixes (comma separated)
                    </label>
                    <textarea
                      rows={3}
                      value={serviceArea.allowedPostcodePrefixes.join(', ')}
                      onChange={(e) => setServiceArea({
                        ...serviceArea,
                        allowedPostcodePrefixes: e.target.value.split(',').map(s => s.trim().toUpperCase()).filter(Boolean)
                      })}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-mono uppercase font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Key Cities / Hubs</label>
                    <input
                      type="text"
                      value={serviceArea.cities.join(', ')}
                      onChange={(e) => setServiceArea({
                        ...serviceArea,
                        cities: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      })}
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Custom Notice for Out-of-Area Enquiries</label>
                    <input
                      type="text"
                      value={serviceArea.customNotice}
                      onChange={(e) => setServiceArea({ ...serviceArea, customNotice: e.target.value })}
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleSaveServiceArea}
                    className="px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-bold rounded-xl transition"
                  >
                    Save Service Area Settings
                  </button>
                </div>
              </div>
            )}

            {/* BUSINESS HOURS TAB */}
            {activeTab === 'business-hours' && (
              <div className="space-y-4 max-w-xl text-xs">
                <div>
                  <h3 className="text-xl font-black text-slate-900">Operating Business Hours</h3>
                  <p className="text-slate-500">Configure daily opening and closing hours. Booking system will enforce these.</p>
                </div>

                <div className="space-y-2">
                  {businessHours.map((bh, idx) => (
                    <div key={bh.day} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                      <div className="w-28 font-bold text-slate-900">{bh.day}</div>
                      <label className="flex items-center gap-1.5 font-semibold text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={bh.open}
                          onChange={(e) => {
                            const updated = [...businessHours];
                            updated[idx].open = e.target.checked;
                            setBusinessHours(updated);
                          }}
                          className="rounded text-sky-600"
                        />
                        <span>{bh.open ? 'Open' : 'Closed'}</span>
                      </label>
                      {bh.open ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="time"
                            value={bh.openTime}
                            onChange={(e) => {
                              const updated = [...businessHours];
                              updated[idx].openTime = e.target.value;
                              setBusinessHours(updated);
                            }}
                            className="p-1 bg-white border rounded text-center"
                          />
                          <span>to</span>
                          <input
                            type="time"
                            value={bh.closeTime}
                            onChange={(e) => {
                              const updated = [...businessHours];
                              updated[idx].closeTime = e.target.value;
                              setBusinessHours(updated);
                            }}
                            className="p-1 bg-white border rounded text-center"
                          />
                        </div>
                      ) : (
                        <span className="text-slate-400 font-semibold italic">Closed to new bookings</span>
                      )}
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleSaveBusinessHours}
                  className="px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-bold rounded-xl transition"
                >
                  Save Business Hours
                </button>
              </div>
            )}

            {/* BLOCKED CALENDAR DATES */}
            {activeTab === 'calendar' && (
              <div className="space-y-4 max-w-xl text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-black text-slate-900">Availability & Blocked Dates</h3>
                    <p className="text-slate-500">Block specific holidays or maintenance days from customer booking.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowBlockDateModal(true)}
                    className="px-3.5 py-2 bg-sky-700 text-white rounded-xl font-bold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Block a Date
                  </button>
                </div>

                {showBlockDateModal && (
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                    <h4 className="font-bold text-slate-900">Block Specific Date</h4>
                    <input
                      type="date"
                      value={newBlockDate}
                      onChange={(e) => setNewBlockDate(e.target.value)}
                      className="p-2 border rounded-xl bg-white w-full"
                    />
                    <input
                      type="text"
                      placeholder="Reason (e.g. Bank Holiday, Staff Training)"
                      value={newBlockReason}
                      onChange={(e) => setNewBlockReason(e.target.value)}
                      className="p-2 border rounded-xl bg-white w-full"
                    />
                    <div className="flex justify-end gap-2">
                      <button onClick={() => setShowBlockDateModal(false)} className="px-3 py-1.5 bg-slate-200 rounded-lg">Cancel</button>
                      <button
                        onClick={() => {
                          if (newBlockDate) {
                            DataStore.addAvailabilityBlock(newBlockDate, newBlockReason || 'Closed');
                            setAvailabilityBlocks(DataStore.getAvailabilityBlocks());
                            setShowBlockDateModal(false);
                            setNewBlockDate('');
                            setNewBlockReason('');
                            showToast('Date blocked successfully');
                          }
                        }}
                        className="px-4 py-1.5 bg-sky-700 text-white font-bold rounded-lg"
                      >
                        Add Block
                      </button>
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  {availabilityBlocks.length === 0 ? (
                    <p className="text-slate-500 italic p-4 bg-slate-50 rounded-xl">No custom blocked dates. Standard business hours apply.</p>
                  ) : (
                    availabilityBlocks.map(b => (
                      <div key={b.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                        <div>
                          <strong className="text-slate-900">{b.date}</strong>
                          <span className="text-slate-500 ml-2">({b.reason})</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            DataStore.removeAvailabilityBlock(b.id);
                            setAvailabilityBlocks(DataStore.getAvailabilityBlocks());
                          }}
                          className="text-rose-600 hover:text-rose-800 font-bold"
                        >
                          Remove
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* QUOTES & ENQUIRIES TAB */}
            {activeTab === 'enquiries' && (
              <div className="space-y-6 text-xs">
                <div>
                  <h3 className="text-xl font-black text-slate-900">Quotes & Contact Messages</h3>
                  <p className="text-slate-500">Inbound custom quote requests and contact form submissions.</p>
                </div>

                <div>
                  <h4 className="font-bold text-sm text-slate-900 mb-2">Quote Requests ({quoteRequests.length})</h4>
                  <div className="space-y-3">
                    {quoteRequests.map(q => (
                      <div key={q.id} className="p-4 border border-slate-200 rounded-2xl bg-white space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-bold text-slate-900 text-sm">{q.name}</span>
                            <span className="text-slate-500 ml-2">({q.email} • {q.phone})</span>
                          </div>
                          <select
                            value={q.status}
                            onChange={(e) => {
                              DataStore.updateQuoteStatus(q.id, e.target.value as QuoteRequest['status']);
                              setQuoteRequests(DataStore.getQuoteRequests());
                            }}
                            className="p-1 border rounded-lg font-semibold text-xs"
                          >
                            <option value="New">New</option>
                            <option value="Reviewed">Reviewed</option>
                            <option value="Quoted">Quoted</option>
                            <option value="Closed">Closed</option>
                          </select>
                        </div>
                        <p className="text-slate-700"><strong>Service:</strong> {q.serviceName} • {q.propertyType} • {q.propertySize} • Postcode: <span className="font-mono font-bold uppercase">{q.postcode}</span></p>
                        <p className="text-slate-600 bg-slate-50 p-2 rounded-lg">"{q.message}"</p>
                        {q.uploadedFiles && q.uploadedFiles.length > 0 && (
                          <div className="flex gap-2 text-[11px] text-sky-800">
                            <strong>Files Attached:</strong>
                            {q.uploadedFiles.map((f, i) => (
                              <span key={i} className="underline">{f.name} ({f.size})</span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <h4 className="font-bold text-sm text-slate-900 mb-2">Contact Form Messages ({contactMessages.length})</h4>
                  <div className="space-y-2">
                    {contactMessages.map(m => (
                      <div key={m.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                        <div className="flex items-center justify-between">
                          <strong>{m.name} ({m.email})</strong>
                          <span className="text-[10px] text-slate-400 font-mono">{m.postcode}</span>
                        </div>
                        <p className="text-slate-700">"{m.message}"</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* WEBSITE CMS CONTENT TAB (Section 2 & 31) */}
            {activeTab === 'cms' && (
              <div className="space-y-4 max-w-2xl text-xs">
                <div>
                  <h3 className="text-xl font-black text-slate-900">Website Content CMS</h3>
                  <p className="text-slate-500">Edit all company placeholders and content dynamically without code changes.</p>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Company Name</label>
                      <input
                        type="text"
                        value={websiteContent.companyName}
                        onChange={(e) => setWebsiteContent({ ...websiteContent, companyName: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl font-bold"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Tagline</label>
                      <input
                        type="text"
                        value={websiteContent.tagline}
                        onChange={(e) => setWebsiteContent({ ...websiteContent, tagline: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Phone Number</label>
                      <input
                        type="text"
                        value={websiteContent.phone}
                        onChange={(e) => setWebsiteContent({ ...websiteContent, phone: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Email Address</label>
                      <input
                        type="email"
                        value={websiteContent.email}
                        onChange={(e) => setWebsiteContent({ ...websiteContent, email: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Opening Hours String</label>
                      <input
                        type="text"
                        value={websiteContent.openingHours}
                        onChange={(e) => setWebsiteContent({ ...websiteContent, openingHours: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Service Area Display String</label>
                      <input
                        type="text"
                        value={websiteContent.serviceArea}
                        onChange={(e) => setWebsiteContent({ ...websiteContent, serviceArea: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Physical Company Address</label>
                      <input
                        type="text"
                        value={websiteContent.address}
                        onChange={(e) => setWebsiteContent({ ...websiteContent, address: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>

                  {/* Fully Insured Toggle as mandated in Section 4: "ONLY if enabled by admin" */}
                  <div className="p-3 bg-white border border-slate-200 rounded-xl">
                    <label className="flex items-center gap-2 font-bold text-slate-900 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={websiteContent.isFullyInsured}
                        onChange={(e) => setWebsiteContent({ ...websiteContent, isFullyInsured: e.target.checked })}
                        className="rounded text-sky-600 w-4 h-4"
                      />
                      <span>Fully Insured Trust Badge Enabled (Do not claim insurance unless configured)</span>
                    </label>
                  </div>

                  {/* Hero Headlines */}
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Hero Main Headline</label>
                    <input
                      type="text"
                      value={websiteContent.heroHeadline}
                      onChange={(e) => setWebsiteContent({ ...websiteContent, heroHeadline: e.target.value })}
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl font-bold"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Hero Subheading</label>
                    <input
                      type="text"
                      value={websiteContent.heroSubheading}
                      onChange={(e) => setWebsiteContent({ ...websiteContent, heroSubheading: e.target.value })}
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                    />
                  </div>

                  {/* Special Offer Banner Controls */}
                  <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sky-950">Promotional Banner / Top Offer</span>
                      <label className="flex items-center gap-1.5 text-xs font-semibold cursor-pointer">
                        <input
                          type="checkbox"
                          checked={specialOffer.enabled}
                          onChange={(e) => setSpecialOffer({ ...specialOffer, enabled: e.target.checked })}
                          className="rounded text-sky-600"
                        />
                        <span>Banner Active</span>
                      </label>
                    </div>
                    <input
                      type="text"
                      value={specialOffer.title}
                      onChange={(e) => setSpecialOffer({ ...specialOffer, title: e.target.value })}
                      placeholder="Title"
                      className="w-full p-2 bg-white border rounded-xl"
                    />
                    <input
                      type="text"
                      value={specialOffer.description}
                      onChange={(e) => setSpecialOffer({ ...specialOffer, description: e.target.value })}
                      placeholder="Description"
                      className="w-full p-2 bg-white border rounded-xl"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleSaveCMS}
                    className="px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-bold rounded-xl transition"
                  >
                    Save CMS Changes
                  </button>
                </div>
              </div>
            )}

            {/* FAQS MANAGER TAB (Section 20) */}
            {activeTab === 'faqs' && (
              <div className="space-y-4 max-w-2xl text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-black text-slate-900">FAQ Management</h3>
                    <p className="text-slate-500">Add, edit, or delete customer questions and answers.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddFaq(!showAddFaq)}
                    className="px-3.5 py-2 bg-sky-700 text-white rounded-xl font-bold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add FAQ
                  </button>
                </div>

                {showAddFaq && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const formData = new FormData(form);
                      DataStore.addFaq({
                        question: formData.get('question') as string,
                        answer: formData.get('answer') as string,
                        category: formData.get('category') as string || 'General',
                        order: faqs.length + 1
                      });
                      setFaqs(DataStore.getFaqs());
                      setShowAddFaq(false);
                      showToast('FAQ added');
                    }}
                    className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2"
                  >
                    <input name="question" required placeholder="Question..." className="w-full p-2 border rounded-xl bg-white" />
                    <textarea name="answer" required rows={2} placeholder="Answer..." className="w-full p-2 border rounded-xl bg-white" />
                    <button type="submit" className="px-4 py-1.5 bg-sky-700 text-white font-bold rounded-xl">Save FAQ</button>
                  </form>
                )}

                <div className="space-y-2">
                  {faqs.map(faq => (
                    <div key={faq.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                      <div className="flex items-center justify-between">
                        <strong className="text-slate-900 text-sm">{faq.question}</strong>
                        <button
                          type="button"
                          onClick={() => {
                            DataStore.deleteFaq(faq.id);
                            setFaqs(DataStore.getFaqs());
                          }}
                          className="text-rose-600 hover:text-rose-800"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-slate-600">{faq.answer}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* REVIEWS MANAGER TAB (Section 21) */}
            {activeTab === 'reviews' && (
              <div className="space-y-4 max-w-2xl text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-black text-slate-900">Genuine Reviews Manager</h3>
                    <p className="text-slate-500">Per specification: No fake reviews are invented. Add verified customer reviews manually here.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddReview(!showAddReview)}
                    className="px-3.5 py-2 bg-sky-700 text-white rounded-xl font-bold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Genuine Review
                  </button>
                </div>

                {showAddReview && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const formData = new FormData(form);
                      DataStore.addReview({
                        customerName: formData.get('name') as string,
                        reviewText: formData.get('review') as string,
                        rating: Number(formData.get('rating') || 5),
                        date: new Date().toISOString().split('T')[0],
                        serviceName: formData.get('service') as string || 'House Cleaning',
                        verified: true,
                        active: true
                      });
                      setReviews(DataStore.getReviews());
                      setShowAddReview(false);
                      showToast('Genuine review added');
                    }}
                    className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2"
                  >
                    <div className="grid grid-cols-2 gap-2">
                      <input name="name" required placeholder="Customer Name" className="p-2 border rounded-xl bg-white" />
                      <input name="service" placeholder="Service (e.g. End of Tenancy)" className="p-2 border rounded-xl bg-white" />
                    </div>
                    <textarea name="review" required rows={2} placeholder="Customer's actual review text..." className="w-full p-2 border rounded-xl bg-white" />
                    <button type="submit" className="px-4 py-1.5 bg-sky-700 text-white font-bold rounded-xl">Save Review</button>
                  </form>
                )}

                <div className="space-y-2">
                  {reviews.length === 0 ? (
                    <div className="p-6 border border-dashed border-slate-200 rounded-2xl text-center text-slate-500 bg-slate-50">
                      "Customer reviews will appear here." (No fake reviews are generated).
                    </div>
                  ) : (
                    reviews.map(r => (
                      <div key={r.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                        <div>
                          <strong>{r.customerName}</strong> • {r.serviceName} ({r.rating} ★)
                          <p className="text-slate-600 mt-1">"{r.reviewText}"</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            DataStore.deleteReview(r.id);
                            setReviews(DataStore.getReviews());
                          }}
                          className="text-rose-600 hover:text-rose-800"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* PROMO CODES TAB (Section 23) */}
            {activeTab === 'promos' && (
              <div className="space-y-4 max-w-2xl text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-black text-slate-900">Promotional Discount Codes</h3>
                    <p className="text-slate-500">Create discount coupons validated dynamically during customer checkout.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddPromo(!showAddPromo)}
                    className="px-3.5 py-2 bg-sky-700 text-white rounded-xl font-bold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Create Promo Code
                  </button>
                </div>

                {showAddPromo && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const formData = new FormData(form);
                      DataStore.addPromoCode({
                        code: (formData.get('code') as string).toUpperCase(),
                        discountType: formData.get('type') as 'percentage' | 'fixed',
                        discountValue: Number(formData.get('value')),
                        minBookingAmount: Number(formData.get('min') || 0),
                        active: true
                      });
                      setPromoCodes(DataStore.getPromoCodes());
                      setShowAddPromo(false);
                      showToast('Promo code created');
                    }}
                    className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2"
                  >
                    <div className="grid grid-cols-2 gap-2">
                      <input name="code" required placeholder="Code (e.g. CLEAN20)" className="p-2 border rounded-xl bg-white font-mono uppercase font-bold" />
                      <select name="type" className="p-2 border rounded-xl bg-white">
                        <option value="fixed">Fixed (£ GBP off)</option>
                        <option value="percentage">Percentage (% off)</option>
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <input name="value" required type="number" placeholder="Discount Amount (e.g. 15)" className="p-2 border rounded-xl bg-white" />
                      <input name="min" type="number" placeholder="Min Booking (£)" className="p-2 border rounded-xl bg-white" />
                    </div>
                    <button type="submit" className="px-4 py-1.5 bg-sky-700 text-white font-bold rounded-xl">Save Promo Code</button>
                  </form>
                )}

                <div className="space-y-2">
                  {promoCodes.map(p => (
                    <div key={p.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="font-mono font-bold text-sky-800 text-sm">{p.code}</span>
                        <span className="text-slate-600 ml-2">
                          ({p.discountType === 'fixed' ? `£${p.discountValue} OFF` : `${p.discountValue}% OFF`}) • Min £{p.minBookingAmount} • Used {p.usageCount} times
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            DataStore.updatePromoCode(p.id, { active: !p.active });
                            setPromoCodes(DataStore.getPromoCodes());
                          }}
                          className={`px-2.5 py-1 rounded-lg font-bold text-[11px] ${
                            p.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                          }`}
                        >
                          {p.active ? 'Active' : 'Disabled'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            DataStore.deletePromoCode(p.id);
                            setPromoCodes(DataStore.getPromoCodes());
                          }}
                          className="text-rose-600 hover:text-rose-800"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}
