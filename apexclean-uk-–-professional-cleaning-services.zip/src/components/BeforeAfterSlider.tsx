import React, { useState, useRef } from 'react';
import { Sparkles } from 'lucide-react';

interface BeforeAfterItem {
  id: string;
  title: string;
  category: string;
  beforeImage: string;
  afterImage: string;
  description: string;
}

const comparisons: BeforeAfterItem[] = [
  {
    id: 'oven',
    title: 'Oven & Range Cooker Deep Clean',
    category: 'Kitchen Specialists',
    beforeImage: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=800&q=80',
    afterImage: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80',
    description: 'Removing years of baked-on grease, carbon deposits, and glass clouding without harsh toxic fumes.'
  },
  {
    id: 'bathroom',
    title: 'Limescale & Tile Grout Restoration',
    category: 'Bathroom Hygiene',
    beforeImage: 'https://images.unsplash.com/photo-1584622781564-1d987f7333c1?auto=format&fit=crop&w=800&q=80',
    afterImage: 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&w=800&q=80',
    description: 'Descaling taps, removing shower screen water stains, and disinfecting all high-touch sanitised surfaces.'
  },
  {
    id: 'living',
    title: 'End of Tenancy Full Property Handover',
    category: 'Tenancy Deposit Standard',
    beforeImage: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
    afterImage: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
    description: 'Guaranteed to meet strict inventory checkout criteria for UK estate agents and landlords.'
  }
];

export function BeforeAfterSlider() {
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeItem = comparisons[selectedIdx];

  const handleMove = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const pos = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(pos);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    handleMove(e.touches[0].clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (e.buttons === 1) { // dragging
      handleMove(e.clientX);
    }
  };

  return (
    <div className="bg-slate-50/70 py-16 px-4 sm:px-6 lg:px-8 border-y border-slate-200">
      <div className="max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" /> High Standards in Action
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            See The Transformation
          </h2>
          <p className="text-slate-600 text-sm mt-2">
            Slide horizontally to compare real property results achieved by our vetted cleaning specialists.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {comparisons.map((c, i) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setSelectedIdx(i);
                setSliderPosition(50);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                selectedIdx === i 
                  ? 'bg-sky-700 text-white shadow-sm' 
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              {c.title}
            </button>
          ))}
        </div>

        {/* Interactive Comparison Viewer */}
        <div className="max-w-3xl mx-auto">
          <div 
            ref={containerRef}
            onMouseMove={handleMouseMove}
            onTouchMove={handleTouchMove}
            onClick={(e) => handleMove(e.clientX)}
            className="relative h-72 sm:h-96 w-full rounded-3xl overflow-hidden shadow-xl select-none cursor-ew-resize border border-slate-300"
          >
            {/* After Image (Full background) */}
            <img 
              src={activeItem.afterImage} 
              alt="After Cleaning" 
              className="absolute inset-0 w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 right-4 bg-emerald-700 text-white font-black text-xs px-3 py-1 rounded-full shadow-md">
              AFTER (Cleaned)
            </div>

            {/* Before Image (Clipped by slider width) */}
            <div 
              className="absolute inset-y-0 left-0 overflow-hidden"
              style={{ width: `${sliderPosition}%` }}
            >
              <img 
                src={activeItem.beforeImage} 
                alt="Before Cleaning" 
                className="absolute inset-0 w-full h-full object-cover max-w-none"
                style={{ width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%' }}
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 left-4 bg-slate-900/80 text-white font-black text-xs px-3 py-1 rounded-full shadow-md">
                BEFORE
              </div>
            </div>

            {/* Drag Handle Divider */}
            <div 
              className="absolute top-0 bottom-0 w-1 bg-white shadow-2xl flex items-center justify-center pointer-events-none"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="w-8 h-8 rounded-full bg-white text-slate-800 shadow-xl border-2 border-sky-600 flex items-center justify-center font-bold text-xs">
                ↔
              </div>
            </div>
          </div>

          <div className="mt-4 text-center">
            <h4 className="font-bold text-base text-slate-900">{activeItem.title}</h4>
            <p className="text-xs text-slate-500 max-w-xl mx-auto mt-1">
              {activeItem.description}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
