import React, { useState, useEffect } from 'react';
import { 
  Service, 
  PropertyType, 
  PropertySize, 
  CleaningFrequency, 
  Booking,
  ServiceExtra
} from '../types';
import { DataStore } from '../services/store';
import { 
  Check, 
  ChevronRight, 
  ChevronLeft, 
  X, 
  Calendar as CalendarIcon, 
  Clock, 
  Home, 
  Sparkles, 
  CreditCard, 
  ShieldCheck, 
  FileText, 
  AlertCircle,
  Tag,
  Building,
  CheckCircle2,
  Info
} from 'lucide-react';

interface BookingWizardProps {
  isOpen: boolean;
  onClose: () => void;
  prefilledServiceId?: string;
  prefilledPostcode?: string;
  prefilledPropertyType?: PropertyType;
  prefilledDate?: string;
  prefilledTimeSlot?: string;
  prefilledFrequency?: CleaningFrequency;
  onBookingComplete?: (booking: Booking) => void;
  onOpenInvoice?: (booking: Booking) => void;
}

export function BookingWizardModal({
  isOpen,
  onClose,
  prefilledServiceId,
  prefilledPostcode,
  prefilledPropertyType,
  prefilledDate,
  prefilledTimeSlot,
  prefilledFrequency,
  onBookingComplete,
  onOpenInvoice
}: BookingWizardProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [services, setServices] = useState<Service[]>([]);
  const [extrasList, setExtrasList] = useState<ServiceExtra[]>([]);
  
  // Step 1: Service
  const [selectedServiceId, setSelectedServiceId] = useState<string>('srv-regular');
  // Step 2: Property Type
  const [propertyType, setPropertyType] = useState<PropertyType>('House');
  // Step 3: Property Size
  const [propertySize, setPropertySize] = useState<PropertySize>('2 Bedrooms');
  const [bathrooms, setBathrooms] = useState<number>(1);
  // Step 4: Frequency
  const [frequency, setFrequency] = useState<CleaningFrequency>('weekly');
  // Step 5: Extras
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);
  // Step 6: Date
  const [selectedDate, setSelectedDate] = useState<string>('');
  // Step 7: Time Slot
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('09:00 – 12:00');
  // Step 8: Customer Details
  const [fullName, setFullName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [postcode, setPostcode] = useState<string>('');
  const [addressLine, setAddressLine] = useState<string>('');
  const [houseNumber, setHouseNumber] = useState<string>('');
  const [accessInstructions, setAccessInstructions] = useState<string>('');
  const [specialInstructions, setSpecialInstructions] = useState<string>('');
  const [postcodeError, setPostcodeError] = useState<string>('');

  // Step 9: Payment & Promo
  const [promoCodeInput, setPromoCodeInput] = useState<string>('');
  const [promoMessage, setPromoMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [appliedPromo, setAppliedPromo] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'completion'>('card');
  const [cardNumber, setCardNumber] = useState<string>('•••• •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState<string>('12/28');
  const [cardCvc, setCardCvc] = useState<string>('•••');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Step 10: Completed Booking State
  const [completedBooking, setCompletedBooking] = useState<Booking | null>(null);

  useEffect(() => {
    if (isOpen) {
      setServices(DataStore.getServices().filter(s => s.active));
      setExtrasList(DataStore.getExtras().filter(e => e.active));
      if (prefilledServiceId) setSelectedServiceId(prefilledServiceId);
      if (prefilledPostcode) {
        setPostcode(prefilledPostcode);
        const check = DataStore.validatePostcode(prefilledPostcode);
        if (!check.isValid) setPostcodeError(check.message || '');
      }
      if (prefilledPropertyType) setPropertyType(prefilledPropertyType);
      if (prefilledFrequency) setFrequency(prefilledFrequency);
      if (prefilledDate) setSelectedDate(prefilledDate);
      if (prefilledTimeSlot) setSelectedTimeSlot(prefilledTimeSlot);

      // default date to tomorrow if not set
      if (!prefilledDate && !selectedDate) {
        const tomorrow = new Date(Date.now() + 86400000);
        setSelectedDate(tomorrow.toISOString().split('T')[0]);
      }
    }
  }, [isOpen, prefilledServiceId, prefilledPostcode, prefilledPropertyType, prefilledFrequency, prefilledDate, prefilledTimeSlot]);

  if (!isOpen) return null;

  const currentService = services.find(s => s.id === selectedServiceId) || services[0];

  // Dynamic pricing calculation
  const pricing = DataStore.calculatePricing({
    serviceId: selectedServiceId,
    propertyType,
    propertySize,
    bathrooms,
    frequency,
    selectedExtraIds: selectedExtras,
    date: selectedDate,
    promoCode: appliedPromo
  });

  const vatSettings = DataStore.getVatSettings();

  // Validate step progression
  const canProceed = () => {
    if (currentStep === 1) return !!selectedServiceId;
    if (currentStep === 2) return !!propertyType;
    if (currentStep === 3) return !!propertySize && bathrooms > 0;
    if (currentStep === 4) return !!frequency;
    if (currentStep === 5) return true; // extras are optional
    if (currentStep === 6) {
      if (!selectedDate) return false;
      const dayCheck = DataStore.isDayOpen(selectedDate);
      return dayCheck.isOpen;
    }
    if (currentStep === 7) return !!selectedTimeSlot;
    if (currentStep === 8) {
      const isPostcodeValid = DataStore.validatePostcode(postcode).isValid;
      return (
        fullName.trim().length > 1 &&
        email.includes('@') &&
        phone.trim().length >= 8 &&
        isPostcodeValid &&
        addressLine.trim().length > 2 &&
        houseNumber.trim().length > 0
      );
    }
    return true;
  };

  const handlePostcodeBlur = () => {
    if (!postcode) return;
    const res = DataStore.validatePostcode(postcode);
    if (!res.isValid) {
      setPostcodeError(res.message || 'We currently do not cover this area.');
    } else {
      setPostcodeError('');
      setPostcode(res.cleanPostcode);
    }
  };

  const handleApplyPromo = () => {
    if (!promoCodeInput.trim()) return;
    const check = DataStore.validatePromoCode(promoCodeInput, pricing.subtotal, selectedServiceId);
    if (check.isValid) {
      setAppliedPromo(check.promo?.code || promoCodeInput);
      setPromoMessage({ type: 'success', text: `Promo code applied! You save £${check.discount}` });
    } else {
      setPromoMessage({ type: 'error', text: check.message || 'Invalid code' });
    }
  };

  const handleConfirmBooking = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      const selectedExtrasObjects = selectedExtras.map(id => {
        const ext = extrasList.find(e => e.id === id);
        return { extraId: id, title: ext?.title || '', price: ext?.price || 0 };
      });

      const newBooking = DataStore.createBooking({
        customerName: fullName,
        customerEmail: email,
        customerPhone: phone,
        serviceId: selectedServiceId,
        serviceName: currentService?.title || 'Cleaning Service',
        propertyType,
        propertySize,
        bathrooms,
        frequency,
        selectedExtras: selectedExtrasObjects,
        bookingDate: selectedDate,
        timeSlot: selectedTimeSlot,
        address: addressLine,
        houseNumber,
        postcode: postcode.toUpperCase(),
        accessInstructions,
        specialInstructions,
        pricing,
        status: 'Confirmed',
        paymentStatus: paymentMethod === 'card' ? 'Paid' : 'Pay on Completion',
        paymentMethod: paymentMethod === 'card' ? 'Card Payment (Online)' : 'Pay on Completion'
      });

      setCompletedBooking(newBooking);
      setIsSubmitting(false);
      setCurrentStep(10);
      if (onBookingComplete) onBookingComplete(newBooking);
    }, 600);
  };

  const toggleExtra = (extraId: string) => {
    setSelectedExtras(prev => 
      prev.includes(extraId) ? prev.filter(id => id !== extraId) : [...prev, extraId]
    );
  };

  const timeSlots = [
    { label: 'Morning', time: '08:30 – 11:30', badge: 'Popular' },
    { label: 'Midday', time: '12:00 – 15:00', badge: 'Standard' },
    { label: 'Afternoon', time: '15:30 – 18:30', badge: 'Standard' },
    { label: 'Evening', time: '18:30 – 21:00', badge: 'Commercial / After Hours' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 flex flex-col max-h-[92vh] overflow-hidden my-auto">
        
        {/* Top Header & Progress Bar */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-sky-600 animate-pulse"></span>
              <span className="text-xs font-bold uppercase tracking-wider text-sky-900">
                UK Booking System • Step {currentStep} of 10
              </span>
            </div>
            <h3 className="font-extrabold text-lg text-slate-900">
              {currentStep === 1 && 'Select Your Cleaning Service'}
              {currentStep === 2 && 'What Type of Property Is It?'}
              {currentStep === 3 && 'Property Size & Bathrooms'}
              {currentStep === 4 && 'How Often Do You Need Us?'}
              {currentStep === 5 && 'Tailor With Optional Extras'}
              {currentStep === 6 && 'Select Your Preferred Date'}
              {currentStep === 7 && 'Choose an Available Time Slot'}
              {currentStep === 8 && 'Your Address & Access Details'}
              {currentStep === 9 && 'Order Summary & Checkout'}
              {currentStep === 10 && 'Booking Confirmed!'}
            </h3>
          </div>
          <button 
            type="button"
            onClick={onClose} 
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-xl transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Visual Progress Line */}
        <div className="w-full bg-slate-100 h-1.5">
          <div 
            className="bg-sky-600 h-1.5 transition-all duration-300 rounded-r-full"
            style={{ width: `${(currentStep / 10) * 100}%` }}
          />
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto flex-1 text-slate-800">

          {/* STEP 1: SELECT SERVICE */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-500">
                Choose the service tailored to your requirements. All services are performed by trusted, professional cleaners.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {services.map((srv) => (
                  <div
                    key={srv.id}
                    onClick={() => setSelectedServiceId(srv.id)}
                    className={`p-4 rounded-2xl border-2 transition cursor-pointer flex flex-col justify-between ${
                      selectedServiceId === srv.id 
                        ? 'border-sky-600 bg-sky-50/50 shadow-sm ring-2 ring-sky-600/10' 
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <h4 className="font-bold text-slate-900 text-sm">{srv.title}</h4>
                        <span className="text-xs font-bold text-sky-700 bg-sky-100 px-2 py-0.5 rounded-full">
                          From £{srv.startingPrice}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-2">{srv.shortDescription}</p>
                    </div>
                    <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <span>Est. {srv.estimatedDuration}</span>
                      {selectedServiceId === srv.id && (
                        <span className="font-bold text-sky-700 flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" /> Selected
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: PROPERTY TYPE */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-500">
                Select your property type so we can allocate the right team and cleaning supplies.
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {(['House', 'Flat/Apartment', 'Studio', 'Office', 'Shop', 'Other'] as PropertyType[]).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setPropertyType(type)}
                    className={`p-4 rounded-2xl border-2 text-center transition flex flex-col items-center gap-2 cursor-pointer ${
                      propertyType === type
                        ? 'border-sky-600 bg-sky-50 text-sky-900 font-bold shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                    }`}
                  >
                    <Building className="w-6 h-6 text-sky-700" />
                    <span className="text-sm">{type}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 3: PROPERTY SIZE & BATHROOMS */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-slate-900 mb-2">Number of Bedrooms</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {(['Studio', '1 Bedroom', '2 Bedrooms', '3 Bedrooms', '4 Bedrooms', '5+ Bedrooms'] as PropertySize[]).map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setPropertySize(size)}
                      className={`p-3 rounded-xl border text-sm font-medium transition cursor-pointer ${
                        propertySize === size
                          ? 'border-sky-600 bg-sky-600 text-white font-bold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700 bg-white'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-900 mb-2">Number of Bathrooms</label>
                <div className="grid grid-cols-4 gap-2.5">
                  {[1, 2, 3, 4].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setBathrooms(num)}
                      className={`p-3 rounded-xl border text-sm font-medium transition cursor-pointer ${
                        bathrooms === num
                          ? 'border-sky-600 bg-sky-600 text-white font-bold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700 bg-white'
                      }`}
                    >
                      {num === 4 ? '4+ Baths' : `${num} ${num === 1 ? 'Bath' : 'Baths'}`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: CLEANING FREQUENCY */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-500">
                Recurring schedules benefit from dedicated cleaners, automated reservations, and continuous discounts.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { id: 'weekly', title: 'Weekly', discount: 'Save 15%', desc: 'Most popular for busy households and regular tidy-ups' },
                  { id: 'fortnightly', title: 'Fortnightly', discount: 'Save 10%', desc: 'Every 2 weeks. Great balance of freshness and value' },
                  { id: 'monthly', title: 'Monthly', discount: 'Save 5%', desc: 'Once a month top-up maintenance clean' },
                  { id: 'one-off', title: 'One-Off Clean', discount: 'Standard Rate', desc: 'No ongoing commitment, single deep refresh' }
                ].map((item) => (
                  <div
                    key={item.id}
                    onClick={() => setFrequency(item.id as CleaningFrequency)}
                    className={`p-4 rounded-2xl border-2 transition cursor-pointer ${
                      frequency === item.id 
                        ? 'border-sky-600 bg-sky-50 shadow-sm' 
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-900 text-base">{item.title}</span>
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        item.id === 'one-off' ? 'bg-slate-100 text-slate-600' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {item.discount}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 5: EXTRAS */}
          {currentStep === 5 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-500">
                Select any extra specialist additions you would like your cleaners to complete.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {extrasList.map((extra) => {
                  const isSelected = selectedExtras.includes(extra.id);
                  return (
                    <div
                      key={extra.id}
                      onClick={() => toggleExtra(extra.id)}
                      className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                        isSelected 
                          ? 'border-sky-600 bg-sky-50/70 text-slate-900 font-semibold' 
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700 bg-white'
                      }`}
                    >
                      <div className="flex-1 pr-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold">{extra.title}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 line-clamp-1">{extra.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-sky-800">+£{extra.price}</span>
                        <div className={`w-5 h-5 rounded-md flex items-center justify-center border ${
                          isSelected ? 'bg-sky-600 border-sky-600 text-white' : 'border-slate-300'
                        }`}>
                          {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 6: DATE PICKER */}
          {currentStep === 6 && (
            <div className="space-y-4 max-w-md mx-auto text-center">
              <p className="text-sm text-slate-500">
                Select your preferred clean appointment date. We operate Monday through Saturday.
              </p>
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                  Select Date
                </label>
                <input
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full p-3 bg-white border border-slate-300 rounded-xl text-slate-900 font-bold text-center text-base focus:ring-2 focus:ring-sky-500 outline-none"
                />
                {selectedDate && !DataStore.isDayOpen(selectedDate).isOpen && (
                  <div className="mt-3 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2 text-left">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>We are closed on this day. Please choose another date (Monday – Saturday).</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 7: TIME SLOTS */}
          {currentStep === 7 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-500">
                Choose an arrival window. Our cleaners arrive promptly within your chosen slot.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {timeSlots.map((slot) => (
                  <button
                    key={slot.time}
                    type="button"
                    onClick={() => setSelectedTimeSlot(slot.time)}
                    className={`p-4 rounded-2xl border-2 transition text-left cursor-pointer ${
                      selectedTimeSlot === slot.time
                        ? 'border-sky-600 bg-sky-50 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-900 text-sm">{slot.label}</span>
                      <span className="text-[11px] font-semibold text-sky-800 bg-sky-100 px-2 py-0.5 rounded-full">
                        {slot.badge}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium mt-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{slot.time}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 8: CUSTOMER DETAILS & ADDRESS */}
          {currentStep === 8 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Eleanor Vance"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-sky-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="eleanor@example.co.uk"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-sky-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number (UK) *</label>
                  <input
                    type="tel"
                    required
                    placeholder="07700 900000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-sky-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">UK Postcode *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. SW1A 1AA"
                    value={postcode}
                    onChange={(e) => {
                      setPostcode(e.target.value);
                      setPostcodeError('');
                    }}
                    onBlur={handlePostcodeBlur}
                    className={`w-full p-2.5 bg-white border rounded-xl text-sm focus:ring-2 focus:ring-sky-500 outline-none uppercase font-semibold ${
                      postcodeError ? 'border-rose-400 bg-rose-50/50' : 'border-slate-300'
                    }`}
                  />
                  {postcodeError && (
                    <p className="text-xs text-rose-600 mt-1 font-medium">{postcodeError}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <label className="block text-xs font-bold text-slate-700 mb-1">House/Flat No. *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Flat 3B"
                    value={houseNumber}
                    onChange={(e) => setHouseNumber(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-sky-500 outline-none"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Street Address *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. High Street, Kensington"
                    value={addressLine}
                    onChange={(e) => setAddressLine(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-sky-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Access Instructions (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Key in lockbox by back door (code 1234) or concierge desk"
                  value={accessInstructions}
                  onChange={(e) => setAccessInstructions(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-sky-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Special Instructions / Focus Areas (Optional)</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Please pay special attention to oven glass and lime-scale on shower screen"
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-sky-500 outline-none resize-none"
                />
              </div>
            </div>
          )}

          {/* STEP 9: PRICE SUMMARY & CHECKOUT */}
          {currentStep === 9 && (
            <div className="space-y-6">
              {/* Itemized Order Review */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-xs">
                <h4 className="font-bold text-sm text-slate-900 border-b border-slate-200 pb-2">
                  Order Summary
                </h4>
                
                <div className="flex justify-between text-slate-700">
                  <span>{currentService.title} ({propertySize}, {bathrooms} {bathrooms === 1 ? 'Bathroom' : 'Bathrooms'})</span>
                  <span className="font-semibold">£{(pricing.basePrice + pricing.bedroomSurcharge + pricing.bathroomSurcharge).toFixed(2)}</span>
                </div>

                {pricing.extrasTotal > 0 && (
                  <div className="flex justify-between text-slate-700">
                    <span>Selected Extras ({selectedExtras.length} items)</span>
                    <span className="font-semibold">£{pricing.extrasTotal.toFixed(2)}</span>
                  </div>
                )}

                {pricing.weekendSurcharge > 0 && (
                  <div className="flex justify-between text-slate-700">
                    <span>Weekend Surcharge</span>
                    <span className="font-semibold">£{pricing.weekendSurcharge.toFixed(2)}</span>
                  </div>
                )}

                {pricing.frequencyDiscount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Recurring Frequency Discount ({frequency})</span>
                    <span>-£{pricing.frequencyDiscount.toFixed(2)}</span>
                  </div>
                )}

                {pricing.promoDiscount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Promo Code ({pricing.promoCodeUsed})</span>
                    <span>-£{pricing.promoDiscount.toFixed(2)}</span>
                  </div>
                )}

                {vatSettings.enabled && (
                  <div className="flex justify-between text-slate-500 text-[11px]">
                    <span>VAT ({vatSettings.percentage}% {vatSettings.pricesIncludeVat ? 'included' : 'added'})</span>
                    <span>£{pricing.vatAmount.toFixed(2)}</span>
                  </div>
                )}

                <div className="border-t border-slate-200 pt-2 flex justify-between items-center text-sm font-black text-slate-900">
                  <span>Total Amount</span>
                  <span className="text-sky-800 text-lg font-mono">£{pricing.total.toFixed(2)}</span>
                </div>
              </div>

              {/* Promo Code Box */}
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter Promo Code (e.g. WELCOME15)"
                  value={promoCodeInput}
                  onChange={(e) => setPromoCodeInput(e.target.value.toUpperCase())}
                  className="flex-1 p-2.5 bg-white border border-slate-300 rounded-xl text-xs uppercase font-bold tracking-wider outline-none"
                />
                <button
                  type="button"
                  onClick={handleApplyPromo}
                  className="px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-900 transition cursor-pointer"
                >
                  Apply Code
                </button>
              </div>
              {promoMessage && (
                <p className={`text-xs font-medium ${promoMessage.type === 'success' ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {promoMessage.text}
                </p>
              )}

              {/* Payment Method Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-900 mb-2">Payment Option</label>
                <div className="grid grid-cols-2 gap-3">
                  <div
                    onClick={() => setPaymentMethod('card')}
                    className={`p-3 rounded-xl border-2 transition cursor-pointer flex items-center gap-2 ${
                      paymentMethod === 'card' ? 'border-sky-600 bg-sky-50' : 'border-slate-200 bg-white'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-sky-700" />
                    <div>
                      <p className="text-xs font-bold text-slate-900">Pay Online by Card</p>
                      <p className="text-[10px] text-slate-500">Secure encrypted checkout</p>
                    </div>
                  </div>

                  <div
                    onClick={() => setPaymentMethod('completion')}
                    className={`p-3 rounded-xl border-2 transition cursor-pointer flex items-center gap-2 ${
                      paymentMethod === 'completion' ? 'border-sky-600 bg-sky-50' : 'border-slate-200 bg-white'
                    }`}
                  >
                    <FileText className="w-4 h-4 text-sky-700" />
                    <div>
                      <p className="text-xs font-bold text-slate-900">Pay on Completion</p>
                      <p className="text-[10px] text-slate-500">Card or bank transfer on day</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card Inputs (if card selected) */}
              {paymentMethod === 'card' && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                    <span>Card Details</span>
                    <span className="text-emerald-700 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> 256-Bit SSL Encrypted
                    </span>
                  </div>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    placeholder="Card Number"
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      placeholder="MM/YY"
                      className="p-2.5 bg-white border border-slate-300 rounded-xl text-xs text-center font-mono"
                    />
                    <input
                      type="text"
                      value={cardCvc}
                      onChange={(e) => setCardCvc(e.target.value)}
                      placeholder="CVC"
                      className="p-2.5 bg-white border border-slate-300 rounded-xl text-xs text-center font-mono"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 10: CONFIRMATION */}
          {currentStep === 10 && completedBooking && (
            <div className="text-center py-4 space-y-4">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                  Confirmed & Scheduled
                </span>
                <h3 className="text-2xl font-black text-slate-900 mt-1">Thank You, {completedBooking.customerName}!</h3>
                <p className="text-xs text-slate-600 mt-1">
                  A confirmation email and SMS notification have been generated for your records.
                </p>
              </div>

              {/* Reference Card */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl max-w-md mx-auto text-left space-y-2 text-xs">
                <div className="flex justify-between border-b border-slate-200 pb-2">
                  <span className="text-slate-500 font-medium">Booking Reference:</span>
                  <span className="font-mono font-bold text-sky-800 text-sm">{completedBooking.reference}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Service:</span>
                  <span className="font-bold text-slate-800">{completedBooking.serviceName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Date & Time:</span>
                  <span className="font-semibold text-slate-800">{completedBooking.bookingDate} ({completedBooking.timeSlot})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Location:</span>
                  <span className="font-medium text-slate-800">{completedBooking.houseNumber} {completedBooking.address}, {completedBooking.postcode}</span>
                </div>
                <div className="flex justify-between border-t border-slate-200 pt-2 font-bold text-slate-900 text-sm">
                  <span>Total Paid:</span>
                  <span className="text-sky-800">£{completedBooking.pricing.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex flex-wrap justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (onOpenInvoice) onOpenInvoice(completedBooking);
                  }}
                  className="px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-4 h-4" /> Download Official Invoice / Receipt
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        {currentStep < 10 && (
          <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={() => setCurrentStep(prev => prev - 1)}
                className="px-4 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" /> Back
              </button>
            ) : (
              <div></div>
            )}

            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-600 hidden sm:inline">
                Est: £{pricing.total.toFixed(2)}
              </span>

              {currentStep < 9 ? (
                <button
                  type="button"
                  disabled={!canProceed()}
                  onClick={() => setCurrentStep(prev => prev + 1)}
                  className={`px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                    canProceed()
                      ? 'bg-sky-700 hover:bg-sky-800 text-white shadow-sm'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  Continue <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  disabled={isSubmitting || !canProceed()}
                  onClick={handleConfirmBooking}
                  className="px-6 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-2 cursor-pointer"
                >
                  {isSubmitting ? 'Confirming...' : `Confirm & Book (£${pricing.total.toFixed(2)})`}
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
