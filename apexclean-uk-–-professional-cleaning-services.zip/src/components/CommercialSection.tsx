import React from 'react';
import { Building2, Clock, ShieldCheck, Briefcase, FileSpreadsheet, ArrowRight, Check } from 'lucide-react';

export function CommercialSection({ onOpenQuoteModal }: { onOpenQuoteModal: () => void }) {
  return (
    <section id="commercial" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Text & Features (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 text-sky-400 text-xs font-bold uppercase tracking-wider">
              <Building2 className="w-3.5 h-3.5" /> B2B Commercial Contracts
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight leading-tight">
              Professional Cleaning Solutions for UK Workplaces & Commercial Facilities
            </h2>

            <p className="text-slate-600 text-sm leading-relaxed">
              From boutique co-working spaces and high-traffic corporate offices to retail showrooms, medical clinics, and educational hubs — we deliver immaculate workplace hygiene tailored around your operational hours.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
                <div className="flex items-center gap-2 text-sky-900 font-bold text-sm">
                  <Clock className="w-4 h-4 text-sky-700" />
                  <span>Out-of-Hours Flexibility</span>
                </div>
                <p className="text-xs text-slate-500">
                  Early morning (06:00), evening, or overnight schedules so your staff and clients are never interrupted.
                </p>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
                <div className="flex items-center gap-2 text-sky-900 font-bold text-sm">
                  <ShieldCheck className="w-4 h-4 text-sky-700" />
                  <span>COSHH & Health Safety</span>
                </div>
                <p className="text-xs text-slate-500">
                  Full health & safety documentation, RAMS, COSHH safety sheets, and strict cross-contamination protocols.
                </p>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
                <div className="flex items-center gap-2 text-sky-900 font-bold text-sm">
                  <Briefcase className="w-4 h-4 text-sky-700" />
                  <span>Dedicated Account Manager</span>
                </div>
                <p className="text-xs text-slate-500">
                  Single point of contact, regular site quality audits, monthly consolidated invoicing, and rapid cover.
                </p>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
                <div className="flex items-center gap-2 text-sky-900 font-bold text-sm">
                  <FileSpreadsheet className="w-4 h-4 text-sky-700" />
                  <span>Consolidated Invoicing</span>
                </div>
                <p className="text-xs text-slate-500">
                  VAT compliant itemised monthly billing with 30-day payment terms for approved corporate entities.
                </p>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={onOpenQuoteModal}
                className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs font-black uppercase tracking-wider shadow-lg transition flex items-center gap-2 cursor-pointer"
              >
                Request a Custom Commercial Site Quote <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Image Showcase Card (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="rounded-3xl overflow-hidden shadow-2xl border-4 border-slate-100 relative">
              <img
                src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80"
                alt="Modern UK Office Cleaning"
                className="w-full h-96 object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
                <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 rounded-full text-xs font-bold inline-block">
                  ✓ Vetted Corporate Cleaners
                </span>
                <h4 className="text-xl font-bold">Trusted by Offices, Studios & Retailers</h4>
                <p className="text-xs text-slate-200">
                  Daily, weekly, or fortnightly cleaning regimes custom-designed for productivity.
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
