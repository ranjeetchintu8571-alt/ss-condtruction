import React from 'react';
import { Invoice } from '../types';
import { Printer, Download, X, CheckCircle, ShieldCheck } from 'lucide-react';

export function InvoiceModal({
  invoice,
  isOpen,
  onClose
}: {
  invoice: Invoice | null;
  isOpen: boolean;
  onClose: () => void;
}) {
  if (!isOpen || !invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Modal Toolbar (hidden when printed) */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-2.5 py-1 bg-sky-100 text-sky-800 rounded-full">
              Official UK Invoice / Receipt
            </span>
            <span className="text-xs text-slate-500">{invoice.invoiceNumber}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 shadow-sm transition"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Invoice Body (styled for screen and print) */}
        <div className="p-8 text-slate-800 font-sans" id="printable-invoice">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-sky-600 flex items-center justify-center text-white font-bold text-lg shadow-sm">
                  ✓
                </div>
                <h2 className="text-2xl font-black tracking-tight text-slate-900">{invoice.companyName}</h2>
              </div>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">{invoice.companyAddress}</p>
              {invoice.companyVatNumber && (
                <p className="text-xs text-slate-600 font-medium mt-0.5">VAT Reg: {invoice.companyVatNumber}</p>
              )}
            </div>

            <div className="sm:text-right">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Invoice / Receipt</span>
              <h3 className="text-xl font-bold text-slate-900 mt-0.5">{invoice.invoiceNumber}</h3>
              <p className="text-xs text-slate-500 mt-1">Date: {invoice.date}</p>
              <p className="text-xs text-slate-500">Ref: <span className="font-mono font-bold text-slate-800">{invoice.bookingReference}</span></p>
              <div className="mt-2 inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                <CheckCircle className="w-3 h-3" />
                {invoice.paymentStatus.toUpperCase()}
              </div>
            </div>
          </div>

          {/* Billed To / Property Address */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 py-6 border-b border-slate-100 text-xs">
            <div>
              <span className="font-bold text-slate-400 uppercase tracking-wider">Billed To</span>
              <p className="font-bold text-sm text-slate-900 mt-1">{invoice.customerName}</p>
              <p className="text-slate-600 mt-0.5">{invoice.customerEmail}</p>
            </div>
            <div>
              <span className="font-bold text-slate-400 uppercase tracking-wider">Service Location</span>
              <p className="text-slate-800 font-medium mt-1">{invoice.customerAddress}</p>
              <p className="text-slate-800 font-bold uppercase">{invoice.customerPostcode}</p>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="py-6">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 uppercase font-bold tracking-wider">
                  <th className="pb-3 font-semibold">Description</th>
                  <th className="pb-3 text-center font-semibold">Qty</th>
                  <th className="pb-3 text-right font-semibold">Unit Price</th>
                  <th className="pb-3 text-right font-semibold">Total (£)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoice.items.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-3 font-medium text-slate-800">{item.description}</td>
                    <td className="py-3 text-center text-slate-500">{item.quantity}</td>
                    <td className="py-3 text-right text-slate-600">£{item.unitPrice.toFixed(2)}</td>
                    <td className="py-3 text-right font-bold text-slate-900">£{item.total.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals Breakdown */}
          <div className="border-t border-slate-200 pt-4 flex flex-col items-end text-xs space-y-1.5">
            <div className="w-64 flex justify-between text-slate-600">
              <span>Subtotal:</span>
              <span className="font-semibold">£{invoice.subtotal.toFixed(2)}</span>
            </div>

            {invoice.discount > 0 && (
              <div className="w-64 flex justify-between text-emerald-600">
                <span>Discount Applied:</span>
                <span className="font-semibold">-£{invoice.discount.toFixed(2)}</span>
              </div>
            )}

            {invoice.vatAmount > 0 && (
              <div className="w-64 flex justify-between text-slate-600">
                <span>VAT ({invoice.vatRate}%):</span>
                <span className="font-semibold">£{invoice.vatAmount.toFixed(2)}</span>
              </div>
            )}

            <div className="w-64 flex justify-between text-base font-black text-slate-900 border-t border-slate-200 pt-2">
              <span>Total Paid:</span>
              <span className="text-sky-700 font-mono">£{invoice.total.toFixed(2)}</span>
            </div>
          </div>

          {/* Footer Note */}
          <div className="mt-8 pt-6 border-t border-slate-100 text-center text-[11px] text-slate-400 space-y-1">
            <p className="font-medium text-slate-600">Payment Method: {invoice.paymentMethod}</p>
            <p>Thank you for choosing {invoice.companyName}. For any billing enquiries, please contact support with your booking reference.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
