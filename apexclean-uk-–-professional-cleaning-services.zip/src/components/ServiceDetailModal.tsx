import React from 'react';
import { Service } from '../types';
import { X, Check, Clock, Users, PlusCircle, HelpCircle, ArrowRight, ShieldCheck } from 'lucide-react';

export function ServiceDetailModal({
  service,
  isOpen,
  onClose,
  onBookNow
}: {
  service: Service | null;
  isOpen: boolean;
  onClose: () => void;
  onBookNow: (serviceId: string) => void;
}) {
  if (!isOpen || !service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Hero Image Header */}
        <div className="relative h-48 sm:h-56 w-full overflow-hidden bg-slate-100 shrink-0">
          <img
            src={service.imageUrl}
            alt={service.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent"></div>
          
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-slate-900/60 hover:bg-slate-900 text-white rounded-full backdrop-blur-sm transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-4 left-6 right-6 text-white">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-sky-600 text-white">
              {service.category}
            </span>
            <h2 className="text-2xl font-black mt-1 tracking-tight">{service.title}</h2>
            <div className="flex items-center gap-4 text-xs text-slate-200 mt-1">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-sky-400" /> {service.estimatedDuration}
              </span>
              <span>•</span>
              <span className="font-bold text-sky-300">From £{service.startingPrice}</span>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-700">
          {/* Description */}
          <div>
            <h3 className="font-bold text-slate-900 text-base mb-1">Service Overview</h3>
            <p className="leading-relaxed text-slate-600 text-xs sm:text-sm">
              {service.fullDescription}
            </p>
          </div>

          {/* Ideal For */}
          {service.idealFor.length > 0 && (
            <div className="p-4 bg-sky-50/60 border border-sky-100 rounded-2xl">
              <div className="flex items-center gap-2 text-sky-900 font-bold text-xs uppercase tracking-wider mb-2">
                <Users className="w-4 h-4 text-sky-700" />
                <span>Ideal For</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {service.idealFor.map((item, idx) => (
                  <span key={idx} className="px-3 py-1 bg-white text-slate-700 rounded-lg text-xs font-medium border border-sky-100 shadow-2xs">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* What's Included */}
          <div>
            <h3 className="font-bold text-slate-900 text-base mb-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-sky-700" />
              What's Included
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {service.included.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2 p-2 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="p-0.5 bg-emerald-100 text-emerald-700 rounded-full shrink-0 mt-0.5">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                  <span className="text-slate-700 font-medium">{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Optional Extras */}
          {service.optionalExtras.length > 0 && (
            <div>
              <h3 className="font-bold text-slate-900 text-base mb-2 flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-sky-700" />
                Optional Extras Available
              </h3>
              <div className="flex flex-wrap gap-2">
                {service.optionalExtras.map((extra, idx) => (
                  <span key={idx} className="px-3 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs">
                    + {extra}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* FAQs */}
          {service.faqs.length > 0 && (
            <div>
              <h3 className="font-bold text-slate-900 text-base mb-2 flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-sky-700" />
                Frequently Asked Questions
              </h3>
              <div className="space-y-2">
                {service.faqs.map((faq, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                    <p className="font-bold text-slate-900 mb-1">{faq.question}</p>
                    <p className="text-slate-600">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer CTA */}
        <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
          <div>
            <span className="text-[11px] text-slate-500 block">Transparent Pricing</span>
            <span className="font-black text-lg text-slate-900">From £{service.startingPrice}</span>
          </div>
          <button
            type="button"
            onClick={() => {
              onClose();
              onBookNow(service.id);
            }}
            className="px-6 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-2 cursor-pointer"
          >
            Book This Cleaning <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
