import React, { useState, useEffect } from 'react';
import { 
  Service, 
  Booking, 
  PropertyType, 
  PropertySize, 
  CleaningFrequency,
  FAQ,
  Review
} from './types';
import { DataStore } from './services/store';
import { BookingWizardModal } from './components/BookingWizardModal';
import { QuoteRequestModal } from './components/QuoteRequestModal';
import { ServiceDetailModal } from './components/ServiceDetailModal';
import { CustomerDashboard } from './components/CustomerDashboard';
import { CleanerDashboard } from './components/CleanerDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { InvoiceModal } from './components/InvoiceModal';
import { CookieBanner } from './components/CookieBanner';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { ChecklistSection } from './components/ChecklistSection';
import { PostcodeChecker } from './components/PostcodeChecker';
import { PricingCalculatorSection } from './components/PricingCalculatorSection';
import { CommercialSection } from './components/CommercialSection';
import { ContactSection } from './components/ContactSection';
import { 
  ShieldCheck, 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  Phone, 
  Mail, 
  MapPin, 
  ChevronRight, 
  Star, 
  ArrowRight, 
  Menu, 
  X, 
  Calendar, 
  CreditCard, 
  FileText, 
  Search,
  ChevronDown,
  UserCheck,
  Award,
  HelpCircle,
  Home,
  Building,
  Check
} from 'lucide-react';

export default function App() {
  // Store dynamic data
  const [content, setContent] = useState(DataStore.getWebsiteContent());
  const [services, setServices] = useState<Service[]>(DataStore.getServices().filter(s => s.active));
  const [specialOffer, setSpecialOffer] = useState(DataStore.getSpecialOffer());
  const [faqs, setFaqs] = useState<FAQ[]>(DataStore.getFaqs());
  const [reviews, setReviews] = useState<Review[]>(DataStore.getReviews().filter(r => r.active));
  const [vatSettings, setVatSettings] = useState(DataStore.getVatSettings());

  // Listen for storage events (updates from Admin, Customer, Cleaner actions)
  useEffect(() => {
    const handleUpdate = () => {
      setContent(DataStore.getWebsiteContent());
      setServices(DataStore.getServices().filter(s => s.active));
      setSpecialOffer(DataStore.getSpecialOffer());
      setFaqs(DataStore.getFaqs());
      setReviews(DataStore.getReviews().filter(r => r.active));
      setVatSettings(DataStore.getVatSettings());
    };
    window.addEventListener('apexclean_storage_update', handleUpdate);
    return () => window.removeEventListener('apexclean_storage_update', handleUpdate);
  }, []);

  // Modals visibility
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isQuoteOpen, setIsQuoteOpen] = useState(false);
  const [isCustomerPortalOpen, setIsCustomerPortalOpen] = useState(false);
  const [isCleanerPortalOpen, setIsCleanerPortalOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [selectedServiceDetail, setSelectedServiceDetail] = useState<Service | null>(null);
  const [activeInvoice, setActiveInvoice] = useState<any>(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);

  // Legal Modals
  const [legalModalContent, setLegalModalContent] = useState<{ title: string; text: string } | null>(null);

  // Prefill state for Booking Wizard
  const [bookingPrefills, setBookingPrefills] = useState<{
    serviceId?: string;
    postcode?: string;
    propertyType?: PropertyType;
    propertySize?: PropertySize;
    bathrooms?: number;
    frequency?: CleaningFrequency;
  }>({});

  // Hero Quick Estimator Widget State
  const [heroServiceId, setHeroServiceId] = useState('srv-regular');
  const [heroPropertyType, setHeroPropertyType] = useState<PropertyType>('House');
  const [heroSize, setHeroSize] = useState<PropertySize>('2 Bedrooms');
  const [heroBathrooms, setHeroBathrooms] = useState(1);
  const [heroFrequency, setHeroFrequency] = useState<CleaningFrequency>('weekly');
  const [heroPostcode, setHeroPostcode] = useState('');
  const [heroPostcodeStatus, setHeroPostcodeStatus] = useState<string>('');

  // Mobile navigation drawer
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // FAQ accordion open index
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);
  const [faqSearchQuery, setFaqSearchQuery] = useState('');

  // Hero live price estimate calculation
  const heroPricing = DataStore.calculatePricing({
    serviceId: heroServiceId,
    propertyType: heroPropertyType,
    propertySize: heroSize,
    bathrooms: heroBathrooms,
    frequency: heroFrequency,
    selectedExtraIds: []
  });

  const handleHeroPostcodeChange = (val: string) => {
    setHeroPostcode(val);
    if (!val.trim()) {
      setHeroPostcodeStatus('');
      return;
    }
    const check = DataStore.validatePostcode(val);
    if (check.isValid) {
      setHeroPostcodeStatus('✓ Available in your area');
    } else {
      setHeroPostcodeStatus('Out of main area');
    }
  };

  const handleOpenBookingWithHeroData = () => {
    setBookingPrefills({
      serviceId: heroServiceId,
      postcode: heroPostcode,
      propertyType: heroPropertyType,
      propertySize: heroSize,
      bathrooms: heroBathrooms,
      frequency: heroFrequency
    });
    setIsBookingOpen(true);
  };

  const handleOpenBookingForService = (serviceId: string) => {
    setBookingPrefills({
      serviceId,
      propertyType: 'House',
      propertySize: '2 Bedrooms',
      bathrooms: 1,
      frequency: 'weekly'
    });
    setIsBookingOpen(true);
  };

  const handleOpenInvoiceModalForBooking = (booking: Booking) => {
    const inv = DataStore.generateInvoice(booking);
    setActiveInvoice(inv);
    setIsInvoiceOpen(true);
  };

  const filteredFaqs = faqs.filter(f => 
    f.question.toLowerCase().includes(faqSearchQuery.toLowerCase()) ||
    f.answer.toLowerCase().includes(faqSearchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-sky-100 selection:text-sky-900">
      
      {/* 1. TOP ANNOUNCEMENT & PORTALS BAR */}
      <div className="bg-slate-900 text-slate-300 text-xs border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex flex-col sm:flex-row items-center justify-between gap-2">
          
          {/* Left: Contact Details & Service Area */}
          <div className="flex items-center gap-4 text-[11px]">
            <a href={`tel:${content.phone}`} className="flex items-center gap-1.5 hover:text-white transition font-medium">
              <Phone className="w-3 h-3 text-sky-400" />
              <span>{content.phone}</span>
            </a>
            <span className="hidden md:inline text-slate-600">•</span>
            <span className="hidden md:flex items-center gap-1.5 text-slate-400">
              <Clock className="w-3 h-3 text-sky-400" />
              <span>{content.openingHours}</span>
            </span>
            <span className="hidden lg:inline text-slate-600">•</span>
            <span className="hidden lg:flex items-center gap-1.5 text-slate-400">
              <MapPin className="w-3 h-3 text-sky-400" />
              <span>{content.serviceArea}</span>
            </span>
          </div>

          {/* Right: Quick Portal Links (Customer, Cleaner, Admin) */}
          <div className="flex items-center gap-2 text-[11px] font-semibold">
            <button
              type="button"
              onClick={() => setIsCustomerPortalOpen(true)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer"
            >
              Customer Portal
            </button>
            <button
              type="button"
              onClick={() => setIsCleanerPortalOpen(true)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer"
            >
              Cleaner Portal
            </button>
            <button
              type="button"
              onClick={() => setIsAdminOpen(true)}
              className="px-2.5 py-1 rounded-lg bg-sky-900/60 hover:bg-sky-800 text-sky-300 border border-sky-700/50 transition cursor-pointer font-bold"
            >
              Admin
            </button>
          </div>
        </div>

        {/* Special Offer Banner (if enabled) */}
        {specialOffer.enabled && (
          <div className="bg-gradient-to-r from-sky-700 to-indigo-800 text-white text-xs py-1.5 px-4 text-center font-bold tracking-wide">
            <span>✨ {specialOffer.title}: {specialOffer.description} Use code: <strong className="font-mono underline">{specialOffer.promoCode}</strong></span>
          </div>
        )}
      </div>

      {/* 2. PRIMARY STICKY NAVIGATION HEADER */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 transition-all shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            
            {/* Brand Logo */}
            <a href="#" className="flex items-center gap-2.5 group">
              <div className="w-10 h-10 rounded-2xl bg-sky-700 flex items-center justify-center text-white font-black text-xl shadow-md group-hover:scale-105 transition">
                ✓
              </div>
              <div>
                <span className="text-xl font-black text-slate-900 tracking-tight block leading-none">
                  {content.companyName}
                </span>
                <span className="text-[10px] font-bold text-sky-800 uppercase tracking-widest block mt-0.5">
                  Professional UK Cleaning
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-7 text-xs font-bold text-slate-600">
              <a href="#services" className="hover:text-sky-700 transition">Services</a>
              <a href="#pricing" className="hover:text-sky-700 transition">Pricing Calculator</a>
              <a href="#checklist" className="hover:text-sky-700 transition">Our 50-Point Standard</a>
              <a href="#service-areas" className="hover:text-sky-700 transition">Service Areas</a>
              <a href="#commercial" className="hover:text-sky-700 transition">Commercial</a>
              <a href="#reviews" className="hover:text-sky-700 transition">Reviews</a>
              <a href="#faqs" className="hover:text-sky-700 transition">FAQs</a>
              <a href="#contact" className="hover:text-sky-700 transition">Contact</a>
            </nav>

            {/* Header Call-to-Action Buttons */}
            <div className="hidden sm:flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsQuoteOpen(true)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Get a Quote
              </button>
              <button
                type="button"
                onClick={() => {
                  setBookingPrefills({ serviceId: 'srv-regular' });
                  setIsBookingOpen(true);
                }}
                className="px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-md hover:shadow-lg transition flex items-center gap-2 cursor-pointer"
              >
                Book a Cleaner <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-xl"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-slate-200 p-5 space-y-4 text-sm font-bold text-slate-700 shadow-xl">
            <a href="#services" onClick={() => setMobileMenuOpen(false)} className="block py-1">Services</a>
            <a href="#pricing" onClick={() => setMobileMenuOpen(false)} className="block py-1">Pricing Calculator</a>
            <a href="#checklist" onClick={() => setMobileMenuOpen(false)} className="block py-1">Cleaning Standards</a>
            <a href="#service-areas" onClick={() => setMobileMenuOpen(false)} className="block py-1">Service Areas</a>
            <a href="#commercial" onClick={() => setMobileMenuOpen(false)} className="block py-1">Commercial Cleaning</a>
            <a href="#reviews" onClick={() => setMobileMenuOpen(false)} className="block py-1">Customer Reviews</a>
            <a href="#faqs" onClick={() => setMobileMenuOpen(false)} className="block py-1">FAQs</a>
            <a href="#contact" onClick={() => setMobileMenuOpen(false)} className="block py-1">Contact Us</a>
            
            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setIsQuoteOpen(true);
                }}
                className="w-full py-2.5 bg-slate-100 text-slate-800 rounded-xl text-xs font-bold"
              >
                Request Free Quote
              </button>
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setIsBookingOpen(true);
                }}
                className="w-full py-3 bg-sky-700 text-white rounded-xl text-xs font-bold shadow-md"
              >
                Book a Cleaner Now
              </button>
            </div>
          </div>
        )}
      </header>

      {/* 3. HERO SECTION WITH EMBEDDED REAL-TIME BOOKING WIDGET */}
      <section className="relative pt-12 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-slate-50 via-white to-white overflow-hidden border-b border-slate-200">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Hero Content (7 cols) */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              
              {/* Trust Pill */}
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 text-sky-900 text-xs font-bold uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4 text-sky-700" />
                <span>UK Trusted Cleaning Service</span>
              </div>

              {/* Headline */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.08]">
                {content.heroHeadline}
              </h1>

              {/* Subheading */}
              <p className="text-base sm:text-lg text-slate-600 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                {content.heroSubheading}
              </p>

              {/* Trust Badges Row (Section 4 Compliance) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs font-bold text-slate-700">
                <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-2">
                  <div className="p-1 bg-emerald-100 text-emerald-700 rounded-lg">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <span>Vetted & DBS Checked</span>
                </div>

                <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-2">
                  <div className="p-1 bg-sky-100 text-sky-700 rounded-lg">
                    <Award className="w-4 h-4" />
                  </div>
                  <span>100% Satisfaction Guarantee</span>
                </div>

                <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-2">
                  <div className="p-1 bg-emerald-100 text-emerald-700 rounded-lg">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <span>Eco-Friendly Supplies</span>
                </div>

                <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-2">
                  <div className="p-1 bg-indigo-100 text-indigo-700 rounded-lg">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span>No Hidden Fees</span>
                </div>
              </div>

              {/* Only show Fully Insured badge if enabled by admin as instructed in Section 4 */}
              {content.isFullyInsured && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Fully Insured Professional Cleaning Service</span>
                </div>
              )}

              {/* Quick Action Links */}
              <div className="pt-2 flex flex-wrap justify-center lg:justify-start gap-4 text-xs font-bold text-slate-600">
                <a href="#services" className="hover:text-sky-700 flex items-center gap-1">
                  Explore All Cleaning Services →
                </a>
                <span>•</span>
                <a href="#commercial" className="hover:text-sky-700 flex items-center gap-1">
                  Commercial Workplace Cleaning →
                </a>
              </div>
            </div>

            {/* Right Hero: Instant Online Booking Calculator Widget (5 cols) */}
            <div className="lg:col-span-5">
              <div className="bg-white border-2 border-slate-200 rounded-3xl p-6 sm:p-7 shadow-2xl relative space-y-4">
                
                <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-sky-800 block">
                      Instant Booking Engine
                    </span>
                    <h3 className="font-extrabold text-lg text-slate-900">Get an Instant Price</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block uppercase font-bold">Estimated Cost</span>
                    <span className="text-2xl font-black text-sky-800 font-mono">£{heroPricing.total.toFixed(2)}</span>
                  </div>
                </div>

                {/* Service Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Select Service</label>
                  <select
                    value={heroServiceId}
                    onChange={(e) => setHeroServiceId(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500"
                  >
                    {services.map(s => (
                      <option key={s.id} value={s.id}>{s.title} (from £{s.startingPrice})</option>
                    ))}
                  </select>
                </div>

                {/* Property Type & Bedrooms */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Property Type</label>
                    <select
                      value={heroPropertyType}
                      onChange={(e) => setHeroPropertyType(e.target.value as PropertyType)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium outline-none"
                    >
                      <option value="House">House</option>
                      <option value="Flat/Apartment">Flat/Apartment</option>
                      <option value="Studio">Studio</option>
                      <option value="Office">Office</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Bedrooms</label>
                    <select
                      value={heroSize}
                      onChange={(e) => setHeroSize(e.target.value as PropertySize)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium outline-none"
                    >
                      <option value="Studio">Studio</option>
                      <option value="1 Bedroom">1 Bedroom</option>
                      <option value="2 Bedrooms">2 Bedrooms</option>
                      <option value="3 Bedrooms">3 Bedrooms</option>
                      <option value="4 Bedrooms">4 Bedrooms</option>
                      <option value="5+ Bedrooms">5+ Bedrooms</option>
                    </select>
                  </div>
                </div>

                {/* Bathrooms & Frequency */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Bathrooms</label>
                    <select
                      value={heroBathrooms}
                      onChange={(e) => setHeroBathrooms(Number(e.target.value))}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium outline-none"
                    >
                      <option value={1}>1 Bathroom</option>
                      <option value={2}>2 Bathrooms</option>
                      <option value={3}>3 Bathrooms</option>
                      <option value={4}>4+ Bathrooms</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Frequency</label>
                    <select
                      value={heroFrequency}
                      onChange={(e) => setHeroFrequency(e.target.value as CleaningFrequency)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-sky-800 outline-none"
                    >
                      <option value="weekly">Weekly (15% Off)</option>
                      <option value="fortnightly">Fortnightly (10% Off)</option>
                      <option value="monthly">Monthly (5% Off)</option>
                      <option value="one-off">One-Off Clean</option>
                    </select>
                  </div>
                </div>

                {/* UK Postcode Live Check */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Enter UK Postcode</label>
                  <input
                    type="text"
                    placeholder="e.g. SW1A 1AA or EC1"
                    value={heroPostcode}
                    onChange={(e) => handleHeroPostcodeChange(e.target.value.toUpperCase())}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs uppercase font-bold tracking-wider outline-none focus:ring-2 focus:ring-sky-500"
                  />
                  {heroPostcodeStatus && (
                    <p className={`text-[11px] font-semibold mt-1 ${
                      heroPostcodeStatus.includes('Available') ? 'text-emerald-600' : 'text-amber-600'
                    }`}>
                      {heroPostcodeStatus}
                    </p>
                  )}
                </div>

                {/* Booking Button */}
                <button
                  type="button"
                  onClick={handleOpenBookingWithHeroData}
                  className="w-full py-3.5 bg-sky-700 hover:bg-sky-800 text-white rounded-2xl text-xs font-black uppercase tracking-wider shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  Book Online in 60 Seconds (£{heroPricing.total.toFixed(2)}) <ArrowRight className="w-4 h-4" />
                </button>

                <p className="text-[10px] text-center text-slate-400">
                  Instant confirmation • No upfront booking charge option • Cancel free up to 24h
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 4. COMPREHENSIVE SERVICES SHOWCASE GRID */}
      <section id="services" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto">
          
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="px-3 py-1 bg-sky-100 text-sky-800 rounded-full text-xs font-bold uppercase tracking-wider">
              Comprehensive Service Range
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mt-2">
              Tailored Cleaning Solutions Across the UK
            </h2>
            <p className="text-slate-600 text-sm mt-2">
              Every home and commercial premise receives our meticulous attention to detail. Fully equipped with professional vacuums, steam machines, and safe eco products.
            </p>
          </div>

          {/* Service Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <div 
                key={service.id} 
                className="bg-white border border-slate-200 hover:border-sky-300 rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  {/* Service Photo */}
                  <div className="relative h-48 w-full overflow-hidden bg-slate-100">
                    <img 
                      src={service.imageUrl} 
                      alt={service.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                      {service.category}
                    </div>
                    <div className="absolute bottom-3 right-3 bg-white/95 text-slate-900 text-xs font-black px-2.5 py-1 rounded-xl shadow-md font-mono">
                      From £{service.startingPrice}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 space-y-3">
                    <h3 className="font-extrabold text-lg text-slate-900 leading-snug group-hover:text-sky-700 transition">
                      {service.title}
                    </h3>
                    
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {service.shortDescription}
                    </p>

                    {/* Features Checklist Snippet */}
                    <div className="space-y-1 pt-1">
                      {service.included.slice(0, 3).map((inc, i) => (
                        <div key={i} className="flex items-center gap-1.5 text-[11px] text-slate-600 font-medium">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 stroke-[2.5]" />
                          <span className="truncate">{inc}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="p-5 pt-0 border-t border-slate-100 mt-2 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedServiceDetail(service)}
                    className="text-xs font-bold text-slate-600 hover:text-sky-700 transition"
                  >
                    View Details
                  </button>
                  <button
                    type="button"
                    onClick={() => handleOpenBookingForService(service.id)}
                    className="px-3.5 py-2 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-2xs cursor-pointer"
                  >
                    Book Now <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 5. TENANCY DEPOSIT 72-HOUR RE-CLEAN GUARANTEE BANNER (Section 5 & 2) */}
      <section className="py-14 px-4 sm:px-6 lg:px-8 bg-slate-900 text-white border-b border-slate-800">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 border border-slate-700/80 shadow-2xl">
            <div className="space-y-2 text-center md:text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold uppercase">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>100% Tenancy Deposit Standard</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                Moving Out? Free 72-Hour Re-Clean Guarantee
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
                Our End of Tenancy cleaning adheres strictly to approved estate agency checkout checklists. If your inventory clerk or landlord notes any cleaning issue, we return free of charge within 72 hours.
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleOpenBookingForService('srv-tenancy')}
              className="px-6 py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-2xl text-xs font-black uppercase tracking-wider shadow-lg transition shrink-0 cursor-pointer"
            >
              Book End of Tenancy Clean
            </button>
          </div>
        </div>
      </section>

      {/* 6. BEFORE & AFTER TRANSFORMATION SLIDER */}
      <BeforeAfterSlider />

      {/* 7. ROOM-BY-ROOM CLEANING CHECKLIST SPECIFICATION (Section 7) */}
      <ChecklistSection />

      {/* 8. INTERACTIVE PRICING CALCULATOR (Section 17) */}
      <PricingCalculatorSection 
        onBookWithParams={(params) => {
          setBookingPrefills({
            serviceId: params.serviceId,
            propertyType: params.propertyType,
            propertySize: params.propertySize,
            bathrooms: params.bathrooms,
            frequency: params.frequency
          });
          setIsBookingOpen(true);
        }}
      />

      {/* 9. UK COVERAGE & SERVICE AREA CHECKER (Section 18 & 27) */}
      <PostcodeChecker 
        onBookNow={(postcode) => {
          setBookingPrefills({ postcode });
          setIsBookingOpen(true);
        }}
      />

      {/* 10. COMMERCIAL & OFFICE CLEANING (Section 2 & 5) */}
      <CommercialSection onOpenQuoteModal={() => setIsQuoteOpen(true)} />

      {/* 11. HOW IT WORKS (3 SIMPLE STEPS) */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50/50 border-b border-slate-200">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="px-3 py-1 bg-sky-100 text-sky-800 rounded-full text-xs font-bold uppercase tracking-wider">
              Simple & Reliable
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mt-2">
              How Our Service Works
            </h2>
            <p className="text-slate-600 text-sm mt-2">
              Effortless cleaning arrangements with complete peace of mind.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 bg-white border border-slate-200 rounded-3xl text-center space-y-3 shadow-sm hover:border-sky-300 transition">
              <div className="w-14 h-14 bg-sky-100 text-sky-800 rounded-2xl flex items-center justify-center font-black text-xl mx-auto shadow-2xs">
                01
              </div>
              <h3 className="font-extrabold text-lg text-slate-900">Book in 60 Seconds</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Choose your service, customize property bedrooms, bathrooms, extras, and pick an arrival slot online.
              </p>
            </div>

            <div className="p-8 bg-white border border-slate-200 rounded-3xl text-center space-y-3 shadow-sm hover:border-sky-300 transition">
              <div className="w-14 h-14 bg-sky-100 text-sky-800 rounded-2xl flex items-center justify-center font-black text-xl mx-auto shadow-2xs">
                02
              </div>
              <h3 className="font-extrabold text-lg text-slate-900">Expert Cleaner Arrives</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Your vetted, background-checked professional arrives equipped with professional tools and eco detergents.
              </p>
            </div>

            <div className="p-8 bg-white border border-slate-200 rounded-3xl text-center space-y-3 shadow-sm hover:border-sky-300 transition">
              <div className="w-14 h-14 bg-sky-100 text-sky-800 rounded-2xl flex items-center justify-center font-black text-xl mx-auto shadow-2xs">
                03
              </div>
              <h3 className="font-extrabold text-lg text-slate-900">Relax in Spotless Comfort</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Inspect your refreshed property backed by our 100% satisfaction re-clean guarantee. Digital receipt generated instantly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 12. GENUINE CUSTOMER REVIEWS (Section 21 Compliance) */}
      <section id="reviews" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold uppercase tracking-wider">
              Verified Feedback
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mt-2">
              Customer Experiences
            </h2>
            <p className="text-slate-600 text-sm mt-2">
              Real feedback from households and commercial clients. (Per strict compliance guidelines, no fake reviews are invented; all feedback is verified).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {reviews.map((rev) => (
              <div key={rev.id} className="p-6 bg-slate-50 border border-slate-200 rounded-3xl space-y-4 shadow-2xs">
                <div className="flex items-center justify-between">
                  <div className="flex text-amber-400">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  {rev.verified && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Verified Client
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-700 italic leading-relaxed">
                  "{rev.reviewText}"
                </p>

                <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-xs">
                  <div>
                    <strong className="text-slate-900 block">{rev.customerName}</strong>
                    <span className="text-slate-500 text-[11px]">{rev.serviceName}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">{rev.date}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <p className="text-xs text-slate-500">
              Are you a client? We welcome feedback directly after every completed cleaning.
            </p>
          </div>
        </div>
      </section>

      {/* 13. FREQUENTLY ASKED QUESTIONS (Section 20) */}
      <section id="faqs" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50/70 border-b border-slate-200">
        <div className="max-w-4xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="px-3 py-1 bg-sky-100 text-sky-800 rounded-full text-xs font-bold uppercase tracking-wider">
              Answers & Advice
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mt-2">
              Frequently Asked Questions
            </h2>
            <p className="text-slate-600 text-sm mt-2">
              Everything you need to know about our cleaners, access, supplies, and cancellation.
            </p>
          </div>

          {/* Quick Search FAQ Filter */}
          <div className="relative max-w-md mx-auto mb-8">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search questions (e.g. key, products, pets, cancellation)..."
              value={faqSearchQuery}
              onChange={(e) => setFaqSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-300 rounded-2xl text-xs outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Accordion List */}
          <div className="space-y-3">
            {filteredFaqs.map((faq, idx) => (
              <div 
                key={faq.id}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs transition"
              >
                <button
                  type="button"
                  onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                  className="w-full p-4 text-left flex items-center justify-between gap-4 font-bold text-sm text-slate-900 hover:text-sky-700 transition cursor-pointer"
                >
                  <span>{faq.question}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${
                    expandedFaq === idx ? 'rotate-180 text-sky-700' : ''
                  }`} />
                </button>
                {expandedFaq === idx && (
                  <div className="px-4 pb-4 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 14. CONTACT US & DIRECT ENQUIRY (Section 19 & 3) */}
      <ContactSection />

      {/* 15. COMPREHENSIVE UK FOOTER & LEGAL LINKS */}
      <footer className="bg-slate-950 text-slate-400 text-xs pt-16 pb-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            
            {/* Col 1: Brand Info (2 cols wide) */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-sky-600 flex items-center justify-center text-white font-bold text-lg">
                  ✓
                </div>
                <span className="text-xl font-black text-white tracking-tight">{content.companyName}</span>
              </div>
              
              <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
                {content.tagline}. High-caliber residential and commercial cleaning across London and the UK with background-checked operatives.
              </p>

              <div className="text-xs space-y-1 text-slate-300">
                <p>📍 {content.address}</p>
                <p>📞 {content.phone}</p>
                <p>✉️ {content.email}</p>
                {vatSettings.enabled && (
                  <p className="text-slate-400 pt-1">VAT Reg: <strong className="text-slate-200">{vatSettings.vatNumber}</strong></p>
                )}
              </div>
            </div>

            {/* Col 2: Cleaning Services */}
            <div className="space-y-3">
              <h4 className="font-bold text-sm text-white uppercase tracking-wider text-[11px]">Cleaning Services</h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#services" className="hover:text-white transition">Regular Domestic Cleaning</a></li>
                <li><a href="#services" className="hover:text-white transition">End of Tenancy Cleaning</a></li>
                <li><a href="#services" className="hover:text-white transition">Deep Spring Cleaning</a></li>
                <li><a href="#services" className="hover:text-white transition">Carpet & Upholstery Steam Clean</a></li>
                <li><a href="#services" className="hover:text-white transition">After Builders Cleaning</a></li>
                <li><a href="#services" className="hover:text-white transition">Airbnb & Holiday Let Turnover</a></li>
              </ul>
            </div>

            {/* Col 3: Quick Navigation */}
            <div className="space-y-3">
              <h4 className="font-bold text-sm text-white uppercase tracking-wider text-[11px]">Explore</h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#pricing" className="hover:text-white transition">Instant Price Calculator</a></li>
                <li><a href="#checklist" className="hover:text-white transition">Our 50-Point Room Standard</a></li>
                <li><a href="#service-areas" className="hover:text-white transition">Check Covered Postcodes</a></li>
                <li><a href="#commercial" className="hover:text-white transition">Commercial Contracts</a></li>
                <li><a href="#reviews" className="hover:text-white transition">Verified Customer Reviews</a></li>
                <li><a href="#faqs" className="hover:text-white transition">Customer FAQs</a></li>
              </ul>
            </div>

            {/* Col 4: Portals & Legal Modals */}
            <div className="space-y-3">
              <h4 className="font-bold text-sm text-white uppercase tracking-wider text-[11px]">Legal & Portals</h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <button 
                    type="button" 
                    onClick={() => setLegalModalContent({
                      title: 'Terms & Conditions',
                      text: 'ApexClean UK operates strict customer service commitments. All domestic bookings can be rescheduled up to 24 hours in advance without penalty. Cancellations within 24 hours may incur a late cancellation fee. All cleaning operatives are vetted and DBS-checked. End of Tenancy cleaning includes our 72-hour re-clean guarantee.'
                    })}
                    className="hover:text-white transition text-left"
                  >
                    Terms & Conditions
                  </button>
                </li>
                <li>
                  <button 
                    type="button" 
                    onClick={() => setLegalModalContent({
                      title: 'UK GDPR & Privacy Policy',
                      text: 'We comply with the UK Data Protection Act 2018 and UK GDPR. We collect customer name, address, email and phone solely for scheduling and dispatching cleaning visits, billing, and quality assurance. Data is stored securely and never sold to third parties.'
                    })}
                    className="hover:text-white transition text-left"
                  >
                    Privacy Policy (GDPR)
                  </button>
                </li>
                <li>
                  <button 
                    type="button" 
                    onClick={() => setLegalModalContent({
                      title: 'Cancellation & Refund Policy',
                      text: 'Clients may cancel or reschedule appointments with at least 24 hours notice for a full refund or re-credit. If you are dissatisfied with any cleaning work, notify us within 24 hours (or 72 hours for End of Tenancy) and we will dispatch a supervisor or operative to re-clean the problem area free of charge.'
                    })}
                    className="hover:text-white transition text-left"
                  >
                    Cancellation & Refund Policy
                  </button>
                </li>
                <li>
                  <button 
                    type="button" 
                    onClick={() => setIsCustomerPortalOpen(true)}
                    className="text-sky-400 hover:text-sky-300 transition text-left font-bold"
                  >
                    Customer Account Login
                  </button>
                </li>
                <li>
                  <button 
                    type="button" 
                    onClick={() => setIsCleanerPortalOpen(true)}
                    className="text-emerald-400 hover:text-emerald-300 transition text-left font-bold"
                  >
                    Operative Cleaning Portal
                  </button>
                </li>
                <li>
                  <button 
                    type="button" 
                    onClick={() => setIsAdminOpen(true)}
                    className="text-slate-400 hover:text-slate-200 transition text-left"
                  >
                    Business Admin Dashboard
                  </button>
                </li>
              </ul>
            </div>

          </div>

          <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <p>© {new Date().getFullYear()} {content.companyName}. All rights reserved. Registered in England & Wales.</p>
            <p className="flex items-center gap-1">
              <span>Secure Payments Encrypted with 256-bit SSL</span>
            </p>
          </div>

        </div>
      </footer>

      {/* 16. MODALS & PORTALS CONTAINER */}

      {/* Booking Wizard Modal */}
      <BookingWizardModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        prefilledServiceId={bookingPrefills.serviceId}
        prefilledPostcode={bookingPrefills.postcode}
        prefilledPropertyType={bookingPrefills.propertyType}
        prefilledFrequency={bookingPrefills.frequency}
        onOpenInvoice={(b) => handleOpenInvoiceModalForBooking(b)}
      />

      {/* Quote Request Modal */}
      <QuoteRequestModal
        isOpen={isQuoteOpen}
        onClose={() => setIsQuoteOpen(false)}
      />

      {/* Service Detail Modal */}
      <ServiceDetailModal
        service={selectedServiceDetail}
        isOpen={!!selectedServiceDetail}
        onClose={() => setSelectedServiceDetail(null)}
        onBookNow={(srvId) => handleOpenBookingForService(srvId)}
      />

      {/* Customer Dashboard Portal */}
      {isCustomerPortalOpen && (
        <CustomerDashboard
          onBookAgain={(srvId) => {
            setIsCustomerPortalOpen(false);
            handleOpenBookingForService(srvId);
          }}
          onOpenInvoice={(b) => handleOpenInvoiceModalForBooking(b)}
          onClose={() => setIsCustomerPortalOpen(false)}
        />
      )}

      {/* Cleaner Dashboard Portal */}
      {isCleanerPortalOpen && (
        <CleanerDashboard
          onClose={() => setIsCleanerPortalOpen(false)}
        />
      )}

      {/* Admin Dashboard */}
      {isAdminOpen && (
        <AdminDashboard
          onClose={() => setIsAdminOpen(false)}
          onOpenInvoice={(b) => handleOpenInvoiceModalForBooking(b)}
        />
      )}

      {/* Printable UK Invoice & Receipt Modal */}
      <InvoiceModal
        isOpen={isInvoiceOpen}
        invoice={activeInvoice}
        onClose={() => setIsInvoiceOpen(false)}
      />

      {/* Legal Content Modal */}
      {legalModalContent && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-lg text-slate-900">{legalModalContent.title}</h3>
              <button 
                type="button" 
                onClick={() => setLegalModalContent(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
              {legalModalContent.text}
            </p>
            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setLegalModalContent(null)}
                className="px-5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* GDPR Cookie Consent Banner */}
      <CookieBanner
        onOpenLegal={(type) => {
          if (type === 'privacy') {
            setLegalModalContent({
              title: 'UK GDPR & Privacy Policy',
              text: 'We comply with the UK Data Protection Act 2018 and UK GDPR. We collect customer name, address, email and phone solely for scheduling and dispatching cleaning visits, billing, and quality assurance. Data is stored securely and never sold to third parties.'
            });
          } else if (type === 'cookies') {
            setLegalModalContent({
              title: 'Cookie Policy',
              text: 'We use strictly essential cookies for secure session maintenance, local preference persistence, and fraud prevention. With your explicit consent, we also utilize anonymised analytics cookies to measure site interactions.'
            });
          } else {
            setLegalModalContent({
              title: 'Terms & Conditions',
              text: 'ApexClean UK operates strict customer service commitments. All domestic bookings can be rescheduled up to 24 hours in advance without penalty. Cancellations within 24 hours may incur a late cancellation fee. All cleaning operatives are vetted and DBS-checked. End of Tenancy cleaning includes our 72-hour re-clean guarantee.'
            });
          }
        }}
      />

    </div>
  );
}
