import { 
  Booking, 
  BookingPricingBreakdown, 
  BusinessHoursDay, 
  Cleaner, 
  ContactMessage, 
  Customer, 
  FAQ, 
  Invoice, 
  PricingRules, 
  PromoCode, 
  PropertySize, 
  PropertyType, 
  QuoteRequest, 
  Review, 
  Service, 
  ServiceAreaConfig, 
  ServiceExtra, 
  SpecialOffer, 
  User, 
  UserRole, 
  VatSettings, 
  WebsiteContent,
  AvailabilityBlock
} from '../types';
import { 
  INITIAL_BOOKINGS, 
  INITIAL_BUSINESS_HOURS, 
  INITIAL_CLEANERS, 
  INITIAL_EXTRAS, 
  INITIAL_FAQS, 
  INITIAL_PRICING_RULES, 
  INITIAL_PROMO_CODES, 
  INITIAL_REVIEWS, 
  INITIAL_SERVICES, 
  INITIAL_SERVICE_AREA, 
  INITIAL_SPECIAL_OFFER, 
  INITIAL_VAT_SETTINGS, 
  INITIAL_WEBSITE_CONTENT,
  DEMO_USERS
} from '../data/initialData';

const STORAGE_KEYS = {
  WEBSITE_CONTENT: 'apexclean_website_content',
  SERVICES: 'apexclean_services',
  EXTRAS: 'apexclean_extras',
  PRICING_RULES: 'apexclean_pricing_rules',
  VAT_SETTINGS: 'apexclean_vat_settings',
  SERVICE_AREA: 'apexclean_service_area',
  BUSINESS_HOURS: 'apexclean_business_hours',
  FAQS: 'apexclean_faqs',
  REVIEWS: 'apexclean_reviews',
  PROMO_CODES: 'apexclean_promo_codes',
  CLEANERS: 'apexclean_cleaners',
  BOOKINGS: 'apexclean_bookings',
  QUOTE_REQUESTS: 'apexclean_quote_requests',
  CONTACT_MESSAGES: 'apexclean_contact_messages',
  SPECIAL_OFFER: 'apexclean_special_offer',
  AVAILABILITY_BLOCKS: 'apexclean_availability_blocks',
  CURRENT_USER: 'apexclean_current_user'
};

function getFromStorage<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    window.dispatchEvent(new CustomEvent('apexclean_storage_update', { detail: { key } }));
  } catch (e) {
    console.error('Failed to save to localStorage', e);
  }
}

export class DataStore {
  // Website Content
  static getWebsiteContent(): WebsiteContent {
    return getFromStorage<WebsiteContent>(STORAGE_KEYS.WEBSITE_CONTENT, INITIAL_WEBSITE_CONTENT);
  }

  static updateWebsiteContent(content: Partial<WebsiteContent>): WebsiteContent {
    const current = this.getWebsiteContent();
    const updated = { ...current, ...content };
    saveToStorage(STORAGE_KEYS.WEBSITE_CONTENT, updated);
    return updated;
  }

  // Services
  static getServices(): Service[] {
    return getFromStorage<Service[]>(STORAGE_KEYS.SERVICES, INITIAL_SERVICES);
  }

  static getServiceBySlug(slug: string): Service | undefined {
    return this.getServices().find(s => s.slug === slug);
  }

  static getServiceById(id: string): Service | undefined {
    return this.getServices().find(s => s.id === id);
  }

  static updateService(id: string, updates: Partial<Service>): Service[] {
    const services = this.getServices().map(s => s.id === id ? { ...s, ...updates, updatedAt: new Date().toISOString() } : s);
    saveToStorage(STORAGE_KEYS.SERVICES, services);
    return services;
  }

  // Extras
  static getExtras(): ServiceExtra[] {
    return getFromStorage<ServiceExtra[]>(STORAGE_KEYS.EXTRAS, INITIAL_EXTRAS);
  }

  static updateExtra(id: string, updates: Partial<ServiceExtra>): ServiceExtra[] {
    const extras = this.getExtras().map(e => e.id === id ? { ...e, ...updates, updatedAt: new Date().toISOString() } : e);
    saveToStorage(STORAGE_KEYS.EXTRAS, extras);
    return extras;
  }

  static addExtra(extra: Omit<ServiceExtra, 'id' | 'createdAt' | 'updatedAt'>): ServiceExtra {
    const extras = this.getExtras();
    const newExtra: ServiceExtra = {
      ...extra,
      id: `ext-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    extras.push(newExtra);
    saveToStorage(STORAGE_KEYS.EXTRAS, extras);
    return newExtra;
  }

  static deleteExtra(id: string): void {
    const extras = this.getExtras().filter(e => e.id !== id);
    saveToStorage(STORAGE_KEYS.EXTRAS, extras);
  }

  // Pricing Rules
  static getPricingRules(): PricingRules {
    return getFromStorage<PricingRules>(STORAGE_KEYS.PRICING_RULES, INITIAL_PRICING_RULES);
  }

  static updatePricingRules(rules: Partial<PricingRules>): PricingRules {
    const current = this.getPricingRules();
    const updated = { ...current, ...rules };
    saveToStorage(STORAGE_KEYS.PRICING_RULES, updated);
    return updated;
  }

  // VAT Settings
  static getVatSettings(): VatSettings {
    return getFromStorage<VatSettings>(STORAGE_KEYS.VAT_SETTINGS, INITIAL_VAT_SETTINGS);
  }

  static updateVatSettings(settings: Partial<VatSettings>): VatSettings {
    const current = this.getVatSettings();
    const updated = { ...current, ...settings };
    saveToStorage(STORAGE_KEYS.VAT_SETTINGS, updated);
    return updated;
  }

  // Service Area
  static getServiceArea(): ServiceAreaConfig {
    return getFromStorage<ServiceAreaConfig>(STORAGE_KEYS.SERVICE_AREA, INITIAL_SERVICE_AREA);
  }

  static updateServiceArea(config: Partial<ServiceAreaConfig>): ServiceAreaConfig {
    const current = this.getServiceArea();
    const updated = { ...current, ...config };
    saveToStorage(STORAGE_KEYS.SERVICE_AREA, updated);
    return updated;
  }

  static validatePostcode(rawPostcode: string): { isValid: boolean; message?: string; cleanPostcode: string } {
    if (!rawPostcode || !rawPostcode.trim()) {
      return { isValid: false, message: 'Please enter a postcode.', cleanPostcode: '' };
    }
    const clean = rawPostcode.trim().toUpperCase();
    const area = this.getServiceArea();

    if (area.allowNationwide) {
      // Standard UK postcode pattern check
      const ukPattern = /^[A-Z]{1,2}[0-9][A-Z0-9]? ?[0-9][A-Z]{2}$/i;
      // Allow partial outcodes too (e.g. SW1, W11, M1)
      const outcodePattern = /^[A-Z]{1,2}[0-9][A-Z0-9]?$/i;
      const isUkFormat = ukPattern.test(clean) || outcodePattern.test(clean);
      if (!isUkFormat && clean.length < 2) {
        return { isValid: false, message: 'Please enter a valid UK postcode.', cleanPostcode: clean };
      }
      return { isValid: true, cleanPostcode: clean };
    }

    // Extract outcode letters (e.g., SW from SW1A 1AA or SW11)
    const match = clean.match(/^([A-Z]{1,2})/);
    const prefix = match ? match[1] : '';

    const isCovered = area.allowedPostcodePrefixes.some(p => p.toUpperCase() === prefix);

    if (isCovered) {
      return { isValid: true, cleanPostcode: clean };
    } else {
      return {
        isValid: false,
        message: "We're sorry, we currently don't provide services in this area.",
        cleanPostcode: clean
      };
    }
  }

  // Business Hours
  static getBusinessHours(): BusinessHoursDay[] {
    return getFromStorage<BusinessHoursDay[]>(STORAGE_KEYS.BUSINESS_HOURS, INITIAL_BUSINESS_HOURS);
  }

  static updateBusinessHours(hours: BusinessHoursDay[]): void {
    saveToStorage(STORAGE_KEYS.BUSINESS_HOURS, hours);
  }

  static isDayOpen(dateStr: string): { isOpen: boolean; openTime?: string; closeTime?: string } {
    if (!dateStr) return { isOpen: true };
    const date = new Date(dateStr + 'T12:00:00');
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayName = dayNames[date.getDay()];
    const hours = this.getBusinessHours();
    const dayConfig = hours.find(h => h.day.toLowerCase() === dayName.toLowerCase());
    if (!dayConfig || !dayConfig.open) {
      return { isOpen: false };
    }
    return { isOpen: true, openTime: dayConfig.openTime, closeTime: dayConfig.closeTime };
  }

  // Dynamic Pricing Calculator
  static calculatePricing(params: {
    serviceId: string;
    propertyType: PropertyType;
    propertySize: PropertySize;
    bathrooms: number;
    frequency: 'one-off' | 'weekly' | 'fortnightly' | 'monthly';
    selectedExtraIds: string[];
    date?: string;
    promoCode?: string;
  }): BookingPricingBreakdown {
    const rules = this.getPricingRules();
    const vat = this.getVatSettings();
    const extrasList = this.getExtras();

    // 1. Base price for service
    const basePrice = rules.basePrices[params.serviceId] ?? 45;

    // 2. Property size surcharge
    const propertySizeSurcharge = rules.propertySizePrices[params.propertySize] ?? 0;

    // 3. Bathrooms surcharge (beyond 1 base bathroom)
    const bathroomSurcharge = Math.max(0, params.bathrooms - 1) * rules.bathroomPrice;

    // 4. Extras
    let extrasTotal = 0;
    params.selectedExtraIds.forEach(id => {
      const extra = extrasList.find(e => e.id === id);
      if (extra && extra.active) {
        extrasTotal += extra.price;
      }
    });

    // 5. Weekend surcharge if Saturday or Sunday
    let weekendSurcharge = 0;
    if (params.date) {
      const d = new Date(params.date + 'T12:00:00');
      const day = d.getDay();
      if (day === 0 || day === 6) {
        weekendSurcharge = rules.weekendSurcharge;
      }
    }

    // 6. Travel fee
    const travelFee = rules.travelFee || 0;

    // Subtotal before frequency discount and promo
    const grossSum = basePrice + propertySizeSurcharge + bathroomSurcharge + extrasTotal + weekendSurcharge + travelFee;

    // 7. Frequency discount
    let frequencyDiscountPct = 0;
    if (params.frequency === 'weekly') frequencyDiscountPct = rules.frequencyDiscounts.weekly;
    else if (params.frequency === 'fortnightly') frequencyDiscountPct = rules.frequencyDiscounts.fortnightly;
    else if (params.frequency === 'monthly') frequencyDiscountPct = rules.frequencyDiscounts.monthly;

    const frequencyDiscount = Number(((grossSum * frequencyDiscountPct) / 100).toFixed(2));
    const subtotalAfterFreq = Math.max(0, grossSum - frequencyDiscount);

    // 8. Promo Code Discount
    let promoDiscount = 0;
    let validPromoCode: string | undefined = undefined;
    if (params.promoCode) {
      const promoCheck = this.validatePromoCode(params.promoCode, subtotalAfterFreq, params.serviceId);
      if (promoCheck.isValid && promoCheck.discount) {
        promoDiscount = promoCheck.discount;
        validPromoCode = promoCheck.promo?.code;
      }
    }

    let netAmount = Math.max(rules.minimumBookingAmount, subtotalAfterFreq - promoDiscount);

    // 9. VAT Calculation
    let vatAmount = 0;
    let finalTotal = netAmount;

    if (vat.enabled) {
      if (vat.pricesIncludeVat) {
        // Price already includes VAT
        vatAmount = Number(((netAmount * vat.percentage) / (100 + vat.percentage)).toFixed(2));
        finalTotal = netAmount;
      } else {
        // Price excludes VAT - add on top
        vatAmount = Number(((netAmount * vat.percentage) / 100).toFixed(2));
        finalTotal = Number((netAmount + vatAmount).toFixed(2));
      }
    }

    return {
      basePrice,
      bedroomSurcharge: propertySizeSurcharge,
      bathroomSurcharge,
      extrasTotal,
      frequencyDiscount,
      travelFee,
      weekendSurcharge,
      subtotal: Number(grossSum.toFixed(2)),
      vatAmount: Number(vatAmount.toFixed(2)),
      promoDiscount: Number(promoDiscount.toFixed(2)),
      promoCodeUsed: validPromoCode,
      total: Number(finalTotal.toFixed(2))
    };
  }

  // Promo Codes
  static getPromoCodes(): PromoCode[] {
    return getFromStorage<PromoCode[]>(STORAGE_KEYS.PROMO_CODES, INITIAL_PROMO_CODES);
  }

  static validatePromoCode(code: string, subtotal: number, serviceId?: string): { isValid: boolean; discount: number; message?: string; promo?: PromoCode } {
    if (!code || !code.trim()) {
      return { isValid: false, discount: 0, message: 'Please enter a promo code.' };
    }
    const cleanCode = code.trim().toUpperCase();
    const codes = this.getPromoCodes();
    const promo = codes.find(p => p.code.toUpperCase() === cleanCode);

    if (!promo || !promo.active) {
      return { isValid: false, discount: 0, message: 'Invalid or expired promotional code.' };
    }

    if (promo.expiresAt && new Date(promo.expiresAt) < new Date()) {
      return { isValid: false, discount: 0, message: 'This promo code has expired.' };
    }

    if (promo.usageLimit && promo.usageCount >= promo.usageLimit) {
      return { isValid: false, discount: 0, message: 'This promo code has reached its usage limit.' };
    }

    if (subtotal < promo.minBookingAmount) {
      return { isValid: false, discount: 0, message: `Minimum booking of £${promo.minBookingAmount} required for this code.` };
    }

    if (serviceId && promo.applicableServices && promo.applicableServices.length > 0) {
      if (!promo.applicableServices.includes(serviceId)) {
        return { isValid: false, discount: 0, message: 'This promo code does not apply to the selected service.' };
      }
    }

    let discount = 0;
    if (promo.discountType === 'fixed') {
      discount = Math.min(promo.discountValue, subtotal);
    } else {
      discount = Number(((subtotal * promo.discountValue) / 100).toFixed(2));
    }

    return { isValid: true, discount, promo };
  }

  static addPromoCode(promo: Omit<PromoCode, 'id' | 'createdAt' | 'updatedAt' | 'usageCount'>): PromoCode {
    const codes = this.getPromoCodes();
    const newPromo: PromoCode = {
      ...promo,
      id: `promo-${Date.now()}`,
      usageCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    codes.push(newPromo);
    saveToStorage(STORAGE_KEYS.PROMO_CODES, codes);
    return newPromo;
  }

  static updatePromoCode(id: string, updates: Partial<PromoCode>): void {
    const codes = this.getPromoCodes().map(p => p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p);
    saveToStorage(STORAGE_KEYS.PROMO_CODES, codes);
  }

  static deletePromoCode(id: string): void {
    const codes = this.getPromoCodes().filter(p => p.id !== id);
    saveToStorage(STORAGE_KEYS.PROMO_CODES, codes);
  }

  // Bookings
  static getBookings(): Booking[] {
    return getFromStorage<Booking[]>(STORAGE_KEYS.BOOKINGS, INITIAL_BOOKINGS);
  }

  static getBookingById(id: string): Booking | undefined {
    return this.getBookings().find(b => b.id === id);
  }

  static getBookingByReference(reference: string): Booking | undefined {
    return this.getBookings().find(b => b.reference.toUpperCase() === reference.toUpperCase());
  }

  static createBooking(bookingData: Omit<Booking, 'id' | 'reference' | 'createdAt' | 'updatedAt'>): Booking {
    const bookings = this.getBookings();
    const refNum = Math.floor(10000 + Math.random() * 90000);
    const newBooking: Booking = {
      ...bookingData,
      id: `bkg-${Date.now()}`,
      reference: `UK-CLN-${refNum}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // If promo code was used, increment usage
    if (newBooking.pricing.promoCodeUsed) {
      const codes = this.getPromoCodes().map(p => {
        if (p.code.toUpperCase() === newBooking.pricing.promoCodeUsed?.toUpperCase()) {
          return { ...p, usageCount: p.usageCount + 1 };
        }
        return p;
      });
      saveToStorage(STORAGE_KEYS.PROMO_CODES, codes);
    }

    bookings.unshift(newBooking);
    saveToStorage(STORAGE_KEYS.BOOKINGS, bookings);
    return newBooking;
  }

  static updateBooking(id: string, updates: Partial<Booking>): Booking | undefined {
    const bookings = this.getBookings();
    let updatedBooking: Booking | undefined;
    const updatedList = bookings.map(b => {
      if (b.id === id) {
        updatedBooking = { ...b, ...updates, updatedAt: new Date().toISOString() };
        return updatedBooking;
      }
      return b;
    });
    saveToStorage(STORAGE_KEYS.BOOKINGS, updatedList);
    return updatedBooking;
  }

  static cancelBooking(id: string, reason?: string): Booking | undefined {
    return this.updateBooking(id, {
      status: 'Cancelled',
      internalNotes: reason ? `Cancelled: ${reason}` : 'Cancelled by user'
    });
  }

  // Cleaners
  static getCleaners(): Cleaner[] {
    return getFromStorage<Cleaner[]>(STORAGE_KEYS.CLEANERS, INITIAL_CLEANERS);
  }

  static getCleanerById(id: string): Cleaner | undefined {
    return this.getCleaners().find(c => c.id === id);
  }

  static addCleaner(cleaner: Omit<Cleaner, 'id' | 'createdAt' | 'updatedAt' | 'completedJobsCount' | 'rating'>): Cleaner {
    const cleaners = this.getCleaners();
    const newCleaner: Cleaner = {
      ...cleaner,
      id: `cln-${Date.now()}`,
      rating: 5.0,
      completedJobsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    cleaners.push(newCleaner);
    saveToStorage(STORAGE_KEYS.CLEANERS, cleaners);
    return newCleaner;
  }

  static updateCleaner(id: string, updates: Partial<Cleaner>): void {
    const cleaners = this.getCleaners().map(c => c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c);
    saveToStorage(STORAGE_KEYS.CLEANERS, cleaners);
  }

  static deleteCleaner(id: string): void {
    const cleaners = this.getCleaners().filter(c => c.id !== id);
    saveToStorage(STORAGE_KEYS.CLEANERS, cleaners);
  }

  // Quote Requests
  static getQuoteRequests(): QuoteRequest[] {
    return getFromStorage<QuoteRequest[]>(STORAGE_KEYS.QUOTE_REQUESTS, [
      {
        id: 'qt-1',
        name: 'Alexander Ward',
        email: 'alex.ward@example.co.uk',
        phone: '07700 900222',
        postcode: 'SW3 4RY',
        propertyType: 'House',
        serviceId: 'srv-builders',
        serviceName: 'After-Builders Cleaning',
        propertySize: '5+ Bedrooms',
        preferredDate: '2026-10-05',
        message: 'Complete Victorian terrace renovation finishing next Tuesday. Dust on all 3 floors, need specialist extraction.',
        uploadedFiles: [{ name: 'ground_floor_renovation.jpg', size: '2.4 MB' }],
        status: 'New',
        createdAt: new Date(Date.now() - 12000000).toISOString(),
        updatedAt: new Date().toISOString()
      }
    ]);
  }

  static createQuoteRequest(request: Omit<QuoteRequest, 'id' | 'status' | 'createdAt' | 'updatedAt'>): QuoteRequest {
    const requests = this.getQuoteRequests();
    const newReq: QuoteRequest = {
      ...request,
      id: `qt-${Date.now()}`,
      status: 'New',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    requests.unshift(newReq);
    saveToStorage(STORAGE_KEYS.QUOTE_REQUESTS, requests);
    return newReq;
  }

  static updateQuoteStatus(id: string, status: QuoteRequest['status'], notes?: string, estimate?: number): void {
    const requests = this.getQuoteRequests().map(q => {
      if (q.id === id) {
        return {
          ...q,
          status,
          internalNotes: notes ?? q.internalNotes,
          estimatedQuote: estimate ?? q.estimatedQuote,
          updatedAt: new Date().toISOString()
        };
      }
      return q;
    });
    saveToStorage(STORAGE_KEYS.QUOTE_REQUESTS, requests);
  }

  // Contact Messages
  static getContactMessages(): ContactMessage[] {
    return getFromStorage<ContactMessage[]>(STORAGE_KEYS.CONTACT_MESSAGES, [
      {
        id: 'msg-1',
        name: 'Charlotte Davies',
        email: 'charlotte.d@example.co.uk',
        phone: '07700 900441',
        postcode: 'NW3 2AA',
        message: 'Do you offer keyholding services for recurring weekly cleans while we are at work?',
        status: 'Unread',
        createdAt: new Date(Date.now() - 36000000).toISOString(),
        updatedAt: new Date().toISOString()
      }
    ]);
  }

  static createContactMessage(msg: Omit<ContactMessage, 'id' | 'status' | 'createdAt' | 'updatedAt'>): ContactMessage {
    const msgs = this.getContactMessages();
    const newMsg: ContactMessage = {
      ...msg,
      id: `msg-${Date.now()}`,
      status: 'Unread',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    msgs.unshift(newMsg);
    saveToStorage(STORAGE_KEYS.CONTACT_MESSAGES, msgs);
    return newMsg;
  }

  static markMessageRead(id: string): void {
    const msgs = this.getContactMessages().map(m => m.id === id ? { ...m, status: 'Read' as const, updatedAt: new Date().toISOString() } : m);
    saveToStorage(STORAGE_KEYS.CONTACT_MESSAGES, msgs);
  }

  // FAQs
  static getFaqs(): FAQ[] {
    return getFromStorage<FAQ[]>(STORAGE_KEYS.FAQS, INITIAL_FAQS);
  }

  static addFaq(faq: Omit<FAQ, 'id' | 'createdAt' | 'updatedAt'>): FAQ {
    const faqs = this.getFaqs();
    const newFaq: FAQ = {
      ...faq,
      id: `faq-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    faqs.push(newFaq);
    saveToStorage(STORAGE_KEYS.FAQS, faqs);
    return newFaq;
  }

  static updateFaq(id: string, updates: Partial<FAQ>): void {
    const faqs = this.getFaqs().map(f => f.id === id ? { ...f, ...updates, updatedAt: new Date().toISOString() } : f);
    saveToStorage(STORAGE_KEYS.FAQS, faqs);
  }

  static deleteFaq(id: string): void {
    const faqs = this.getFaqs().filter(f => f.id !== id);
    saveToStorage(STORAGE_KEYS.FAQS, faqs);
  }

  // Reviews (Testimonials)
  static getReviews(): Review[] {
    return getFromStorage<Review[]>(STORAGE_KEYS.REVIEWS, INITIAL_REVIEWS);
  }

  static addReview(review: Omit<Review, 'id' | 'createdAt' | 'updatedAt'>): Review {
    const reviews = this.getReviews();
    const newReview: Review = {
      ...review,
      id: `rev-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    reviews.push(newReview);
    saveToStorage(STORAGE_KEYS.REVIEWS, reviews);
    return newReview;
  }

  static toggleReview(id: string, active: boolean): void {
    const reviews = this.getReviews().map(r => r.id === id ? { ...r, active, updatedAt: new Date().toISOString() } : r);
    saveToStorage(STORAGE_KEYS.REVIEWS, reviews);
  }

  static deleteReview(id: string): void {
    const reviews = this.getReviews().filter(r => r.id !== id);
    saveToStorage(STORAGE_KEYS.REVIEWS, reviews);
  }

  // Special Offer / Banner
  static getSpecialOffer(): SpecialOffer {
    return getFromStorage<SpecialOffer>(STORAGE_KEYS.SPECIAL_OFFER, INITIAL_SPECIAL_OFFER);
  }

  static updateSpecialOffer(offer: Partial<SpecialOffer>): SpecialOffer {
    const current = this.getSpecialOffer();
    const updated = { ...current, ...offer };
    saveToStorage(STORAGE_KEYS.SPECIAL_OFFER, updated);
    return updated;
  }

  // Availability Blocks
  static getAvailabilityBlocks(): AvailabilityBlock[] {
    return getFromStorage<AvailabilityBlock[]>(STORAGE_KEYS.AVAILABILITY_BLOCKS, []);
  }

  static addAvailabilityBlock(date: string, reason: string, timeSlot?: string): AvailabilityBlock {
    const blocks = this.getAvailabilityBlocks();
    const newBlock: AvailabilityBlock = {
      id: `blk-${Date.now()}`,
      date,
      timeSlot,
      reason,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    blocks.push(newBlock);
    saveToStorage(STORAGE_KEYS.AVAILABILITY_BLOCKS, blocks);
    return newBlock;
  }

  static removeAvailabilityBlock(id: string): void {
    const blocks = this.getAvailabilityBlocks().filter(b => b.id !== id);
    saveToStorage(STORAGE_KEYS.AVAILABILITY_BLOCKS, blocks);
  }

  // User Authentication & Session
  static getCurrentUser(): User | null {
    return getFromStorage<User | null>(STORAGE_KEYS.CURRENT_USER, null);
  }

  static login(role: UserRole, email?: string): User {
    const demoUser = DEMO_USERS.find(u => u.role === role) || {
      id: `user-${role}-${Date.now()}`,
      email: email || `${role}@cleaning.co.uk`,
      name: role === 'admin' ? 'Admin Manager' : role === 'cleaner' ? 'Sarah Jenkins' : 'Oliver Smith',
      role,
      phone: '07700 900123',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    saveToStorage(STORAGE_KEYS.CURRENT_USER, demoUser);
    return demoUser;
  }

  static logout(): void {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    window.dispatchEvent(new CustomEvent('apexclean_storage_update', { detail: { key: STORAGE_KEYS.CURRENT_USER } }));
  }

  // Generate Invoice from Booking
  static generateInvoice(booking: Booking): Invoice {
    const website = this.getWebsiteContent();
    const vat = this.getVatSettings();

    const items = [
      {
        description: `${booking.serviceName} (${booking.propertySize}, ${booking.bathrooms} ${booking.bathrooms === 1 ? 'Bathroom' : 'Bathrooms'})`,
        quantity: 1,
        unitPrice: booking.pricing.basePrice + booking.pricing.bedroomSurcharge + booking.pricing.bathroomSurcharge,
        total: booking.pricing.basePrice + booking.pricing.bedroomSurcharge + booking.pricing.bathroomSurcharge
      }
    ];

    booking.selectedExtras.forEach(extra => {
      items.push({
        description: `Extra: ${extra.title}`,
        quantity: 1,
        unitPrice: extra.price,
        total: extra.price
      });
    });

    if (booking.pricing.weekendSurcharge > 0) {
      items.push({
        description: 'Weekend Service Surcharge',
        quantity: 1,
        unitPrice: booking.pricing.weekendSurcharge,
        total: booking.pricing.weekendSurcharge
      });
    }

    if (booking.pricing.travelFee > 0) {
      items.push({
        description: 'Travel / Out-of-Area Fee',
        quantity: 1,
        unitPrice: booking.pricing.travelFee,
        total: booking.pricing.travelFee
      });
    }

    return {
      id: `inv-${booking.id}`,
      invoiceNumber: `INV-${booking.reference.replace('UK-CLN-', '')}`,
      bookingId: booking.id,
      bookingReference: booking.reference,
      customerName: booking.customerName,
      customerEmail: booking.customerEmail,
      customerAddress: `${booking.houseNumber} ${booking.address}`,
      customerPostcode: booking.postcode,
      date: booking.bookingDate,
      items,
      subtotal: booking.pricing.subtotal,
      discount: booking.pricing.frequencyDiscount + booking.pricing.promoDiscount,
      vatRate: vat.enabled ? vat.percentage : 0,
      vatAmount: booking.pricing.vatAmount,
      total: booking.pricing.total,
      paymentStatus: booking.paymentStatus,
      paymentMethod: booking.paymentMethod || 'Online Payment',
      companyName: website.companyName,
      companyAddress: website.address,
      companyVatNumber: vat.enabled ? vat.vatNumber : undefined,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt
    };
  }
}
