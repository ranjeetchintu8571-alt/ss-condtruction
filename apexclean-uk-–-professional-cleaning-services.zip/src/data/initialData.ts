import { 
  WebsiteContent, 
  Service, 
  ServiceExtra, 
  PricingRules, 
  VatSettings, 
  ServiceAreaConfig, 
  BusinessHoursDay, 
  FAQ, 
  Review, 
  PromoCode, 
  Cleaner, 
  Booking,
  SpecialOffer,
  User
} from '../types';

export const INITIAL_WEBSITE_CONTENT: WebsiteContent = {
  companyName: '[COMPANY NAME]',
  tagline: 'Professional Cleaning. Simply Done.',
  phone: '[PHONE NUMBER]',
  email: '[EMAIL ADDRESS]',
  serviceArea: '[SERVICE AREA]',
  address: '[COMPANY ADDRESS]',
  openingHours: '[OPENING HOURS]',
  isFullyInsured: false, // Default false until enabled by admin as per instructions!
  heroHeadline: 'A Cleaner Home. A Better Day.',
  heroSubheading: 'Reliable professional cleaning services for homes, offices and properties across the UK.',
  aboutUsText: 'We are a dedicated UK cleaning provider committed to pristine cleanliness, reliable service, and transparent pricing. Built with high standards and flexible scheduling, our mission is to free up your valuable time while delivering impeccably fresh living and working spaces.',
  missionText: 'To set the benchmark for dependable, honest, and spotless cleaning across British homes and businesses through vetted cleaners and straightforward booking.',
  values: [
    { title: 'Reliability', description: 'Punctual, vetted cleaners you can trust in your home or commercial premises.' },
    { title: 'Professionalism', description: 'Trained operatives, premium cleaning supplies, and consistent quality checklists.' },
    { title: 'Attention to Detail', description: 'From skirting boards to appliance handles, we ensure every corner sparkles.' },
    { title: 'Customer Service', description: 'Friendly UK-based support and effortless online booking management.' },
    { title: 'Consistency', description: 'The same elevated quality clean, whether it is a one-off or recurring schedule.' }
  ],
  approachText: 'We combine streamlined digital management with dedicated, professional cleaners. You choose your schedule, customize extras with clear pricing, and enjoy peace of mind with vetted cleaners.',
  facebookUrl: 'https://facebook.com',
  instagramUrl: 'https://instagram.com',
  linkedinUrl: 'https://linkedin.com'
};

export const INITIAL_SERVICES: Service[] = [
  {
    id: 'srv-regular',
    slug: 'regular-house-cleaning',
    title: 'Regular House Cleaning',
    shortDescription: 'Recurring cleaning for busy households with flexible weekly, fortnightly, or monthly visits.',
    fullDescription: 'Our regular domestic cleaning service provides continuous maintenance for your home. We pair you with trusted, vetted professionals who follow a detailed room-by-room checklist tailored to your household routine.',
    iconName: 'Sparkles',
    imageUrl: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=1000&q=80',
    category: 'residential',
    startingPrice: 45,
    estimatedDuration: '2 – 4 hours',
    idealFor: ['Busy professionals', 'Families needing weekly support', 'Elderly residents', 'Holidaymakers'],
    included: [
      'Kitchen worktops, hobs, and sink sanitization',
      'Bathrooms, showers, toilets, and tiles descaling',
      'Bedrooms tidying and bed making',
      'Dusting all accessible surfaces and furniture',
      'Thorough vacuuming of carpets and rugs',
      'Hard floor vacuuming and damp mopping',
      'Emptying bins and general tidying'
    ],
    optionalExtras: ['Ironing', 'Bed linen change', 'Interior windows', 'Inside fridge', 'Oven deep clean'],
    faqs: [
      { question: 'Can I have the same cleaner every time?', answer: 'Yes, for recurring weekly or fortnightly cleaning, we assign a dedicated cleaner to ensure consistency.' },
      { question: 'Do I need to be home during the clean?', answer: 'No, many of our clients securely provide a key or lockbox code.' }
    ],
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'srv-oneoff',
    slug: 'one-off-cleaning',
    title: 'One-Off Cleaning',
    shortDescription: 'A single, comprehensive professional clean when you need an extra helping hand.',
    fullDescription: 'Perfect for seasonal spring cleans, preparing for guests, or recovering after a busy period. Our operatives refresh your entire property thoroughly in a single session.',
    iconName: 'CalendarCheck',
    imageUrl: 'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=1000&q=80',
    category: 'residential',
    startingPrice: 65,
    estimatedDuration: '3 – 5 hours',
    idealFor: ['Spring cleaning', 'Pre/post family gatherings', 'Catch-up after holidays', 'Occasional top-up'],
    included: [
      'Detailed dusting of surfaces, shelves, and frames',
      'Sanitizing kitchens and food preparation surfaces',
      'Deep scrubbing of bathroom suites, taps, and tiles',
      'Vacuuming all upholstery and carpets',
      'Washing all hard floors',
      'High-level cobweb removal and light switch cleaning'
    ],
    optionalExtras: ['Oven cleaning', 'Carpet steam clean', 'Inside kitchen cupboards', 'Interior windows'],
    faqs: [
      { question: 'What is the difference between one-off and deep cleaning?', answer: 'A one-off clean is an intensive surface clean, while deep cleaning involves internal appliances, descaling, and detailed baseboards.' }
    ],
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'srv-deep',
    slug: 'deep-cleaning',
    title: 'Deep Cleaning',
    shortDescription: 'Detailed intensive cleaning for homes and properties requiring rigorous attention.',
    fullDescription: 'Our deep cleaning service tackles accumulated dirt, grime, and lime-scale in overlooked and hard-to-reach areas. Ideal once or twice a year to maintain optimal hygiene.',
    iconName: 'ShieldCheck',
    imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1000&q=80',
    category: 'residential',
    startingPrice: 110,
    estimatedDuration: '4 – 7 hours',
    idealFor: ['Annual spring refreshes', 'Properties uncleaned for 3+ months', 'Post-illness sanitization', 'Move-ins'],
    included: [
      'Kitchen deep clean including degreasing extractor hood and splashback',
      'Bathroom deep clean, intensive limescale removal and grout scrub',
      'All skirting boards, door frames, and doors hand-wiped',
      'Behind and beneath movable furniture and appliances',
      'Radiators dusted and cleaned behind',
      'Light fittings, switches, and sockets cleaned',
      'Cabinet exteriors and reachable tops scrubbed'
    ],
    optionalExtras: ['Inside oven', 'Inside fridge/freezer', 'Inside cabinets', 'Carpet shampooing'],
    faqs: [
      { question: 'How long does a deep clean take?', answer: 'Depending on property size and condition, between 4 and 7 hours with 1 to 2 cleaners.' }
    ],
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'srv-eot',
    slug: 'end-of-tenancy-cleaning',
    title: 'End of Tenancy Cleaning',
    shortDescription: 'Designed for tenants, landlords and letting agents to secure deposit returns.',
    fullDescription: 'Guaranteed to meet UK inventory clerk and estate agency standards. We follow a comprehensive checklist designed to ensure your property passes checkout inspections flawlessly.',
    iconName: 'KeyRound',
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80',
    category: 'specialist',
    startingPrice: 145,
    estimatedDuration: '4 – 8 hours',
    idealFor: ['Tenants aiming for full deposit return', 'Landlords preparing for new tenants', 'Letting agents & property managers'],
    included: [
      'Kitchen deep sanitization including oven exterior, hob, and sink',
      'Full descaling and polishing of bathroom suites and taps',
      'All bedrooms, fitted wardrobes cleaned inside and out',
      'Living areas, woodwork, and skirting boards wiped',
      'Hard floors thoroughly scrubbed and mopped',
      'Internal windows, frames, and sills cleaned',
      'Radiators, doors, handles, and sockets wiped down'
    ],
    optionalExtras: ['Professional carpet steam clean', 'Oven interior deep degrease', 'Balcony cleaning', 'Mattress sanitization'],
    faqs: [
      { question: 'Does this service comply with UK letting agency standards?', answer: 'Yes, our checklist is matched to leading UK estate agent requirements and inventory clerk checkouts.' },
      { question: 'Does the property need electricity and water?', answer: 'Yes, operatives require working hot water and electricity to complete the clean.' }
    ],
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'srv-commercial',
    slug: 'commercial-cleaning',
    title: 'Commercial Cleaning',
    shortDescription: 'Reliable cleaning for offices, retail shops, restaurants, and commercial properties.',
    fullDescription: 'Customized commercial cleaning schedules tailored to your business operations. Available early morning, evening, or weekend to minimize disturbance to your team and clients.',
    iconName: 'Building2',
    imageUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1000&q=80',
    category: 'commercial',
    startingPrice: 75,
    estimatedDuration: 'Flexible based on sq ft',
    idealFor: ['Corporate offices', 'Retail stores & boutiques', 'Medical practices & clinics', 'Restaurants & cafes', 'Co-working spaces'],
    included: [
      'Workstations, desks, and communal table sanitization',
      'Office kitchenettes, sinks, and microwave cleaning',
      'Restrooms fully sanitized, descaled, and replenished',
      'Emptying waste receptacles and recycling sorting',
      'Floor vacuuming and hard surface buffing/mopping',
      'Glass partitions and entrance door cleaning'
    ],
    optionalExtras: ['Carpet steam extraction', 'Kitchen deep degreasing', 'High-level window cleaning', 'Supply restocking'],
    faqs: [
      { question: 'Can cleaning be done outside business hours?', answer: 'Yes, our commercial teams operate keyholding services for early morning or night shifts.' },
      { question: 'Do you provide COSHH safety data sheets?', answer: 'Yes, full compliance and safety documentation can be supplied for commercial premises.' }
    ],
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'srv-carpet',
    slug: 'carpet-upholstery-cleaning',
    title: 'Carpet & Upholstery Cleaning',
    shortDescription: 'Deep hot water extraction for carpets, sofas, armchairs, rugs, and mattresses.',
    fullDescription: 'Industrial-grade steam extraction eliminates stubborn stains, allergens, dust mites, and pet odours, restoring vibrancy and extending the lifespan of your soft furnishings.',
    iconName: 'Layers',
    imageUrl: 'https://images.unsplash.com/photo-1558317374-067fb5f30001?auto=format&fit=crop&w=1000&q=80',
    category: 'specialist',
    startingPrice: 55,
    estimatedDuration: '1.5 – 3 hours',
    idealFor: ['Stained carpets or sofas', 'Homes with pets or allergy sufferers', 'End of tenancy requirements', 'High-traffic hallways'],
    included: [
      'Pre-inspection and fibre identification',
      'High-filtration dry vacuuming to remove loose debris',
      'Targeted pre-treatment of stubborn spots and traffic lanes',
      'Pressurized hot-water extraction (steam clean)',
      'Odour neutralization and anti-bacterial rinse',
      'Pile grooming for faster drying times'
    ],
    optionalExtras: ['Scotchgard stain protection', 'Mattress deep sanitization', 'Pet odour enzyme treatment'],
    faqs: [
      { question: 'How long do carpets take to dry?', answer: 'Normally 2 to 4 hours with good ventilation and room temperature.' }
    ],
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'srv-builders',
    slug: 'after-builders-cleaning',
    title: 'After-Builders Cleaning',
    shortDescription: 'Specialist dust and debris removal for newly renovated or built properties.',
    fullDescription: 'Construction and decorating leave fine plaster dust everywhere. Our after-builders operatives use high-powered HEPA filtration and solvent cleaners to eliminate paint flecks, silicone residues, and construction dust.',
    iconName: 'Hammer',
    imageUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1000&q=80',
    category: 'specialist',
    startingPrice: 165,
    estimatedDuration: '5 – 8 hours',
    idealFor: ['Home extensions and loft conversions', 'Newly fitted kitchens or bathrooms', 'Complete property renovations', 'New build handovers'],
    included: [
      'Multi-stage HEPA vacuuming to trap ultra-fine plaster dust',
      'Removal of paint splatter, plaster specks, and masking tape residues',
      'Deep wiping of doors, architraves, switches, and sockets',
      'Sanitizing newly installed sanitary ware and tiles',
      'Cleaning inside all brand-new cupboards and drawers',
      'Buffing chrome fixtures, glass, and mirrors'
    ],
    optionalExtras: ['External window cleaning', 'Grout haze removal', 'Hard floor sealant stripping'],
    faqs: [
      { question: 'When should after-builders cleaning take place?', answer: 'Once all tradespeople have completely finished their work to prevent re-contamination.' }
    ],
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'srv-airbnb',
    slug: 'airbnb-holiday-let-cleaning',
    title: 'Airbnb / Holiday-Let Cleaning',
    shortDescription: 'Fast turnaround cleaning, linen changing, and checklist inspection for hosts.',
    fullDescription: 'Keep your short-let property 5-star reviewed with reliable same-day turnaround. We manage guest turnarounds, linen laundry coordination, bathroom replenishments, and report maintenance issues promptly.',
    iconName: 'Home',
    imageUrl: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1000&q=80',
    category: 'commercial',
    startingPrice: 70,
    estimatedDuration: '2 – 3.5 hours',
    idealFor: ['Airbnb and VRBO hosts', 'Serviced apartment operators', 'Holiday cottage owners', 'Property management companies'],
    included: [
      'Hotel-standard bed stripping and remaking with fresh linen',
      'Sanitizing bathrooms and replenishing toiletries',
      'Full kitchen clean and emptying fridge/pantry',
      'Restocking tea, coffee, and welcome items checklist',
      'Vacuuming, mopping, and patio/balcony sweep',
      'Pre-arrival guest inspection and photo report'
    ],
    optionalExtras: ['Linen wash and iron service', 'Key safe code reset', 'Emergency call-out'],
    faqs: [
      { question: 'Can you work within strict check-in windows?', answer: 'Yes, we specialize in the standard 10:00 AM – 3:00 PM turnaround window between guest bookings.' }
    ],
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const INITIAL_EXTRAS: ServiceExtra[] = [
  { id: 'ext-oven', title: 'Oven Deep Clean', description: 'Complete degreasing of racks, glass door, and interior chamber', price: 45, iconName: 'Flame', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-fridge', title: 'Inside Fridge & Freezer', description: 'Defrost wipe-down, shelving scrub, and odour neutralization', price: 25, iconName: 'Snowflake', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-cabinets', title: 'Inside Kitchen Cabinets', description: 'Empty, wipe shelves, remove crumbs, and reorganize', price: 35, iconName: 'Box', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-windows', title: 'Interior Windows & Sills', description: 'Streak-free cleaning of all indoor window panes and frames', price: 30, iconName: 'Maximize', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-carpet', title: 'Carpet Steam Clean (Per Room)', description: 'Hot water extraction for single room or area rug', price: 45, iconName: 'Layers', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-upholstery', title: 'Sofa / Upholstery Clean', description: 'Fibre conditioning and deep steam shampoo', price: 40, iconName: 'Armchair', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-mattress', title: 'Mattress Sanitization', description: 'Allergen extraction and anti-microbial treatment', price: 35, iconName: 'Bed', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-ironing', title: 'Ironing Service (1 Hour)', description: 'Shirts, trousers, and bedding pressed neatly', price: 20, iconName: 'Shirt', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-laundry', title: 'Laundry Wash & Dry Cycle', description: 'Standard wash, dry, and fold cycle', price: 20, iconName: 'RotateCcw', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-extra-bath', title: 'Extra Bathroom Suite', description: 'Full sanitization of additional ensuite or cloakroom', price: 25, iconName: 'Bath', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'ext-balcony', title: 'Balcony or Patio Clean', description: 'Sweep, wash down railings and floor tiles', price: 30, iconName: 'Sun', active: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
];

export const INITIAL_PRICING_RULES: PricingRules = {
  basePrices: {
    'srv-regular': 45,
    'srv-oneoff': 65,
    'srv-deep': 110,
    'srv-eot': 145,
    'srv-commercial': 85,
    'srv-carpet': 55,
    'srv-builders': 165,
    'srv-airbnb': 70
  },
  bedroomPrice: 15,
  bathroomPrice: 20,
  propertySizePrices: {
    'Studio': 0,
    '1 Bedroom': 15,
    '2 Bedrooms': 30,
    '3 Bedrooms': 45,
    '4 Bedrooms': 65,
    '5+ Bedrooms': 90
  },
  frequencyDiscounts: {
    weekly: 15,      // 15% discount
    fortnightly: 10, // 10% discount
    monthly: 5       // 5% discount
  },
  weekendSurcharge: 15,
  peakTimeSurcharge: 10,
  minimumBookingAmount: 45,
  travelFee: 0
};

export const INITIAL_VAT_SETTINGS: VatSettings = {
  enabled: false, // Default false: "Do not assume the company is VAT registered"
  percentage: 20,
  pricesIncludeVat: true,
  vatNumber: 'GB 123 4567 89'
};

export const INITIAL_SERVICE_AREA: ServiceAreaConfig = {
  allowedPostcodePrefixes: [
    'SW', 'SE', 'NW', 'NE', 'EC', 'WC', 'W', 'E', 
    'BR', 'CR', 'DA', 'EN', 'HA', 'IG', 'KT', 'RM', 
    'SM', 'TW', 'UB', 'WD', 'M', 'B', 'BS', 'LS', 'OX', 'CB'
  ],
  cities: ['London', 'Greater London', 'Manchester', 'Birmingham', 'Bristol', 'Leeds', 'Oxford', 'Cambridge'],
  regions: ['Greater London', 'South East', 'West Midlands', 'North West'],
  travelRadiusMiles: 35,
  customNotice: 'We cover Greater London and major surrounding hubs. Enter your postcode to confirm instant availability.',
  allowNationwide: true, // If true, allows all valid UK postcodes with confirmation
  travelFee: 0
};

export const INITIAL_BUSINESS_HOURS: BusinessHoursDay[] = [
  { day: 'Monday', open: true, openTime: '08:00', closeTime: '18:00' },
  { day: 'Tuesday', open: true, openTime: '08:00', closeTime: '18:00' },
  { day: 'Wednesday', open: true, openTime: '08:00', closeTime: '18:00' },
  { day: 'Thursday', open: true, openTime: '08:00', closeTime: '18:00' },
  { day: 'Friday', open: true, openTime: '08:00', closeTime: '18:00' },
  { day: 'Saturday', open: true, openTime: '09:00', closeTime: '16:00' },
  { day: 'Sunday', open: false, openTime: '10:00', closeTime: '14:00' }
];

export const INITIAL_FAQS: FAQ[] = [
  { id: 'faq-1', question: 'How do I book a cleaning?', answer: 'You can book directly through our online system in under 60 seconds. Choose your service, select property specifications, pick a date and convenient time slot, and confirm with zero hassle.', category: 'Booking', order: 1, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-2', question: 'Do you provide regular cleaning?', answer: 'Yes! We provide flexible recurring cleaning on a weekly, fortnightly, or monthly schedule with discounted rates and your own assigned cleaner.', category: 'Services', order: 2, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-3', question: 'Do you offer one-off cleaning?', answer: 'Absolutely. If you need an intensive spring clean or a single appointment before guests arrive, you can easily reserve a one-off visit without any ongoing commitment.', category: 'Services', order: 3, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-4', question: 'What is included in a deep clean?', answer: 'A deep clean is a rigorous top-to-bottom scrub covering all accessible surfaces, limescale removal in bathrooms, degreasing kitchen zones, hand-wiping skirting boards, radiators, doors, and behind furniture.', category: 'Services', order: 4, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-5', question: 'Do you provide end-of-tenancy cleaning?', answer: 'Yes, our end-of-tenancy service adheres strictly to professional UK letting agent and inventory clerk inspection checklists to maximize your deposit return.', category: 'Services', order: 5, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-6', question: 'Can I book carpet cleaning?', answer: 'Yes, we offer professional hot-water extraction (steam cleaning) for carpets, rugs, and upholstery. It can be booked standalone or as an add-on extra to your house clean.', category: 'Services', order: 6, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-7', question: 'Can I choose my cleaner?', answer: 'For recurring bookings, we pair you with a dedicated primary cleaner. If you ever wish to switch or request a specific operative, you can manage this from your customer account or contact our team.', category: 'Cleaners', order: 7, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-8', question: 'Can I reschedule my booking?', answer: 'Yes, you can reschedule your booking online up to 24 hours prior to your scheduled appointment time via your Customer Dashboard without any fee.', category: 'Booking', order: 8, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-9', question: 'What happens if I need to cancel?', answer: 'Cancellations made at least 24 hours in advance receive a full refund or rescheduling credit. Late cancellations within 24 hours may incur a modest administrative callout fee.', category: 'Booking', order: 9, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-10', question: 'Do I need to provide cleaning products?', answer: 'For regular cleaning, cleaners typically utilize your preferred home supplies and vacuum to respect personal preferences and avoid cross-contamination. For deep, end-of-tenancy, and carpet cleans, all specialist equipment and chemicals are supplied.', category: 'Equipment', order: 10, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-11', question: 'What areas do you cover?', answer: 'We cover widespread UK postal districts across London, Greater London, and key regions. You can verify your exact postcode instantly using our service area checker in the booking widget.', category: 'Coverage', order: 11, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-12', question: 'How are prices calculated?', answer: 'Our transparent dynamic pricing engine calculates costs based on your selected service, property bedrooms, bathrooms, frequency discounts, and any requested optional extras. You see the full itemized breakdown before confirming.', category: 'Pricing', order: 12, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-13', question: 'Can I book recurring cleaning?', answer: 'Yes! Regular schedules (weekly, fortnightly, or monthly) benefit from automated slot reservation and up to 15% recurring discounts.', category: 'Services', order: 13, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'faq-14', question: 'Can I request a quote?', answer: 'Yes, if you have bespoke commercial specifications, unique property dimensions, or large-scale requirements, submit our quick Quote Request form with photos for a tailored quotation within hours.', category: 'Pricing', order: 14, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
];

// Per prompt: "Display: 'Customer reviews will appear here.' Allow admin to add genuine reviews manually."
// Do NOT invent fake customer reviews!
export const INITIAL_REVIEWS: Review[] = [];

export const INITIAL_SPECIAL_OFFER: SpecialOffer = {
  enabled: true,
  title: 'New Customer Offer',
  description: 'Save £15 on your first booking with code WELCOME15 at checkout.',
  discountType: 'fixed',
  discountValue: 15,
  promoCode: 'WELCOME15'
};

export const INITIAL_PROMO_CODES: PromoCode[] = [
  {
    id: 'promo-welcome15',
    code: 'WELCOME15',
    discountType: 'fixed',
    discountValue: 15,
    minBookingAmount: 45,
    expiresAt: '2027-12-31',
    usageLimit: 500,
    usageCount: 14,
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'promo-clean10',
    code: 'CLEAN10',
    discountType: 'percentage',
    discountValue: 10,
    minBookingAmount: 50,
    expiresAt: '2027-12-31',
    usageLimit: 200,
    usageCount: 9,
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const INITIAL_CLEANERS: Cleaner[] = [
  {
    id: 'cln-1',
    userId: 'user-cln-1',
    name: 'Sarah Jenkins',
    phone: '07700 900123',
    email: 'sarah.cleaner@example.co.uk',
    serviceAreas: ['SW', 'SE', 'CR', 'KT'],
    skills: ['Residential', 'Deep Cleaning', 'End of Tenancy', 'Airbnb'],
    availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    workingHours: '08:00 – 16:30',
    status: 'Available',
    rating: 4.9,
    completedJobsCount: 142,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cln-2',
    userId: 'user-cln-2',
    name: 'Marcus Davies',
    phone: '07700 900456',
    email: 'marcus.cleaner@example.co.uk',
    skills: ['Commercial', 'Carpet Cleaning', 'After Builders', 'End of Tenancy'],
    serviceAreas: ['EC', 'WC', 'W', 'NW', 'E'],
    availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    workingHours: '07:30 – 17:00',
    status: 'Busy',
    rating: 4.8,
    completedJobsCount: 98,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cln-3',
    userId: 'user-cln-3',
    name: 'Elena Popova',
    phone: '07700 900789',
    email: 'elena.cleaner@example.co.uk',
    skills: ['Residential', 'Deep Cleaning', 'Airbnb'],
    serviceAreas: ['SW', 'W', 'TW', 'UB'],
    availability: ['Tuesday', 'Wednesday', 'Thursday', 'Saturday'],
    workingHours: '09:00 – 17:00',
    status: 'Available',
    rating: 5.0,
    completedJobsCount: 185,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'bkg-101',
    reference: 'UK-CLN-92014',
    customerId: 'cust-demo',
    customerName: 'Oliver Smith',
    customerEmail: 'oliver.smith@example.co.uk',
    customerPhone: '07700 900881',
    serviceId: 'srv-regular',
    serviceName: 'Regular House Cleaning',
    propertyType: 'House',
    propertySize: '3 Bedrooms',
    bathrooms: 2,
    frequency: 'weekly',
    selectedExtras: [
      { extraId: 'ext-ironing', title: 'Ironing Service (1 Hour)', price: 20 }
    ],
    bookingDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    timeSlot: '09:00 – 11:30',
    address: '14 Kensington Park Gardens',
    houseNumber: '14',
    postcode: 'W11 3HB',
    accessInstructions: 'Key in security key safe code 4821 by side gate',
    specialInstructions: 'Please focus on kitchen countertops and polish wooden dining table',
    pricing: {
      basePrice: 45,
      bedroomSurcharge: 45,
      bathroomSurcharge: 40,
      extrasTotal: 20,
      frequencyDiscount: 22.5,
      travelFee: 0,
      weekendSurcharge: 0,
      subtotal: 127.5,
      vatAmount: 0,
      promoDiscount: 0,
      total: 127.5
    },
    status: 'Cleaner Assigned',
    paymentStatus: 'Paid',
    paymentMethod: 'Credit Card (Online)',
    assignedCleanerId: 'cln-1',
    assignedCleanerName: 'Sarah Jenkins',
    internalNotes: 'Client confirmed recurring Wednesday morning slot.',
    createdAt: new Date(Date.now() - 172800000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString()
  },
  {
    id: 'bkg-102',
    reference: 'UK-CLN-83192',
    customerId: 'cust-demo-2',
    customerName: 'Emma Watson',
    customerEmail: 'emma.w@example.co.uk',
    customerPhone: '07700 900332',
    serviceId: 'srv-eot',
    serviceName: 'End of Tenancy Cleaning',
    propertyType: 'Flat/Apartment',
    propertySize: '2 Bedrooms',
    bathrooms: 1,
    frequency: 'one-off',
    selectedExtras: [
      { extraId: 'ext-oven', title: 'Oven Deep Clean', price: 45 },
      { extraId: 'ext-carpet', title: 'Carpet Steam Clean', price: 45 }
    ],
    bookingDate: new Date(Date.now() + 172800000).toISOString().split('T')[0],
    timeSlot: '13:30 – 17:30',
    address: 'Flat 4, 88 Battersea Rise',
    houseNumber: 'Flat 4',
    postcode: 'SW11 1EJ',
    accessInstructions: 'Concierge desk has keys marked Flat 4',
    specialInstructions: 'Letting agent checkout inspection scheduled for Friday 9 AM',
    pricing: {
      basePrice: 145,
      bedroomSurcharge: 30,
      bathroomSurcharge: 20,
      extrasTotal: 90,
      frequencyDiscount: 0,
      travelFee: 0,
      weekendSurcharge: 0,
      subtotal: 285,
      vatAmount: 0,
      promoDiscount: 15,
      promoCodeUsed: 'WELCOME15',
      total: 270
    },
    status: 'Confirmed',
    paymentStatus: 'Paid',
    paymentMethod: 'Debit Card',
    assignedCleanerId: 'cln-2',
    assignedCleanerName: 'Marcus Davies',
    internalNotes: 'Estate agent checkout requirements checklist provided.',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'bkg-103',
    reference: 'UK-CLN-77410',
    customerId: 'cust-demo-3',
    customerName: 'David H. Miller',
    customerEmail: 'david.miller@example.co.uk',
    customerPhone: '07700 900554',
    serviceId: 'srv-commercial',
    serviceName: 'Commercial Cleaning',
    propertyType: 'Office',
    propertySize: '3 Bedrooms',
    bathrooms: 2,
    frequency: 'weekly',
    selectedExtras: [],
    bookingDate: new Date(Date.now() + 259200000).toISOString().split('T')[0],
    timeSlot: '18:00 – 20:30',
    address: 'Suite 301, 10 Finsbury Square',
    houseNumber: 'Suite 301',
    postcode: 'EC2A 1AF',
    accessInstructions: 'Security code provided to cleaner for night access',
    specialInstructions: 'Empty all recycling bins and clean board room glass partition',
    pricing: {
      basePrice: 85,
      bedroomSurcharge: 45,
      bathroomSurcharge: 40,
      extrasTotal: 0,
      frequencyDiscount: 25.5,
      travelFee: 0,
      weekendSurcharge: 0,
      subtotal: 144.5,
      vatAmount: 0,
      promoDiscount: 0,
      total: 144.5
    },
    status: 'Pending',
    paymentStatus: 'Pay on Completion',
    paymentMethod: 'BACS Invoice',
    internalNotes: 'Awaiting commercial agreement countersign.',
    createdAt: new Date(Date.now() - 43200000).toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const DEMO_USERS: User[] = [
  {
    id: 'user-admin',
    email: 'admin@cleaning.co.uk',
    name: 'Admin Manager',
    role: 'admin',
    phone: '07700 900001',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'user-cln-1',
    email: 'cleaner@cleaning.co.uk',
    name: 'Sarah Jenkins',
    role: 'cleaner',
    phone: '07700 900123',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cust-demo',
    email: 'customer@cleaning.co.uk',
    name: 'Oliver Smith',
    role: 'customer',
    phone: '07700 900881',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];
