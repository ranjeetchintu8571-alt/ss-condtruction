export type UserRole = 'customer' | 'admin' | 'manager' | 'cleaner';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  phone?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomerAddress {
  id: string;
  label: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  postcode: string;
  isDefault?: boolean;
}

export interface Customer {
  id: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  savedAddresses: CustomerAddress[];
  createdAt: string;
  updatedAt: string;
}

export interface AdminUser {
  id: string;
  userId: string;
  name: string;
  email: string;
  role: 'admin' | 'manager';
  createdAt: string;
  updatedAt: string;
}

export type CleanerSkill = 
  | 'Residential' 
  | 'Commercial' 
  | 'Deep Cleaning' 
  | 'Carpet Cleaning' 
  | 'End of Tenancy' 
  | 'After Builders' 
  | 'Airbnb';

export type CleanerStatus = 'Available' | 'Busy' | 'Off Duty';

export interface Cleaner {
  id: string;
  userId: string;
  name: string;
  phone: string;
  email: string;
  serviceAreas: string[];
  skills: CleanerSkill[];
  availability: string[];
  workingHours: string;
  status: CleanerStatus;
  rating: number;
  completedJobsCount: number;
  createdAt: string;
  updatedAt: string;
}

export type ServiceCategory = 'residential' | 'commercial' | 'specialist';

export interface Service {
  id: string;
  slug: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  iconName: string;
  imageUrl: string;
  category: ServiceCategory;
  startingPrice: number;
  estimatedDuration: string;
  idealFor: string[];
  included: string[];
  optionalExtras: string[];
  faqs: { question: string; answer: string }[];
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ServiceExtra {
  id: string;
  title: string;
  description: string;
  price: number;
  iconName?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export type PropertyType = 'House' | 'Flat/Apartment' | 'Studio' | 'Office' | 'Shop' | 'Other';
export type PropertySize = 'Studio' | '1 Bedroom' | '2 Bedrooms' | '3 Bedrooms' | '4 Bedrooms' | '5+ Bedrooms';
export type BathroomsCount = 1 | 2 | 3 | 4;
export type CleaningFrequency = 'one-off' | 'weekly' | 'fortnightly' | 'monthly';

export type BookingStatus = 
  | 'Pending' 
  | 'Confirmed' 
  | 'Cleaner Assigned' 
  | 'In Progress' 
  | 'Completed' 
  | 'Cancelled';

export type PaymentStatus = 'Pending' | 'Paid' | 'Failed' | 'Pay on Completion';

export interface BookingPricingBreakdown {
  basePrice: number;
  bedroomSurcharge: number;
  bathroomSurcharge: number;
  extrasTotal: number;
  frequencyDiscount: number;
  travelFee: number;
  weekendSurcharge: number;
  subtotal: number;
  vatAmount: number;
  promoDiscount: number;
  promoCodeUsed?: string;
  total: number;
}

export interface BookingItem {
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Booking {
  id: string;
  reference: string;
  customerId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  serviceId: string;
  serviceName: string;
  propertyType: PropertyType;
  propertySize: PropertySize;
  bathrooms: number;
  frequency: CleaningFrequency;
  selectedExtras: { extraId: string; title: string; price: number }[];
  bookingDate: string;
  timeSlot: string;
  address: string;
  houseNumber: string;
  postcode: string;
  accessInstructions?: string;
  specialInstructions?: string;
  pricing: BookingPricingBreakdown;
  status: BookingStatus;
  paymentStatus: PaymentStatus;
  paymentMethod?: string;
  assignedCleanerId?: string;
  assignedCleanerName?: string;
  internalNotes?: string;
  cleanerNotes?: string;
  completionPhotos?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  bookingId: string;
  bookingReference: string;
  customerName: string;
  customerEmail: string;
  customerAddress: string;
  customerPostcode: string;
  date: string;
  items: BookingItem[];
  subtotal: number;
  discount: number;
  vatRate: number;
  vatAmount: number;
  total: number;
  paymentStatus: PaymentStatus;
  paymentMethod: string;
  companyName: string;
  companyAddress: string;
  companyVatNumber?: string;
  createdAt: string;
  updatedAt: string;
}

export interface QuoteRequest {
  id: string;
  name: string;
  email: string;
  phone: string;
  postcode: string;
  propertyType: PropertyType;
  serviceId: string;
  serviceName: string;
  propertySize: string;
  preferredDate?: string;
  message: string;
  uploadedFiles?: { name: string; size: string }[];
  status: 'New' | 'Reviewed' | 'Quoted' | 'Closed';
  estimatedQuote?: number;
  internalNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  postcode: string;
  message: string;
  status: 'Unread' | 'Read' | 'Replied';
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  customerName: string;
  reviewText: string;
  rating: number;
  date: string;
  serviceName: string;
  verified: boolean;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PromoCode {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minBookingAmount: number;
  expiresAt?: string;
  usageLimit?: number;
  usageCount: number;
  applicableServices?: string[];
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface BusinessHoursDay {
  day: string;
  open: boolean;
  openTime: string;
  closeTime: string;
}

export interface ServiceAreaConfig {
  allowedPostcodePrefixes: string[];
  cities: string[];
  regions: string[];
  travelRadiusMiles: number;
  customNotice: string;
  allowNationwide: boolean;
  travelFee: number;
}

export interface PricingRules {
  basePrices: Record<string, number>;
  bedroomPrice: number;
  bathroomPrice: number;
  propertySizePrices: Record<string, number>;
  frequencyDiscounts: {
    weekly: number;      // percentage, e.g. 15
    fortnightly: number; // percentage, e.g. 10
    monthly: number;     // percentage, e.g. 5
  };
  weekendSurcharge: number;
  peakTimeSurcharge: number;
  minimumBookingAmount: number;
  travelFee: number;
}

export interface VatSettings {
  enabled: boolean;
  percentage: number;
  pricesIncludeVat: boolean;
  vatNumber?: string;
}

export interface WebsiteContent {
  companyName: string;
  tagline: string;
  phone: string;
  email: string;
  serviceArea: string;
  address: string;
  openingHours: string;
  isFullyInsured: boolean;
  heroHeadline: string;
  heroSubheading: string;
  aboutUsText: string;
  missionText: string;
  values: { title: string; description: string }[];
  approachText: string;
  facebookUrl?: string;
  instagramUrl?: string;
  linkedinUrl?: string;
}

export interface SpecialOffer {
  enabled: boolean;
  title: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  promoCode: string;
}

export interface AvailabilityBlock {
  id: string;
  date: string;
  timeSlot?: string;
  reason: string;
  createdAt: string;
  updatedAt: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: string;
  read: boolean;
  targetRole?: UserRole;
}
